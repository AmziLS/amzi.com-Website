This diskette contains authorized artwork for 
the IBM Business Partner emblem.

ONLY CURRENT AUTHORIZED IBM BUSINESS PARTNERS IN 
COMPLIANCE WITH THE TERMS OF THE BUSINESS PARTNER 
AGREEMENT OR THE PARTNERWORLD AGREEMENT ARE AUTHORIZED 
BY IBM TO DOWNLOAD THE 
ARTWORK. THE ARTWORK MAY ONLY BE USED UNDER THE 
TERMS OF THE BUSINESS PARTNER AGREEMENT OR THE
PARTNERWORLD AGREEMENT AND IN 
COMPLIANCE WITH THE BUSINESS PARTNER EMBLEM 
GUIDELINES. NO OTHER USE OF THE ARTWORK IS PERMITTED.

Only the EPS files should be used for print
applications. The GIF file is for on-screen
usage only. The BMP file should be used
for low-resolution printing on non-PostScript(TM)
office laser printers.

Do not use BMP or GIF files as artwork for
printed communications.

Color version
* Color version is preferred.
* Do not alter the colors of the emblem.
	- Spot color: Pantone 2718 Blue
	- Four-color process: 
	Cyan 91%, Magenta 43%, Yellow 0%, Black 0%
* "Business Partner" text and the (R) notice 
print black in all instances.
* Do not use the color version of the 
emblem in low-resolution printing conditions.
* Do not allow printed background colors to 
show through the emblem. The IBM logotype and the 
inside of the Business Partner box should always 
appear white.

Black version
* Do not use the black version of the emblem 
in low-resolution printing conditions.
* Do not recreate the emblem using different typefaces.
* Do not create three-dimensional versions of the emblem.
* Do not add business partner designations to the emblem.

Low-resolution printing version
* Use the low-resolution printing emblem for all 
situations in which reproduction is typically of low quality, 
such as faxes, newspapers, or yellow pages advertising.
* Do not alter the line weights.
* Do not change the size of the elements within the emblem.

PostScript(TM) is a trademark of Adobe Systems Incorporated.



