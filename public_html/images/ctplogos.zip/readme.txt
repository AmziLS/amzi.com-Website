CODEGEAR TECHNOLOGY PARTNER LOGO USAGE 
-----------------------------------
Membership in the CodeGear Technology Partner Program requires that partners: a) maintain a Web site; b) host Web 
hot links to the CodeGear Web site; and c) place CodeGear logos on Web sites, product boxes, advertisements, etc. 

A temporary CodeGear is available to CodeGear Technology Partners in various sizes and formats. The logo may be 
utilized for your Web site, print ads, product literature, product packaging, etc.  By displaying the logo, you are 
representing that your product(s) are compatible with and support CodeGear products and that you are an active member 
of the CodeGear Technology Partner Program with a current non-disclosure agreement on file.

We will be tracking all logo references from Technology Partners, so please read all instructions carefully regarding 
logo usage and hyperlink formatting.  Those partners with high numbers of unique click-through referrals may be identified 
for further marketing partnerships.

LOGO DOWNLOAD: CodeGear Technology Partner Logos - http://tp.codegear.com/resources/ctp_logos.zip

IMPORTANT!: Please note that these are temporary CodeGear logo graphics will be replaced with final logos upon their approved 
release and publication sometime in Q2 2007.

WEB SITE LOGO USAGE: 
To allow us to track where CodeGear logo references are originating, a specific hyperlink URL must 
be used for the logo on your Web site.  The URL you will use behind the logo on your site is unique to your 
CTP company ID number and to the product ID for JBuilder 2007, and takes the following form:

	http://tp.codegear.com/btprefer.aspx?partner_id=####&product_id=0 

(#### indicates your CTP company ID number found on the Company Tab of CTPConsole and 0 is the referral ID for CodeGear Technology Partners)

EXAMPLE HYPERLINK:
(Example CTP Company ID: 1234 <--- substitute your ID here - found on CTPConsole on the Company Data tab)

<a href="http://tp.codegear.com/btprefer.aspx?partner_id=1234&product_id=0" target=_BLANK><img src="jb2007logo_150.png" border=0 alt="CodeGear - Where Developers Matter"></a>

QUESTIONS:
Questions may be directed to:
Christine Ellis
CodeGear
Developer Relations
100 Enterprise Way
Scotts Valley, CA  95066

Email: christine.ellis@codegear.com
