// GEKOTest.java

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.clientdb.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.client.*;
import amzi.kb.*;

import java.util.*;
import java.io.*;

public class GEKOTest
{
   GEKOClientI gekos;
   BufferedReader din;

   // Used in edit mode
   KnowledgeFrame current_geko;
   KnowledgeFrame current_person;
   KnowledgeFrame current_citation;
   KnowledgeFrame current_keyword;
   KnowledgeFrame current_variable;

   public static void main(String[] args) throws Exception
   {
      GEKOTest app = new GEKOTest();
      app.go();
   }

   public GEKOTest() throws Exception
   {
      din = new BufferedReader(new InputStreamReader(System.in));
   }

   /**
   * A simple console-based command loop.
   */
   public void go()
   {
      String command;

      //gekos = new GEKOClientI_RMI();
      gekos = new GEKOClientI_PSE();

      System.out.println("AMKES Console Test Application");
      System.out.println("");

      command = "help";

      while (! command.equals("exit"))
      {
         try
         {
            if (command.equals("error")) ;    // do nothing after an error
            // System
            else if (command.equals("help"))      display_help();
            else if (command.equals("logon"))     logon();
            else if (command.equals("logoff"))    logoff();
            else if (command.equals("logout"))    logoff();
            else if (command.equals("new"))       new_library();
            else if (command.equals("open"))      open_library();
            else if (command.equals("edit"))      edit();
            else if (command.equals("test_schemas")) test_schemas();
            else
               display_help();

            System.out.print("\nKA> ");
            command = din.readLine();
         }
         catch (KAFrameException e)
         {
            System.out.println("MainLoop: " + e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (FrameException e)
         {
            System.out.println("MainLoop: " + e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (IOException e)
         {
            System.out.println("MainLoop: " + e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (Exception e)
         {
            System.out.println("MainLoop: " + e.getMessage());
            e.printStackTrace();
            command = "error";
         }
      }
      System.out.println("quitting");
      return;
   }

   private void display_help()
   {
      System.out.println("The GEKO Test application is a command line interface");
      System.out.println("to a KnowledgeLibrary storing GEKOs.");
      System.out.println();
      System.out.println("You can enter the following commands:");
      System.out.println("  help     - shows this information");
      System.out.println("  logon    - logon to server");
      System.out.println("  logout   - logoff server");
      System.out.println("  logoff   - logoff server");
      System.out.println("  new      - create a new library");
      System.out.println("  open     - open an existing library");
      System.out.println("  edit     - start a geko editing session");
      System.out.println("  test_schemas     - test the xml schema read");
      System.out.println("  exit     - exits the Knowledge Archiver");
   }

   class GKOFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return n.endsWith(".gko");
      }
   }

   class XMLFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return n.endsWith(".xml");
      }
   }

   class GKOXMLFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return (n.endsWith(".xml") || n.endsWith(".gko"));
      }
   }


   private void new_library() throws FrameException, IOException
   {
      String name = prompt("New Library Name: ");
      String schema = prompt("Schema: ");
      gekos.create( name, schema );
   }
   
   private void open_library() throws FrameException, IOException
   {
      Vector archives = gekos.get_archives();
      gekos.open(string_list_select(archives));
      //gekos.open(prompt("Library Name: "));
   }
   
   private void logon() throws FrameException, IOException
   {
      String default_addr = "209.251.13.83";
      String port = "1099";
      String addr = prompt("Server address (" + default_addr + ")");
      if (addr.equals(""))
         addr = default_addr;
      if (addr.equals("local"))
         addr = "";
      System.out.println("Connecting to server...");
      gekos.connect(addr, port);
      boolean tf = gekos.logon(
            prompt("User ID: "),
            prompt("Password: ") );
      if (tf)
         System.out.println("Logon successfull");
      else
         System.out.println("Logon failed");
   }

   private void logoff() throws FrameException
   {
      gekos.logoff();
   }

   private void test_schemas() throws FrameException, IOException
   {
      File f = new File("/KnowledgeArchiver/source/default.sch");
      Vector v = KnowledgeFrame.readXMLs(f);
      for (int i=0; i < v.size(); i++)
      {
         System.out.println("*******************");
         System.out.println();
         KnowledgeFrame kf = (KnowledgeFrame)v.elementAt(i);
         System.out.println(kf.toFullString());
      }
   }

   /* --------- */
   /* Edit Mode */

   private void edit() throws FrameException, IOException
   {
      String command = "help";

      while (! command.equals("exit"))
      {
         try
         {
            if (command.equals("error")) ;    // do nothing after an error
            // System
            else if (command.equals("help"))      edit_help();
            else if (command.equals("new"))       edit_new();
            else if (command.equals("open"))      edit_open();
            else if (command.equals("show"))      edit_show();
            else if (command.equals("save"))      edit_save();
            else if (command.equals("upload"))    edit_upload();
            else if (command.equals("batch"))     edit_batch();
            else if (command.equals("download"))  edit_download();
            else if (command.equals("infer"))     edit_infer();
            else if (command.equals("query"))     edit_query();
            else
               edit_help();

            System.out.print("\nEdit> ");
            command = din.readLine();
         }
         catch (KAFrameException e)
         {
            System.out.println(e.getMsg());
            e.printStackTrace();
            command = "error";
         }
         catch (FrameException e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (IOException e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
      }
      System.out.println("quitting edit mode");
      return;
   }

   private void edit_help() throws FrameException, IOException
   {
      System.out.println("AMKES Console Edit Mode for local and archive GEKOs");
      System.out.println();
      System.out.println("In edit mode there is a 'current geko' which is");
      System.out.println("operated on, either being created, uploaded or whatever.");
      System.out.println();
      System.out.println("You can enter the following commands:");
      System.out.println("  help     - shows this information");
      System.out.println("  new      - create a new GEKO or other frame");
      System.out.println("  open     - open a GEKO from disk");
      System.out.println("  save     - save the current GEKO to disk");
      System.out.println("  show     - show the current GEKO");
      System.out.println("  upload   - upload current GEKO to archive");
      System.out.println("  batch    - upload a full directory");
      System.out.println("  download - download a GEKO");
      System.out.println("  exit     - exits edit mode");
      System.out.println("  infer    - test kb download");
      System.out.println("  query    - test query");
   }

   /**
   * Create a new knowledge frame for the various AMKES shared
   * frame types/groups.
   */
   private void edit_new() throws FrameException, IOException
   {
      System.out.println("Select the type of frame to create.");
      Vector groups = gekos.get_groups();
      String group_name = string_list_select(groups);
      if (group_name == null)
         return;

      // Create a queryframe for frames of group "schema"
      // and find one who's 'group' slot is the one we want.
      QueryFrame qf = new QueryFrame("schema");
      qf.set("group", new QueryOp(QueryOp.EQUALS, group_name));

      // The query returns a vector of key_note_pairs that
      // satisfy the query, should be just the one schema.
      Vector v = gekos.query(qf);
      if (v.size() != 1)
         throw new FrameException(FrameException.NO_SCHEMA, group_name);

      // Retrieve the schema frame.
      String key = ((KeyNotePair)v.elementAt(0)).get_key();
      KnowledgeFrame schema = gekos.get_frame("schema", key);

      // Call the function that walks the schema
      // prompting for inputs.
      KnowledgeFrame new_frame = read_frame(schema, 0);

      if      (group_name.equals("geko")) current_geko = new_frame;
      else if (group_name.equals("person")) current_person = new_frame;
      else if (group_name.equals("citation")) current_citation = new_frame;
      else if (group_name.equals("keyword")) current_keyword = new_frame;
      else if (group_name.equals("variable")) current_variable = new_frame;

      return;
   }

   /**
   * Open a text file with a GEKO, either in .gko or .xml
   * format.
   */
   private void edit_open() throws FrameException, IOException
   {
      System.out.println("What type of file to open.");
      Vector choices = new Vector();
         choices.addElement(".gko");
         choices.addElement(".xml");
      String file_type = string_list_select(choices);

      // Let someone else do the work.
      if (file_type == null)
         return;
      else if (file_type.equals(".gko"))
         edit_open_gko();
      else if (file_type.equals(".xml"))
         edit_open_xml();

      return;
   }

   private void edit_open_gko() throws FrameException, IOException
   {
      String sub_dir = prompt("Which gekos subdirectory? ");
      String dir = "/KnowledgeArchiver/gekos/" + sub_dir + "/";
      String[] files = (new File(dir)).list(new GKOFilter());
      System.out.println("Open which file? ");
      Vector choices = new Vector();
      for (int i=0; i<files.length; i++)
         choices.addElement(files[i].toString());
      String file_name = string_list_select(choices);
      if (file_name == null)
         return;

      // How to read a text .gko geko.
      GEKOStreamView v = new GEKOStreamView(GEKOStreamView.IN, new File(dir + file_name));
      current_geko = v.input();
      return;
   }

   private void edit_open_xml() throws FrameException, IOException
   {
      KnowledgeFrame kf;
      File f;

      String sub_dir = prompt("Which gekos subdirectory? ");
      String dir = "/KnowledgeArchiver/gekos/" + sub_dir + "/";
      String[] files = (new File(dir)).list(new XMLFilter());
      System.out.println("Open which file? ");
      Vector choices = new Vector();
      for (int i=0; i<files.length; i++)
         choices.addElement(files[i].toString());
      String file_name = string_list_select(choices);
      if (file_name == null)
         return;

      // How to read an XML geko.
      current_geko = KnowledgeFrame.readXML(new File(dir + file_name));
      return;
   }

   /**
   * Save a GEKO in .xml format.
   */
   private void edit_save() throws FrameException, IOException
   {
      String sub_dir = prompt("Which gekos subdirectory? ");
      String dir = "/KnowledgeArchiver/gekos/" + sub_dir + "/";
      System.out.print("What name (.xml will be added)>  ");
      String xmlout = dir + din.readLine() + ".xml";

      // How to save a geko in XML format
      PrintWriter out = new PrintWriter(new FileWriter(xmlout));
      out.print(current_geko.toXMLString());
      out.flush();
   }

   private void edit_show() throws FrameException, IOException
   {
      System.out.println("Select the current frame to show.");
      Vector groups = gekos.get_groups();
      String group_name = string_list_select(groups);
      if (group_name == null)
         return;

      if      (group_name.equals("geko"))
         System.out.println(current_geko.toFullString());
      else if (group_name.equals("person"))
         System.out.println(current_person.toFullString());
      else if (group_name.equals("citation"))
         System.out.println(current_citation.toFullString());
      else if (group_name.equals("keyword"))
         System.out.println(current_keyword.toFullString());
      else if (group_name.equals("variable"))
         System.out.println(current_variable.toFullString());
   }

   private void edit_upload() throws FrameException, IOException
   {
      register_geko(current_geko);
      return;
   }

   /**
   * Register all the gekos in a subdirectory of gekos.
   */
   private void edit_batch() throws FrameException, IOException
   {
      int i;
      //String dir = prompt("Enter full path name for gekos directory: ");
      String sub_dir = prompt("Enter gekos subdirectory: ");
      String dir = "/KnowledgeArchiver/gekos/" + sub_dir + "/";
      String[] files = (new File(dir)).list(new GKOXMLFilter());

      // sort the files by name
      Vector vf = new Vector();
      for (i=0; i<files.length; i++)
         vf.addElement(files[i]);
      Sorter s = new Sorter();
      s.sort(vf);
      for (i=0; i<files.length; i++)
         files[i] = (String)vf.elementAt(i);

      PrintWriter log = new PrintWriter(new FileOutputStream(
            "/KnowledgeArchiver/source/batchlog.txt"),
            true);
      for (i=0; i<files.length; i++)
      {
         try
         {
            System.out.println("Registering: " + files[i].toString());
            log.println("Registering: " + files[i].toString());
            BufferedReader br = new BufferedReader(new FileReader(dir + files[i]));
            String first_line = br.readLine();
            br.close();
            if (first_line.startsWith("<?XML"))
            {
               current_geko = KnowledgeFrame.readXML(new File(dir + files[i]));
            }
            else
            {
               GEKOStreamView v = new GEKOStreamView(GEKOStreamView.IN, new File(dir + files[i]));
               current_geko = v.input();
               v.close();
            }
            register_geko(current_geko);
         }
         catch (Exception e)
         {
            log.println("*** Error: " + e.getMessage());
            System.out.println("*** Error: " + e.getMessage());
         }
      }
      log.close();
      return;
   }

   /**
   * Download a shared frame from the archive.
   */
   private void edit_download() throws FrameException, IOException
   {
      // Get the group names from the archive.
      Vector groups = gekos.get_groups();
      System.out.println("Which group?");
      String group_name = string_list_select(groups);
      if (group_name == null)
         return;

      // Get the particular one of interest.
      Vector v = gekos.get_key_notes(group_name);
      System.out.println("Which one?");
      String key = list_select(v);

      // Retrieve the frame by group and key.
      KnowledgeFrame f = gekos.get_frame(group_name, key);

      if      (group_name.equals("geko")) current_geko = f;
      else if (group_name.equals("person")) current_person = f;
      else if (group_name.equals("citation")) current_citation = f;
      else if (group_name.equals("keyword")) current_keyword = f;
      else if (group_name.equals("variable")) current_variable = f;

      return;
   }

   /**
   * Test the inference downloading parts of the archive.
   */
   private void edit_infer() throws FrameException, IOException
   {
      int i;
      Variable[] vars = gekos.get_variables();
      System.out.println("Inference Variables:");
      for (i=0; i<vars.length; i++)
         System.out.println(vars[i].toString());

      Rule[] rules = gekos.get_rules();
      System.out.println("Inference Rules:");
      for (i=0; i<rules.length; i++)
         System.out.println(rules[i].toString());

      System.out.println("--- end inference dump ---");
   }

   /**
   * Test the query capability.
   */
   private void edit_query() throws FrameException, IOException
   {
      int i;
      KeyNotePair kn;
      Vector v;

      Long t1 = new Long(System.currentTimeMillis());

      KnowledgeFrame p1 = new KnowledgeFrame("person");
      p1.set("Name", "Kato");
      String k1 = gekos.put_frame(p1);

      Long t2 = new Long(System.currentTimeMillis());

      KnowledgeFrame p2 = new KnowledgeFrame("person");
      p2.set("Name", "Ella");
      String k2 = gekos.put_frame(p2);

      Long t3 = new Long(System.currentTimeMillis());

      KnowledgeFrame p3 = new KnowledgeFrame("person");
      p3.set("Name", "Ollie");
      String k3 = gekos.put_frame(p3);

      Long t4 = new Long(System.currentTimeMillis());

      p3 = gekos.get_frame("person", k3);
      p3.set("Name", "Oliver");
      gekos.put_frame(p3);

      QueryFrame qf = new QueryFrame("person");
      qf.set_system("create date", new QueryOp(QueryOp.AFTER, t1) );

      v = gekos.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
         KnowledgeFrame p = gekos.get_frame("person", kn.get_key());
         System.out.println("version = " + p.get_version());
      }
      System.out.println("---");


      p3 = gekos.get_frame("person", k3, 0);
      System.out.println("version 1 = " + (String)p3.get("Name"));
      p3 = gekos.get_frame("person", k3, 1);
      System.out.println("version 2 = " + (String)p3.get("Name"));

      
      gekos.remove_frame(gekos.get_frame("person", k1));
      gekos.remove_frame(gekos.get_frame("person", k2));
      gekos.remove_frame(gekos.get_frame("person", k3));
   }

   /**
   * Does all the work of ensuring that the shared sub-frames of a new
   * GEKO are indeed shared.
   */
   private void register_geko(KnowledgeFrame geko) throws FrameException, IOException
   {
      KnowledgeFrame source, technical, knowledge, author, variable, citation, keyword;
      KnowledgeList ivars, cits, kwords;
      QueryFrame qf;
      String key;
      int i;

      source = (KnowledgeFrame)geko.get("Source Frame");
      author = (KnowledgeFrame)source.get("Author");
      technical = (KnowledgeFrame)current_geko.get("Technical Frame");
      knowledge = (KnowledgeFrame)current_geko.get("Knowledge Frame");

      switch (gekos.check_geko((String)source.get("Title"), current_geko))
      {
      case GEKOClientI.NEW_OK:
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("CANCEL: A GEKO with the same title already exists in the archive");
         return;
      case GEKOClientI.OLD_OK:
         System.out.println("This GEKO has already been uploaded to the archive.");
         String answer = prompt("Continue to update existing copy with this version? (y/n)");
         if (answer.equals("n"))
            return;
         break;
      case GEKOClientI.OLD_MOD:
         System.out.println("CANCEL: This GEKO is an old version of an archive GEKO");
         return;
      }

      switch (gekos.check_author((String)author.get("Name"), author))
      {
      case GEKOClientI.NEW_OK:
         System.out.println("Adding new author");
         //key = gekos.put_frame(author);
         //author = gekos.get_frame("person", key);
         //source.set("Author", author);
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("Using author of same name from archive");
         author = simple_query("person", "Name", (String)author.get("Name"));
         source.set("Author", author);
         break;
      case GEKOClientI.OLD_MOD:
         System.out.println("Using latest version of this author from archive.");
         author = gekos.get_frame("person", author.get_key());
         source.set("Author", author);
         break;
      }

      variable = (KnowledgeFrame)knowledge.get("Dependent Variable");
      switch (gekos.check_variable((String)variable.get("Name"), variable))
      {
      case GEKOClientI.NEW_OK:
         System.out.println("Adding new dependent variable");
         //key = gekos.put_frame(variable);
         //variable = gekos.get_frame("variable", key);
         //knowledge.set("Dependent Variable", variable);
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("Using variable of same name from archive");
         variable = simple_query("variable", "Name", (String)variable.get("Name"));
         knowledge.set("Dependent Variable", variable);
         break;
      case GEKOClientI.OLD_MOD:
         System.out.println("Using latest version of this variable from archive.");
         variable = gekos.get_frame("variable", variable.get_key());
         knowledge.set("Dependent Variable", variable);
         break;
      }

      ivars = (KnowledgeList)knowledge.get("Independent Variables");
      for (i=0; i < ivars.length(); i++)
      {
         KnowledgeSlot s = ivars.slot_at(i);
         variable = (KnowledgeFrame)s.value();
         switch (gekos.check_variable((String)variable.get("Name"), variable))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new independent variable");
            //key = gekos.put_frame(variable);
            //variable = gekos.get_frame("variable", key);
            //s.set_value(variable);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using variable of same name from archive");
            variable = simple_query("variable", "Name", (String)variable.get("Name"));
            s.set_value(variable);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this variable from archive.");
            variable = gekos.get_frame("variable", variable.get_key());
            s.set_value(variable);
            break;
         }
      }

      if (knowledge.slot_exists("Major Controlled Variables"))
      {
         ivars = (KnowledgeList)knowledge.get("Major Controlled Variables");
         for (i=0; i < ivars.length(); i++)
         {
            KnowledgeSlot s = ivars.slot_at(i);
            variable = (KnowledgeFrame)s.value();
            switch (gekos.check_variable((String)variable.get("Name"), variable))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new controlled variable");
               //key = gekos.put_frame(variable);
               //variable = gekos.get_frame("variable", key);
               //s.set_value(variable);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using variable of same name from archive");
               variable = simple_query("variable", "Name", (String)variable.get("Name"));
               s.set_value(variable);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this variable from archive.");
               variable = gekos.get_frame("variable", variable.get_key());
               s.set_value(variable);
               break;
            }
         }
      }

      cits = (KnowledgeList)source.get("Source Citations");
      for (i=0; i < cits.length(); i++)
      {
         KnowledgeSlot s = cits.slot_at(i);
         citation = (KnowledgeFrame)s.value();
         switch (gekos.check_citation((String)citation.get("Body"), citation))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new citation");
            //key = gekos.put_frame(citation);
            //citation = gekos.get_frame("citation", key);
            //s.set_value(citation);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using citation of same name from archive");
            citation = simple_query("citation", "Body", (String)citation.get("Body"));
            s.set_value(citation);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this citation from archive.");
            citation = gekos.get_frame("citation", citation.get_key());
            s.set_value(citation);
            break;
         }
      }

      if (source.slot_exists("Support Citations"))
      {
         cits = (KnowledgeList)source.get("Support Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new citation");
               //key = gekos.put_frame(citation);
               //citation = gekos.get_frame("citation", key);
               //s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using citation of same name from archive");
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this citation from archive.");
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }

      kwords = (KnowledgeList)source.get("Keywords");
      for (i=0; i < kwords.length(); i++)
      {
         KnowledgeSlot s = kwords.slot_at(i);
         keyword = (KnowledgeFrame)s.value();
         switch (gekos.check_keyword((String)keyword.get("word"), keyword))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new keyword");
            //key = gekos.put_frame(keyword);
            //keyword = gekos.get_frame("keyword", key);
            //s.set_value(keyword);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using keyword of same name from archive");
            keyword = simple_query("keyword", "word", (String)keyword.get("word"));
            s.set_value(keyword);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this keyword from archive.");
            keyword = gekos.get_frame("keyword", keyword.get_key());
            s.set_value(keyword);
            break;
         }
      }

      gekos.put_frame(current_geko);
   }

   /* ------------------------------------ */
   /* Use a schema to generate a new frame */

   private KnowledgeFrame read_frame(KnowledgeFrame schema, int dent)
         throws FrameException, IOException
   {
      String group = (String)schema.get("group");
      for (int j=0; j<dent; j++) System.out.print(" ");
      System.out.println("Enter " + group);
      KnowledgeFrame new_frame = new KnowledgeFrame(group);
      KnowledgeList formats = (KnowledgeList)schema.get("formats");
      KnowledgeFrame format;
      KnowledgeSlot new_slot;
      String slot_name;
      String slot_type;
      KnowledgeFrame sub_frame_schema;
      Vector key_note_pairs;
      KeyNotePair kn;
      QueryFrame qf;
      int i;
      for (i = 0; i < formats.length(); i++)
      {
         format = (KnowledgeFrame)formats.slot_at(i).value();
         slot_type = (String)format.get("type");
         slot_name = (String)format.get("slot");
         if (slot_type.equals("text_line"))
         {
            new_frame.set(slot_name, prompt(slot_name + " : ", dent));
         }
         else if (slot_type.equals("text_area"))
         {
            new_frame.set(slot_name, read_area(slot_name, dent));
         }
         else if (slot_type.equals("local_frame"))
         {
            sub_frame_schema = (KnowledgeFrame)format.get("schema");
            new_frame.set( slot_name, read_frame(sub_frame_schema,dent+2) );
         }
         else if (slot_type.equals("global_frame"))
         {
            qf = new QueryFrame("schema");
            qf.set("group", new QueryOp(QueryOp.EQUALS, format.get("schema")));
            key_note_pairs = gekos.query(qf);
            if (key_note_pairs.size() != 1)
               System.out.println("uh oh");
            kn = (KeyNotePair)key_note_pairs.firstElement();
            sub_frame_schema = gekos.get_frame("schema", kn.get_key());
            new_frame.set( slot_name, read_frame(sub_frame_schema,dent+2) );
         }
         else if (slot_type.equals("global_frame_list"))
         {
            qf = new QueryFrame("schema");
            qf.set("group", new QueryOp(QueryOp.EQUALS, format.get("schema")));
            key_note_pairs = gekos.query(qf);
            if (key_note_pairs.size() != 1)
               System.out.println("uh oh");
            kn = (KeyNotePair)key_note_pairs.firstElement();
            sub_frame_schema = gekos.get_frame("schema", kn.get_key());
            new_frame.set( slot_name, read_frame_list(slot_name,sub_frame_schema,dent+2) );
         }
         else if (slot_type.equals("local_frame_list"))
         {
            sub_frame_schema = (KnowledgeFrame)format.get("schema");
            new_frame.set( slot_name, read_frame_list(slot_name,sub_frame_schema,dent+2) );
         }
         else
            System.out.println("unknown slot type: " + slot_type);
      }
      return new_frame;
   }

   private KnowledgeList read_frame_list(String slot_name, KnowledgeFrame schema, int dent)
      throws FrameException, IOException
   {
      KnowledgeList kl = new KnowledgeList();
      KnowledgeFrame f;
      
      String yn = prompt("Add " + slot_name + "(y/n)? ", dent);
      while (yn.equals("y"))
      {
         f = read_frame(schema, dent+2);
         kl.add_slot(new KnowledgeSlot("item", f));
         yn = prompt("Add " + schema.get("group") + "(y/n)? ", dent);
      }

      return kl;
   }

   private String read_area(String prompt, int dent) throws IOException
   {
      for (int j=0; j<dent; j++) System.out.print(" ");
      System.out.println(prompt + " (enter blank line to end):");
      StringBuffer sb = new StringBuffer();
      String line = prompt("> ", dent);
      while (! line.equals(""))
      {
         sb.append(line + "\n");
         line = prompt("> ", dent);
      }
      return sb.toString();
   }

   /* --------- */
   /* Utilities
   /* --------- */

   // Present a numbered list of the notes in a vector of key note pairs,
   // return the key associated with the user selected note.
   private String list_select(Vector list) throws IOException
   {
      int i=1;

      Enumeration e = list.elements();
      while (e.hasMoreElements())
         System.out.println(i++ + ": " + ((KeyNotePair)e.nextElement()).summary());
      System.out.print("\nList Item Number (0 for none)> ");
      i = Integer.parseInt(din.readLine());
      if (i == 0)
         return null;
      else
         return ((KeyNotePair)list.elementAt(i-1)).get_key();
   }

   // Present a numbered list of the strings for the
   // user to select from.
   private String string_list_select(Vector list) throws IOException
   {
      int i=1;

      Enumeration e = list.elements();
      while (e.hasMoreElements())
         System.out.println(i++ + ": " + (String)e.nextElement());
      System.out.print("\nList Item Number (0 for none)> ");
      i = Integer.parseInt(din.readLine());
      if (i == 0)
         return null;
      else
         return (String)list.elementAt(i-1);
   }

   private String prompt(String p) throws IOException
   {
      return prompt(p, 0);
   }

   private String prompt(String p, int dent) throws IOException
   {
      for (int j=0; j<dent; j++) System.out.print(" ");
      System.out.print(p);
      return din.readLine();
   }

   /**
   * Find a knowledge frame based on a query in which a single slot is
   * compared against a single value.  Return just the first if there
   * are multiple solutions.
   */
   private KnowledgeFrame simple_query(String group, String slot_name, String value)
         throws FrameException
   {
      // Create a new query frame for the group.
      QueryFrame qf = new QueryFrame(group);

      // Set a query slot pattern match for the simple equals case.
      qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

      // The query returns a vector of key_note_pairs that
      // satisfy the query.  We'll just take the first one
      // or return null.
      Vector answers = gekos.query(qf);
      if (answers.isEmpty())
         return null;
      
      // Retrieve the desired frame.
      String key = ((KeyNotePair)answers.firstElement()).get_key();
      return gekos.get_frame(group, key);
   }
}