// AmziException.java

package amzi.util;

/**
 * Exception class for Amzi! exceptions.
 *
 * @author  Amzi! inc.
 */
public class AmziException extends Exception
{
   /**
   * Class defining preformatted error messages.
   */
   static class ErrorMsg
   {
      public int number;
      public int type;
      public String msg;

      /**
      * Full argument constructor.
      * @param n - Message number.
      * @param t - Message type.
      * @param m - Message string.
      */
      public ErrorMsg(int n, int t, String m)
      {
         number = n;
         type = t;
         msg = m;
      }
   }

   // Types of errors
   public final static int UNKNOWN  = 0;
   public final static int ABORT    = 1;
   public final static int FATAL    = 2;
   public final static int INTERNAL = 3;
   public final static int ERROR    = 4;

   public final static String[] types =
   {
      "UNKNOWN",
      "ABORT",
      "FATAL",
      "INTERNAL (Contact Amzi!) ",
      "ERROR",
   };

   // Specific errors
   public final static int SOMETHING_WRONG    = 101;

   private static ErrorMsg[] msgs =
   {
      /*101*/ new ErrorMsg(SOMETHING_WRONG, ERROR,
         "Something went wrong."),

      new ErrorMsg(UNKNOWN, UNKNOWN,
         "Unknown Amzi! Error")
   };

   protected String prefix = "";
   protected String msg = "";

   public AmziException()
   {
      msg = "";
      prefix = "";
      //server_info();
   }
   
   /**
    * Constructor for exception with just a preformatted message.
    *
    * @param   i  the identifier of the message
    */
   public AmziException(int i)
   {
      msg = findMsg(i);
      prefix = "";
      //server_info();
   }

   /**
    * Constructor for exception with preformatted message and
    * suffix.
    *
    * @param   i  the identifier of the message
    * @param   suffix  the suffix
    */
   public AmziException(int i, String suffix)
   {
      msg = findMsg(i) + suffix;
      prefix = "";
      //server_info();
   }


   /**
    * Constructor for exception with a custom message.
    *
    * @param   m  the message to be used
    */
   public AmziException(String m)
   {
      msg = msg;
      prefix = "";
      //server_info();
   }

   /**
    * Constructor for exception with a preformatted message
    * and a customized message prefix.
    *
    * @param   c  the message prefix
    * @param   i  the message identifier
    */
   public AmziException(String c, int i)
   {
      msg = findMsg(i);
      prefix = c;
      //server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    */
   public AmziException(Object o, int i)
   {
      msg = findMsg(i);
      prefix = o.getClass().getName();
      //server_info();
   }

   /**
    * Constructor for exception with a custom
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   m  the custom message
    */
   public AmziException(Object o, String m)
   {
      msg = m;
      prefix = o.getClass().getName();
      //server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message, a prefix generated from the class
    * name of the thrower, and additional information.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    * @param   a  additional information
    */
   public AmziException(Object o, int i, String a)
   {
      super();
      msg = findMsg(i) + a;
      prefix = o.getClass().getName();
      //server_info();
   }

   protected String findMsg(int error_number)
   {
      // Just walk down the array looking, as this only
      // happens occasionally, its not such a
      // big deal.
      int i;
      for (i=0; i<msgs.length-1; i++)  // last message is default
      {
         if (msgs[i].number == error_number)
            break;
      }
      return msgs[i].msg;
   }

   public String getMessage()
   {
      return "AmziException " + prefix + ": " + msg;
   }
}
