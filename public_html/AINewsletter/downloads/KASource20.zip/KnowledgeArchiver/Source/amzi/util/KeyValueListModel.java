// KeyValueListModel

package amzi.util;

import java.util.*;
import java.text.*;
import javax.swing.*;

/**
* Maintain a vector of sorted KeyValue pairs for quick
* inserts and initial sort.
*/
public class KeyValueListModel extends AbstractListModel
{
   Vector list = null;

   public KeyValueListModel()
   {
      list = new Vector();
   }

   public KeyValueListModel(Vector v)
   {
      super();
      KeyValue[] kvs = Sort.makeKeyValueArray(v);

      sort_list(kvs);
   }

   public KeyValueListModel(Object[] os)
   {
      super();
      KeyValue[] kvs = Sort.makeKeyValueArray(os);

      sort_list(kvs);
   }

   private void sort_list(KeyValue[] kvs)
   {
      Sort.sort(kvs);
      list = new Vector(kvs.length);
      for (int i=0; i<kvs.length; i++)
         list.addElement(kvs[i]);
   }

   public Object getElementAt(int index)
   {
      return ((KeyValue)list.elementAt(index)).value;
   }

   public int getSize()
   {
      return list.size();
   }

   public void addElement(Object o)
   {
      Collator c = Collator.getInstance();
      CollationKey key = c.getCollationKey(o.toString());
      int i=0;

      if (list.isEmpty())
      {
         list.addElement(new KeyValue(key, o));
      }
      else
      {
         for (i=0; i < list.size(); i++)
         {
            if (key.compareTo(((KeyValue)list.elementAt(i)).key) <= 0)
            {
               list.insertElementAt(new KeyValue(key, o), i);
               break;
            }
         }
      }

      if (i == list.size())
         list.addElement(new KeyValue(key, o));

      fireIntervalAdded(this, i, i);
      //System.out.println("added " + o.toString());
   }

   public void removeElement(Object o)
   {
      Collator c = Collator.getInstance();
      CollationKey key = c.getCollationKey(o.toString());
      int i;

      for (i=0; i < list.size(); i++)
      {
         if (key.compareTo(((KeyValue)list.elementAt(i)).key) == 0)
         {
            list.removeElementAt(i);
            break;
         }
      }

      fireIntervalRemoved(this, i, i);
   }

   public void removeAllElements()
   {
      list.removeAllElements();
      fireIntervalRemoved(this, 1, list.size());
   }
}