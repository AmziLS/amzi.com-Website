// KeyValue.java

package amzi.util;

import java.text.*;

public class KeyValue
{
   CollationKey key;
   Object value;

   KeyValue(CollationKey k, Object v)
   {
      key = k;
      value = v;
   }
}