// Sort.java

package amzi.util;

import java.util.*;
import java.text.*;

public class Sort
{
   /**
   * quick sort, the sort of choice.
   */
   public static void sort(Vector v)
   {
      KeyValue[] kvs = makeKeyValueArray(v);
      quick_sort(kvs, 0, kvs.length-1);
      int i;

      for (i=0; i<kvs.length-1; i++)
         v.setElementAt(kvs[i].value, i);
   }

   /**
   * Create an array of KeyValue pairs from the vector.
   * The keys of KeyValue pairs are the collation keys
   * for the string value.
   */
   public static KeyValue[] makeKeyValueArray(Vector v)
   {
      Collator c = Collator.getInstance();
      int size = v.size();
      int i;
      Object o;
      KeyValue[] kvs = new KeyValue[size];
      KeyValue kv;

      for (i=0; i<size; i++)
      {
         o = v.elementAt(i);
         kvs[i] = new KeyValue(c.getCollationKey(o.toString()), o);
      }

      return kvs;
   }

   public static KeyValue[] makeKeyValueArray(Object[] os)
   {
      Collator c = Collator.getInstance();
      int size = os.length;
      int i;
      Object o;
      KeyValue[] kvs = new KeyValue[size];
      KeyValue kv;

      for (i=0; i<size; i++)
      {
         o = os[i];
         kvs[i] = new KeyValue(c.getCollationKey(o.toString()), o);
      }

      return kvs;
   }

   public static void sort(KeyValue[] kvs)
   {
      quick_sort(kvs, 0, kvs.length-1);
   }

   private static void quick_sort(KeyValue[] kvs, int begin, int end)
   {
      if ((end-begin) < 5)
      {
         key_bubble(kvs, begin, end);
         return;
      }

      int i = begin+1;
      int j = end;

      KeyValue kv;

      while (i<j)
      {
         for ( ; i<=end; i++)
            if (kvs[i].key.compareTo(kvs[begin].key) > 0)
               break;

         for ( ; j>=begin; j--)
            if (kvs[j].key.compareTo(kvs[begin].key) <= 0)
               break;

         if (i < j)
         {
            kv = kvs[i];
            kvs[i] = kvs[j];
            kvs[j] = kv;
         }
      }
      kv = kvs[begin];
      kvs[begin] = kvs[j];
      kvs[j] = kv;

      quick_sort(kvs, begin, j-1);
      quick_sort(kvs, j+1, end);
   }

   /**
   * A bubble sort using collation keys, called when quick_sort
   * gets close.
   */
   private static void key_bubble(KeyValue[] kvs, int begin, int end)
   {
      KeyValue kv;
      int i;
      boolean swap = true;
      while (swap)
      {
         swap = false;
         for (i=begin; i<=end-1; i++)
         {
            if ( kvs[i].key.compareTo(kvs[i+1].key) > 0 )
            {
               kv = kvs[i];
               kvs[i] = kvs[i+1];
               kvs[i+1] = kv;
               swap = true;
            }
         }
      }
   }

   //-----------------------------------------------
   // Other sorts for reference on use of collators
   //

   /**
   * Sort a vector using the toString() method for each of its
   * elements.
   * @param v The vector to sort.
   */
   public static void string_bubble(Vector v)
   {
      // Use default Collator for this locale.
      Collator c = Collator.getInstance();

      Object o;
      boolean swap = true;
      while (swap)
      {
         swap = false;
         for (int i=0; i<v.size()-1; i++)
         {
            if ( c.compare(v.elementAt(i).toString(), v.elementAt(i+1).toString()) > 0 )
            {
               o = v.elementAt(i);
               v.setElementAt(v.elementAt(i+1), i);
               v.setElementAt(o, i+1);
               swap = true;
            }
         }
      }
   }

   /**
   * A bubble sort using collation keys.
   */
   public static void key_bubble(Vector v)
   {
      Collator c = Collator.getInstance();
      int size = v.size();
      int i;
      Object o;
      KeyValue[] kvs = new KeyValue[size];
      KeyValue kv;
      
      for (i=0; i<size; i++)
      {
         o = v.elementAt(i);
         kvs[i] = new KeyValue(c.getCollationKey(o.toString()), o);
      }

      boolean swap = true;
      while (swap)
      {
         swap = false;
         for (i=0; i<size-1; i++)
         {
            if ( kvs[i].key.compareTo(kvs[i+1].key) > 0 )
            {
               kv = kvs[i];
               kvs[i] = kvs[i+1];
               kvs[i+1] = kv;
               swap = true;
            }
         }
      }

      for (i=0; i<size; i++)
         v.setElementAt(kvs[i].value, i);
   }

   /**
   * A simple insertion sort using keys.
   */
   public static void key_insert(Vector v)
   {
      Collator c = Collator.getInstance();
      int size = v.size();
      int i, j;
      Object o;
      KeyValue[] kvs = new KeyValue[size];
      KeyValue kv;
      
      for (i=0; i<size; i++)
      {
         o = v.elementAt(i);
         kv = new KeyValue(c.getCollationKey(o.toString()), o);
         for (j=0; j<i; j++)
         {
            if (kv.key.compareTo(kvs[j].key) <= 0)
            {
               System.arraycopy(kvs, j, kvs, j+1, i-j);
               kvs[j] = kv;
               break;
            }
         }
         if (i == j)
            kvs[i] = kv;
      }

      for (i=0; i<size; i++)
         v.setElementAt(kvs[i].value, i);
   }
}

