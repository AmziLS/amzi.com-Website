// AttrValueListModel

package amzi.util;

import java.util.*;
import java.text.*;
import javax.swing.*;

/**
* Maintain a list model of Strings of the form
* attr = value, and have it so there is only one
* attr in the list.  New 'add's get put at the
* beginning, old ones removed when new added.
* So the effect is the topmost are the most recently
* set.
*/
public class AttrValueListModel extends AbstractListModel
{
   Vector list = null;

   public AttrValueListModel()
   {
      list = new Vector();
   }

   public AttrValueListModel(Vector v)
   {
      super();
      list = v;
   }

   public Object getElementAt(int index)
   {
      return list.elementAt(index);
   }

   public int getSize()
   {
      return list.size();
   }

   public void addElement(Object o)
   {
      String s = (String)o;
      int ix = s.indexOf(" = ");
      String a = s.substring(0, ix);
      String v = s.substring(ix+3);
      addElement(a,v);
   }

   public void addElement(String a, Object o)
   {
      removeElement(a);
      list.insertElementAt(a + " = " + o.toString(), 0);

      fireIntervalAdded(this, 1, list.size());
   }

   public void removeElement(Object o)
   {
      String a = (String)o;

      int i;
      for (i=0; i<list.size(); i++)
      {
         if ( ((String)list.elementAt(i)).startsWith(a) )
            break;
      }

      if (i < list.size())
      {
         list.removeElementAt(i);
         fireIntervalRemoved(this, i+1, list.size());
      }
   }

   public void removeAllElements()
   {
      list.removeAllElements();
      fireIntervalRemoved(this, 1, list.size());
   }
}