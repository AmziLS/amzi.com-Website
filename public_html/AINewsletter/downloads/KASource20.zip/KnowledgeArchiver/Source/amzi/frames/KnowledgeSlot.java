// KnowledgeSlot.java

package amzi.frames;

import java.util.*;
import java.io.*;

/**
* The elemental slot which is stored in KnowledgeFrames.
*/
public class KnowledgeSlot implements Serializable
{
   // Static class identifiers used for identifying slot
   // contents.

   static Class frame_class;
   static Class list_class;
   static Class cLong;
   static Class cShort;
   static Class cFloat;
   static Class cString;
   static Class cDouble;
   static Class cInteger;
   static Class cBoolean;

   static
   {
      try
      {
         list_class = Class.forName("amzi.frames.KnowledgeList");
         frame_class = Class.forName("amzi.frames.KnowledgeFrame");
         cLong = Class.forName("java.lang.Long");
         cShort = Class.forName("java.lang.Short");
         cFloat = Class.forName("java.lang.Float");
         cString = Class.forName("java.lang.String");
         cDouble = Class.forName("java.lang.Double");
         cInteger = Class.forName("java.lang.Integer");
         cBoolean = Class.forName("java.lang.Boolean");
      }
      catch (Exception e)
      {}
   }

   // The internal state of a slot.

   String name;
   Object value;

   // Constructors

   public KnowledgeSlot()
   {
      name = "item";
      value = null;
   }

   public KnowledgeSlot(String name)
   {
      this.name = name;
      this.value = null;
   }

   public KnowledgeSlot(String name, Object value)
   {
      this.name = name;
      this.value = value;
   }

   // Implement the KnowledgeSlot interface

   /**
   * Get the name of this slot.
   * @return The name.
   */
   public String name() { return name; }

   /**
   * Get the value of this slot.
   * @return The value.
   */
   public Object value() { return value; }

   /**
   * Change the value of this slot.
   * @param v The new value.
   */
   public void set_value(Object v) { value = v; }

   /**
   * If this slot's value is a KnowledgeList, add
   * this slot to the list.
   * @param s The slot to add.
   * @throws FrameException if the slot is not a list.
   */
   public void add_value(KnowledgeSlot s) throws FrameException
   {
      if (is_list())
         ((KnowledgeList)value).add_slot(s);
      else
         throw new FrameException(this, FrameException.NOT_A_LIST_SLOT, name);
   }

   /**
   * Is the value a KnowledgeFrame.
   * @return true if value is a frame, otherwise false.
   */
   public boolean is_frame()
   {
      if (value.getClass() == frame_class)
         return true;
      else
         return false;
   }

   /**
   * Is the value a KnowledgeList.
   * @return true if value is a list, otherwise false.
   */
   public boolean is_list()
   {
      if (value.getClass() == list_class)
         return true;
      else
         return false;
   }

   /**
   * Return a summary string suitable for presentation in a GUI. The
   * string is just an identification, and is not intended to be a full
   * dump of the contents of the slot, which might be KnowledgeFrame
   * or KnowledgeList.
   * @return The summary string.
   * @throws A FrameException if there is a problem getting the summary.
   */
   public String summary() throws FrameException
   {
      if (is_frame())
         return ((KnowledgeFrame)value).summary();
      else if (is_list())
         return "";
      else
         return value.toString();
   }

   /**
   * An implementation of toString that returns the summary
   * string for this slot.
   * @return The summary string, or null if an error occurred
   * getting it.
   */
   public String toString()
   {
      try
      {
         return name + ": " + summary();
      }
      catch (FrameException e)
      {
         return null;
      }
   }

   /**
   * Slots are equal if their names and values are equal.
   */
   public boolean same_contents(KnowledgeSlot s) throws FrameException
   {
      if ( ! name().equals(s.name()) )
         return false;

      if (is_frame() && s.is_frame())
      {
         if ( ((KnowledgeFrame)value()).same_contents((KnowledgeFrame)s.value()) )
            return true;
         else
            return false;
      }

      if (is_list() && s.is_list())
      {
         if ( ((KnowledgeList)value()).same_contents((KnowledgeList)s.value()) )
            return true;
         else
            return false;
      }

      if ( (!is_frame() && !is_list()) && (!s.is_frame() && !s.is_list()) )
      {
         if ( value().equals(s.value()) )
            return true;
         else
            return false;
      }

      return false;
   }

   /**
   * Return a fully indented string suitbable for displaying the
   * contents of the slot.  This routine is part of a recursive
   * set of similar calls in KnowledgeFrame and KnowledgeList.
   * @param indent The amount of space to indent on an output line.
   * @return The string.
   */
   public String toFullString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer();
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append(name + ": ");

      if (is_list())
         sb.append( ((KnowledgeList)value).toFullString(indent+1) );
      else if (is_frame())
         sb.append( ((KnowledgeFrame)value).toFullString(indent+1) );
      else
         sb.append( value.toString() );

      return sb.toString();
   }

   /**
   * A starting position for toFullString(int).
   */
   public String toFullString() throws FrameException
   {
      return toFullString(0);
   }

   /**
   * Return a tagged string suitbable for dumping and reloading
   * Knowledge objects.
   * @param indent Indentation for readability
   * @return The string.
   */
   public String toTaggedString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer();
      int k;
      String jtype = null;
      String katype = null;
      Class c = null;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("<Slot name=\"" + name + "\">");

      if (is_list())
         sb.append( ((KnowledgeList)value).toTaggedString(indent+1) );
      else if (is_frame())
         sb.append( ((KnowledgeFrame)value).toTaggedString(indent+1) );
      else
      {
         c = value.getClass();
         //jtype = value.getClass().getName();
         katype = null;
         if      (c == cLong)  katype = "Long";
         else if (c == cShort)  katype = "Short";
         else if (c == cFloat)  katype = "Float";
         else if (c == cString)  katype = "String";
         else if (c == cDouble)  katype = "Double";
         else if (c == cInteger)  katype = "Integer";
         else if (c == cBoolean)  katype = "Boolean";

         if (katype != null)
         {
            sb.append("<" + katype + ">");
            sb.append(toXML(value.toString()));
            sb.append("</" + katype + ">");
         }
         else
         {
            jtype = value.getClass().getName();
            sb.append("<JavaClass type=\"" + jtype + "\">");
            sb.append(toXML(value.toString()));
            sb.append("</JavaClass>");
         }
      }

      sb.append("</Slot>");
      return sb.toString();
   }

   /**
   * A starting position for toFullString(int).
   */
   public String toTaggedString() throws FrameException
   {
      return toTaggedString(0);
   }

   /**
   * Replace < and > with &GT and &LT for XML output.
   * Also note that ampersands, less thans, greater thans,
   * apostophres and quotes all need to be represented
   * in the data as &amp; &lt; &gt; &apos; &quot;
   */
   private String toXML(String in)
   {
      StringBuffer out = new StringBuffer("");
      for (int i=0; i<in.length(); i++)
      {
         char c = in.charAt(i);
         switch (c)
         {
         case '&':
            out.append("&amp;"); break;
         case '<':
            out.append("&lt;"); break;
         case '>':
            out.append("&gt;"); break;
         case '\'':
            out.append("&apos;"); break;
         case '\"':
            out.append("&quot;"); break;
         default:
            out.append(c);
         }
      }
      return out.toString();
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}
