// PSEGroup.java

package amzi.frames.pse;

import amzi.frames.*;
import java.util.*;
import COM.odi.*;
import COM.odi.util.*;

class PSEGroup
{
   String group;
   OSHashtable frames;
   int next_key;

   static transient Class cPSEVersions;
   static transient Class cPSEFrame;

   static
   {
      try
      {
         cPSEVersions = Class.forName("amzi.frames.pse.PSEVersions");
         cPSEFrame = Class.forName("amzi.frames.pse.PSEFrame");
         //System.out.println("PSEGroup statics initialized");
         //System.out.println(cPSEVersions.getName());
         //System.out.println(cPSEFrame.getName());
      }
      catch (Exception e)
      {
         System.out.println("Error during PSEGroup static initialization: " +
            e.getMessage());
      }
   }

   /**
   * Construct a new KnowledgeGroup with the given
   * group name, a starting key number, and a clean
   * hash table.
   */
   public PSEGroup(String group)
   {
      this.group = group;
      next_key = 1001;
      frames = new OSHashtable();
   }

   /**
   * Puts a frame in this frame group, creating a new key
   * if necessary, or else adding a version of the frame at the
   * frame's existing key.
   */
   public String put_frame(PSEFrame f) throws FrameException
   {
      if (f.get_key() == null)
         return add_frame(f);
      else
         return update_frame(f);
   }

   /**
   * Remove a frame in this frame group.
   */
   public void remove_frame(PSEFrame f) throws FrameException
   {
      if (f.get_key() == null)
         throw new FrameException(FrameException.FRAME_NOT_ARCHIVED);

      frames.remove(f.get_key());
   }

   /**
   * Adds a frame version control object in this frame group.
   */
   public String add_frame(PSEFrame f) throws FrameException
   {
      if (f.get_key() != null)
         throw new FrameException(FrameException.FRAME_ALREADY_EXISTS);

      f.set_key(group + next_key++);
      f.set_system("version", new Integer(1));
      PSEVersions v = new PSEVersions();
      v.add_version(f);

      frames.put(f.get_key(), v);
      return f.get_key();
   }

   /**
   * Puts a frame in this frame group, creating a new key
   * if necessary, or else replacing the frame at the
   * frame's existing key.
   */
   public String update_frame(PSEFrame f) throws FrameException
   {
      if (f.get_key() == null)
         throw new FrameException(FrameException.FRAME_NOT_ARCHIVED);

      PSEVersions v = (PSEVersions)frames.get(f.get_key());
      v.add_version(f);
      frames.put(f.get_key(), v);
      return f.get_key();
   }

   /**
   * Get a frame from the group dictionary based on its
   * key.
   * @return A KnowledgeFrame.
   */
   public PSEFrame get_frame(String key) throws FrameException
   {
      PSEFrame f;
      Object o = frames.get(key);
      if (o == null)
         //throw new FrameException(FrameException.MISSING_KEY, key);
         return null;
      if (o.getClass() == cPSEVersions)
         f = ((PSEVersions)o).current_version();
      else
         f = (PSEFrame)o;
      return f;
   }

   /**
   * Get a frame from the group dictionary based on its
   * key.
   * @return A KnowledgeFrame.
   */
   public PSEFrame get_frame(String key, int version) throws FrameException
   {
      if (version == 0)
         return get_frame(key);

      PSEVersions v = (PSEVersions)frames.get(key);
      if (v == null)
         throw new FrameException(FrameException.MISSING_KEY, key);
      return v.get_version(version);
   }

   /**
   * Return a vector of pairs of frame keys and a representative
   * slot value from the frame.  Use the first slot of each
   * frame for the default note.
   * @return  A vector of pairs.
   */
   public Vector get_key_notes() throws FrameException
   {
      Vector v = new Vector(5,5);
      Enumeration e = frames.elements();
      PSEFrame f;

      while (e.hasMoreElements())
      {
         Object o = e.nextElement();
         if (o != null)
         {
            if (o.getClass() == cPSEVersions)
            {
               f = ((PSEVersions)o).current_version();
            }
            else
            {
               f = (PSEFrame)o;
            }

            v.addElement( new KeyNotePair(f.get_key(), f.summary() ) );
         }
      }
      return v;
   }

   public Enumeration elements()
   {
      return frames.elements();
   }

   public Enumeration get_keys()
   {
      return frames.keys();
   }
}
