// PSEList.java

package amzi.frames.pse;

import amzi.frames.*;
import java.util.*;
import COM.odi.*;
import COM.odi.util.*;

/**
* An implementation of a KnowledgeList using
* Java vectors.
*/
class PSEList
{
   private OSVector slots;

   PSEList(KnowledgeList kl) throws FrameException
   {
      slots = new OSVector();
      for (int i=0; i<kl.length(); i++)
         slots.addElement( new PSESlot(kl.slot_at(i)) );
   }

   KnowledgeList make_KnowledgeList() throws FrameException
   {
      KnowledgeList kl = new KnowledgeList();
      for (int i=0; i<slots.size(); i++)
         kl.add_slot( ((PSESlot)slots.elementAt(i)).make_KnowledgeSlot() );
      return kl;
   }


   /**
   * Create a new KnowledgeList initializing the internal
   * vector according to the parameters.
   * @param initial_size The initial size of the vector.
   * @param growth_increment How much it grows by.
   */
   public PSEList(int initial_size, int growth_increment)
   {
      slots = new OSVector();
   }

   /**
   * Create a new KnowledgeList with an internal vector
   * with default size of 5,5.
   */
   public PSEList()
   {
      slots = new OSVector();
   }

   /**
   * Add a slot to the end of the list.
   * @param s The knowledge slot to add.
   */
   void add_slot(PSESlot s)
   { slots.addElement(s); }

   /**
   * Get the slot at a given position in the list.
   * @param i The 0-based position.
   * @return The slot at that position.
   */
   PSESlot slot_at(int i)
   { return (PSESlot)slots.elementAt(i); }

   /**
   * Set a slot at a particular position.
   * @param i The position.
   * @param s The slot to put at that position.
   */
   void set_slot_at(int i, PSESlot s)
   { slots.setElementAt(s, i); }

   /**
   * Remove the slot at position i.
   * @param i The position of the slot to remove.
   */
   void remove_slot_at(int i)
   { slots.removeElementAt(i); }

   /**
   * Get the length of the list.
   * @return The length.
   */
   int length()
   { return slots.size(); }

   /**
   * Get an enumeration for the list.
   * @return The enumeration.
   */
   Enumeration elements()
   { return slots.elements(); }

   /**
   * Dump the contents of a list into a string for printing.
   * @return The string.
   */
   String toFullString() throws FrameException
   {
      return toFullString(0);
   }

   String toFullString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      for (int i=0; i < length(); i++)
         sb.append( slot_at(i).toFullString(indent) );

      return sb.toString();
   }

   /**
   * Dump the contents of a list into a tagged string for easy
   * parsing.
   * @return The string.
   */
   String toTaggedString() throws FrameException
   {
      return toTaggedString(0);
   }

   String toTaggedString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("<List>");
      for (int j=0; j < length(); j++)
      {
         sb.append("\n"); for (k=0; k<indent+1; k++) sb.append("  ");
         sb.append("<ListItem>");
         sb.append( slot_at(j).toTaggedString(indent+1) );
         sb.append("</ListItem>");
      }
      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("</List>");
      return sb.toString();
   }
}