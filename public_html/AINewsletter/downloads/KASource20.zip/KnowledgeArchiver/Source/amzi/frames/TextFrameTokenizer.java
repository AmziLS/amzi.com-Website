// TextFrameTokenizer

package amzi.frames;

import java.io.*;
import java.util.*;

/**
* Returns frame tokens, either slots or values, while
* reading a formatted frame text file.
*/
public class TextFrameTokenizer
{
   // Tokenizer returns
   final static int END = 0;
   final static int VALUE = 1;
   final static int SLOT = 2;

   private StreamTokenizer in;
   private LineNumberReader inline;
   private String file_name;
   private int line_number;

   int type;
   SchemaSlot slot;
   String value;

   // Maintaining state of tokenizer
   private boolean pushed_back;
   private boolean expecting_value;

   public TextFrameTokenizer(String file)
   {
      initialize_file(file);
   }
   
   /**
   * Initializes a StreamTokenizer for reading frames.
   * @param file - The input file for the frame.
   */
   private void initialize_file(String file) throws IOException
   {
      file_name = f;
      inline = new LineNumberReader(new FileReader(file_name));
      in = new StreamTokenizer(inline);
      in.resetSyntax();
      in.wordChars(0, 255);
      in.ordinaryChar('/');
      in.ordinaryChar('*');
      in.slashStarComments(true);
      in.ordinaryChar(':');
      in.ordinaryChar(';');

      expecting_value = false;
      pushed_back = false;
   }

   public void close() throws IOException
   {
      inline.close();
   }

   public String get_file_info()
   {
      // return file information for error messages
      return " " + file_name + "[" + inline.getLineNumber() + "]";
   }

   public void push_back()
   {
      pushed_back = true;
   }

   /**
   * Reads a frame token from the input stream.  The token
   * is stored in toekn_schema_slot or token_string_value
   * depending on token type.
   * @param   schema - The schema to use looking for a token.
   * @returns  int - The type of token read.
   */
   public int nextToken(ASchema schema) throws KAException
   {
      if (pushed_back)
      {
         pushed_back = false;
         return token_type;
      }

      StringBuffer buffer = new StringBuffer();
      String key;
      boolean done = false;
      int next_token;

      try
      {
         while (! done)
         {
            in.nextToken();
            switch(in.ttype)
            {
            case StreamTokenizer.TT_EOF:
               token_type = END;
               done = true;
               break;
            case StreamTokenizer.TT_WORD:
               buffer.append(in.sval);
               break;
            case '/':
            case '*':
               // Put these comment characters back in as they
               // are found.
               buffer.append((char)in.ttype);
               break;
            case ':':
               if (expecting_value)
                  buffer.append(':');
               else
               {
                  key = buffer.toString().trim();
                  // we're at the end of this frame if the slot isn't in
                  // the schema
                  if (! schema.slot_exists(key))
                  {
                     token_type = END;
                     pushed_back = true;
                     done = true;
                  }
                  else
                  {
                     slot = (SchemaSlot)schema.get_slot(key);

                     switch(token_schema_slot.get_type())
                     {
                     case SchemaSlot.STRING:
                        expecting_value = true;
                        break;
                     case SchemaSlot.FRAME:
                     case SchemaSlot.VECTOR:
                        expecting_value = false;
                        break;
                     default:
                        throw new AFrameException(this,
                           AFrameException.UNKNOWN_SLOT_NAME,
                           key + get_file_info());
                     }
                  token_type = SLOT;
                  done = true;
                  }
               }
               break;
            case ';':
               if (! expecting_value)
                  throw new KAException(this,
                     KAException.TEXT_UNEXPECTED_SEMICOLON,
                     get_file_info());
               else
               // A ;; ends the value, but there might be
               // single ; as part of the text.
               {
                  if (';' == (next_token = in.nextToken()))
                  {
                     token_type = STRING;
                     token_string_value = buffer.toString();
                     expecting_value = false;
                     done = true;
                  }
                  else
                     buffer.append(':' + in.sval);
               }
               break;

            default:
               throw new AFrameException(this,
                  AFrameException.TEXT_PARSE_ERROR,
                  get_file_info());
            }
         }
      }
      catch (IOException e)
      {
         throw new AFrameException(this,
            AFrameException.IO_ERROR,
            get_file_info() + e.toString());
      }
      return token_type;
   }
}
