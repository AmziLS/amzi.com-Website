// PSEVersions.java

package amzi.frames.pse;

import amzi.frames.*;
import java.util.*;
import COM.odi.*;
import COM.odi.util.*;

/**
* FrameVersion provides version control for
* frames stored in the archive.
*/
class PSEVersions
{
   OSVector versions;

   PSEVersions()
   {
      versions = new OSVector();
   }

   void add_version(PSEFrame f) throws FrameException
   {
      f.set_system( "version", new Integer(versions.size()+1) );
      f.set_system( "update date", new Long(System.currentTimeMillis()) );
      versions.addElement(f);
   }

   PSEFrame current_version()
   {
      return (PSEFrame)versions.lastElement();
   }

   PSEFrame get_version(int v) throws FrameException
   {
      if (v >= versions.size())
         throw new FrameException(FrameException.NO_SUCH_VERSION);

      return (PSEFrame)versions.elementAt(v-1);
   }

   int count()
   {
      return versions.size();
   }
}