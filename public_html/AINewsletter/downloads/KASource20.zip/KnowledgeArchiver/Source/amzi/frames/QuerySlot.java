// QuerySlot

package amzi.frames;

import java.io.*;
import java.util.*;

/**
* A pattern to be used in a slot of a query frame.  It
* contains an operator and a value to compare against
* the value in the slot of the frame in question.
* @author  Amzi! inc.
*/
public class QuerySlot implements Serializable
{
   public String name;
   public QueryOp query_op;

   public QuerySlot(String name, QueryOp query_op)
   {
      this.name = name;
      this.query_op = query_op;
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}