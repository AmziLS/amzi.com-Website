// FrameException.java

package amzi.frames;

/**
 * Exception class for Amzi! frame exceptions.
 *
 * @author  Amzi! inc.
 */
public class FrameException extends Exception
{
   /**
   * Class defining preformatted error messages.
   */
   static class ErrorMsg
   {
      public int number;
      public int type;
      public String msg;

      /**
      * Full argument constructor.
      * @param n - Message number.
      * @param t - Message type.
      * @param m - Message string.
      */
      public ErrorMsg(int n, int t, String m)
      {
         number = n;
         type = t;
         msg = m;
      }
   }

   // Types of errors
   public final static int UNKNOWN  = 0;
   public final static int ABORT    = 1;
   public final static int FATAL    = 2;
   public final static int INTERNAL = 3;
   public final static int ERROR    = 4;

   // I/O Errors 101-199
   public final static int UNKNOWN_SLOT_NAME    = 101;
   public final static int IO_ERROR             = 102;
   public final static int TEXT_PARSE_ERROR     = 103;
   public final static int MISSING_GROUP        = 104;
   public final static int INITIALIZATION       = 105;
   public final static int NO_SUCH_FILE         = 106;
   public final static int XML_PARSE            = 107;

   // Query Errors 201-299
   public final static int INVALID_GROUP_QUERY  = 201;
   public final static int INVALID_QUERY        = 202;
   public final static int NULL_SLOTS           = 203;

   // Frame Access Errors 301-399
   public final static int NOT_A_LIST_SLOT      = 301;
   public final static int FRAME_ALREADY_EXISTS = 302;
   public final static int FRAME_NOT_ARCHIVED   = 303;
   public final static int NO_SUCH_VERSION      = 304;
   public final static int NO_SCHEMA            = 305;
   public final static int MISSING_KEY          = 306;

   // Errors using Object Store database 500-599
   public final static int OS_ERROR                  =  500;
   public final static int OS_NOT_INITIALIZED        =  501;
   public final static int OS_MISSING_DATABASE       =  502;
   public final static int OS_OPEN_TRANSACTION       =  503;

   // Network errors 600-699
   public final static int REMOTE_EXCEPTION          =  600;

   protected boolean dump_exceptions = false;

   private static ErrorMsg[] msgs =
   {
      /*101*/ new ErrorMsg(UNKNOWN_SLOT_NAME, ERROR,
         "Unknown slot name: "),
      /*102*/ new ErrorMsg(IO_ERROR, ERROR,
         "Java IO Error: "),
      /*103*/ new ErrorMsg(TEXT_PARSE_ERROR, ERROR,
         "State of confusion reached while parsing input file: "),
      /*104*/ new ErrorMsg(MISSING_GROUP, ERROR,
         "Missing group in KnowledgeLibrary: "),
      /*105*/ new ErrorMsg(INITIALIZATION, ERROR,
         "Error initializing KnowledgeLibrary: "),
      /*106*/ new ErrorMsg(NO_SUCH_FILE, ERROR,
         "Can't find file: "),
      /*107*/ new ErrorMsg(XML_PARSE, ERROR,
         "Error parsing XML input file: "),

      /*201*/ new ErrorMsg(INVALID_GROUP_QUERY, ERROR,
         "Invalid query operator specified for frame group field. "),
      /*202*/ new ErrorMsg(INVALID_QUERY, ERROR,
         "Invalid query operator specified. "),
      /*203*/ new ErrorMsg(NULL_SLOTS, ERROR,
         "This stub group was accessed by mistake: "),

      /*301*/ new ErrorMsg(NOT_A_LIST_SLOT, ERROR,
         "This slot was incorrectly used as a list: "),
      /*302*/ new ErrorMsg(FRAME_ALREADY_EXISTS, ERROR,
         "Attempt to add a frame to archive that already is archived."),
      /*303*/ new ErrorMsg(FRAME_NOT_ARCHIVED, ERROR,
         "Attempt to update a frame in archive that has not been archived."),
      /*304*/ new ErrorMsg(NO_SUCH_VERSION, ERROR,
         "Attempt to retrieve a frame version that doesn't exist"),
      /*305*/ new ErrorMsg(NO_SCHEMA, ERROR,
         "Error trying to access schema for frame group: "),
      /*306*/ new ErrorMsg(MISSING_KEY, ERROR,
         "Attempt to access missing element in archive: "),

      /*500*/ new ErrorMsg(OS_ERROR, ERROR,
         "Object Store error: "),
      /*501*/ new ErrorMsg(OS_NOT_INITIALIZED, ERROR,
         "Unable to initialize Object Store"),
      /*502*/ new ErrorMsg(OS_MISSING_DATABASE, ERROR,
         "Missing Object Store database: "),
      /*503*/ new ErrorMsg(OS_OPEN_TRANSACTION, ERROR,
         "Attempt to start an Object Store transaction when one is already in progress"),

      /*600*/ new ErrorMsg(REMOTE_EXCEPTION, ERROR,
         "Remote exception occurred: "),

      new ErrorMsg(UNKNOWN, UNKNOWN,
         "Unknown Knowledge Frame Error")
   };

   protected String prefix = "";
   protected String msg = "";
   protected int error_number = 0;

   public FrameException()
   {
      msg = "";
      prefix = "";
      error_number = 0;
      server_info();
   }
   
   /**
    * Constructor for exception with just a preformatted message.
    *
    * @param   i  the identifier of the message
    */
   public FrameException(int i)
   {
      msg = findMsg(i);
      prefix = "";
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with preformatted message and
    * suffix.
    *
    * @param   i  the identifier of the message
    * @param   suffix  the suffix
    */
   public FrameException(int i, String suffix)
   {
      msg = findMsg(i) + suffix;
      prefix = "";
      error_number = i;
      server_info();
   }


   /**
    * Constructor for exception with a custom message.
    *
    * @param   m  the message to be used
    */
   public FrameException(String m)
   {
      msg = msg;
      prefix = "";
      error_number = 0;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted message
    * and a customized message prefix.
    *
    * @param   c  the message prefix
    * @param   i  the message identifier
    */
   public FrameException(String c, int i)
   {
      msg = findMsg(i);
      prefix = c;
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    */
   public FrameException(Object o, int i)
   {
      msg = findMsg(i);
      prefix = o.getClass().getName();
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with a custom
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   m  the custom message
    */
   public FrameException(Object o, String m)
   {
      msg = m;
      prefix = o.getClass().getName();
      error_number = 0;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message, a prefix generated from the class
    * name of the thrower, and additional information.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    * @param   a  additional information
    */
   public FrameException(Object o, int i, String a)
   {
      super();
      msg = findMsg(i) + a;
      prefix = o.getClass().getName();
      error_number = i;
      server_info();
   }

   /**
   * Provide information on the exception for the server.
   */
   protected void server_info()
   {
      if (dump_exceptions)
      {
         System.out.println();
         System.out.println("***** Creating FrameException *****");
         System.out.println("  prefix = " + prefix);
         System.out.println("  msg = " + msg);
         System.out.println("Stack Trace:");
         Thread.currentThread().dumpStack();
         System.out.println("***** Exception created *****");
         System.out.println();
      }
   }

   protected String findMsg(int error_number)
   {
      // Just walk down the array looking, as this only
      // happens occasionally, its not such a
      // big deal.
      int i;
      for (i=0; i<msgs.length-1; i++)  // last message is default
      {
         if (msgs[i].number == error_number)
            break;
      }
      return msgs[i].msg;
   }

   public int get_error_number() { return error_number; }

   public String getMessage()
   {
      //return "KAException #" + error_number + " " + prefix + ": " + msg;
      return "Error #KF" + error_number + ": " + msg;
   }
}
