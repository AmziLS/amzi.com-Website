// MiniLL.java

import java.io.*;
import java.net.*;

public class MiniLL
{
   BufferedReader din;

   public static void main(String[] args) throws Exception
   {
      MiniLL app = new MiniLL();
      app.go();
   }

   MiniLL()
   {
      din = new BufferedReader(new InputStreamReader(System.in));
   }

   void go() throws Exception
   {
      String host;
      String port;
      String proxy_host;
      String proxy_port;

      BufferedReader din = new BufferedReader(new InputStreamReader(System.in));
      if ( prompt("use proxy (y/n)? ").equals("y") )
      {
         proxy_host = prompt("proxy host address: ");
         proxy_port = prompt("proxy port: ");
         System.getProperties().put( "proxySet", "true" );
         System.getProperties().put( "proxyHost", proxy_host );
         System.getProperties().put( "proxyPort", proxy_port );
      }
      host = prompt("host address: ");
      port = prompt("port: ");

      Socket sock = new Socket(InetAddress.getByName(host), Integer.parseInt(port));
   }

   String prompt(String text) throws Exception
   {
      System.out.print(text);
      return din.readLine();
   }
}

