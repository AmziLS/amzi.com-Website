// KnowledgeLibraryI_PSE.java

package amzi.frames.pse;

import amzi.frames.*;
import java.util.*;
import COM.odi.*;
import COM.odi.util.*;

/**
* A Persistent implementation of KnowledgeLibrary using
* Object Stores PSE product.  It contains definitions of
* private classes that are persistent (PSE) versions of
* each of the key KnowledgeFrame classes.  These are mapped
* back and forth to the actual classes on input and output
* to avoid having to make all application code PSE aware.
*
* Note that it is not possible (practical) at this time
* to keep the ka-specific compiled code out of the underlying
* frame system, thus the inclusion of PSECode in places.
* @author Amzi! inc.
*/
public class KnowledgeLibraryI_PSE implements KnowledgeLibraryI
{
   static transient Class vector_class;
   static transient Class frame_class;
   static transient Class string_class;

   String library;
   OSHashtable groups;

   // Database state variables
   transient String dbname;
   transient Database db;
   transient Transaction tr;

   public KnowledgeLibraryI_PSE()
   {
//System.out.println("KnowledgeLibraryI_PSE:constructor " + Thread.currentThread().toString());
   }

   public synchronized void initialize() throws FrameException
   {
      if (! ObjectStore.initialize(null, null))
         throw new FrameException(this, FrameException.OS_NOT_INITIALIZED);
   }

   public synchronized Thread initial_thread() throws FrameException
   {
//System.out.println("*KnowledgeLibraryI_PSE:initial_thread " + Thread.currentThread().toString());
      if (! ObjectStore.initialize(null, null))
         throw new FrameException(this, FrameException.OS_NOT_INITIALIZED);
      return Thread.currentThread();
   }

   public synchronized void initialize(Thread th) throws FrameException
   {
//System.out.println("*KnowledgeLibraryI_PSE:initialize(th) " + Thread.currentThread().toString());
//System.out.println("*initializing with thread: " + th.toString());

      // no throw here, a false simply means for this call that the thread
      // was already initialized, ODI will throw an exception if something
      // more serious is wrong.
      ObjectStore.initialize(th);
   }

   public synchronized void create(String name) throws FrameException
   {
      this.dbname = name + ".odb";

      // First make sure its not there
      try
      {
         Database.open(dbname, ObjectStore.OPEN_UPDATE).destroy();
      }
      catch (DatabaseNotFoundException e)
      {
      }

      // Then create a new one
      try
      {
         //System.out.println("About to create");
         db = Database.create(dbname,
            ObjectStore.ALL_READ |
            ObjectStore.ALL_WRITE);
         //System.out.println("Database created");

         tr = Transaction.begin(ObjectStore.UPDATE);
         //System.out.println("Transaction begun");

         groups = new OSHashtable();
         db.createRoot("groups", groups);
         tr.commit();
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this, FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   public synchronized void open(String name) throws FrameException
   {
System.out.println("KL opening: " + name);
      this.dbname = name + ".odb";

      try
      {
         db = Database.open(dbname, ObjectStore.OPEN_UPDATE);
      }
      catch (DatabaseNotFoundException e)
      {
         throw new FrameException(this,
            FrameException.OS_MISSING_DATABASE, dbname);
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      catch (Exception e)
      {
         System.out.println("something bad happened in KL");
      }

System.out.println(name + " opened");
   }

   public synchronized void close() throws FrameException
   {
      try
      {
         db.close();
         ObjectStore.shutdown(true);
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
   }

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public synchronized void add_group(String group) throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.UPDATE);
         groups = (OSHashtable)db.getRoot("groups");

         if (! groups.containsKey(group))
            groups.put(group, new PSEGroup(group));

         tr.commit();
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public synchronized Vector get_groups() throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.READONLY);
         groups = (OSHashtable)db.getRoot("groups");

         Vector v = new Vector(5,5);
         Enumeration e = groups.keys();
         while (e.hasMoreElements())
            v.addElement((String)e.nextElement());

         tr.commit();
         return v;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   /**
   * Get a KnowledgeGroup, privately called from an existing
   * transaction.
   */
   protected PSEGroup get_group(String group)
   {
      return (PSEGroup)groups.get(group);
   }

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The new key for the frame.
   */
   public synchronized String put_frame(KnowledgeFrame f) throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.UPDATE);
         groups = (OSHashtable)db.getRoot("groups");

         if (! groups.containsKey(f.group_name()))
            throw new FrameException(this, FrameException.MISSING_GROUP, f.group_name());

         PSEFrame pf = check_sub_frames(new PSEFrame(f));
         ((PSEGroup)groups.get(pf.group_name())).put_frame(pf);

         String key = pf.get_key();
         tr.commit();
         return key;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The new key for the frame.
   */
   public synchronized void remove_frame(KnowledgeFrame f) throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.UPDATE);
         groups = (OSHashtable)db.getRoot("groups");

         if (! groups.containsKey(f.group_name()))
            throw new FrameException(this, FrameException.MISSING_GROUP, f.group_name());

         PSEFrame pf = check_sub_frames(new PSEFrame(f));
         ((PSEGroup)groups.get(pf.group_name())).remove_frame(pf);

         tr.commit();
         return;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }


   public synchronized KnowledgeFrame get_frame(String group, String key) throws FrameException
   {
      return get_frame(group, key, 0);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public synchronized KnowledgeFrame get_frame(String group, String key, int version)
         throws FrameException
   {
      PSEGroup g;

      try
      {
         // We're going to be changing some stuff
         // that we don't want to save.
         tr = Transaction.begin(ObjectStore.UPDATE);
         groups = (OSHashtable)db.getRoot("groups");

         g = (PSEGroup)groups.get(group);
         if (g == null)
            return null;

         PSEFrame f = g.get_frame(key, version);
         f = fill_stubs(f);
         KnowledgeFrame kf = f.make_KnowledgeFrame();
         // So abort the transaction instead
         // of commiting it.
         tr.abort();
         return kf;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   private PSEFrame get_pseframe(String group, String key) throws FrameException
   {
      // Assumes a transaction is in progress
      PSEGroup g = (PSEGroup)groups.get(group);
      if (g == null)
         return null;

      return fill_stubs(g.get_frame(key));
   }

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public synchronized Vector get_key_notes(String group) throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.UPDATE);
         groups = (OSHashtable)db.getRoot("groups");
         PSEGroup g = (PSEGroup)groups.get(group);
         Vector v = g.get_key_notes();
         tr.commit();
         new Sorter().sort(v);
         return v;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public synchronized Vector query(QueryFrame qf) throws FrameException
   {
      try
      {
         tr = Transaction.begin(ObjectStore.READONLY);
         groups = (OSHashtable)db.getRoot("groups");

         String group_name = qf.group_name();
         PSEGroup g = (PSEGroup)groups.get(group_name);

         Vector v = new Vector();
         PSEFrame f;
         PSESlot s;
         String note;
         int i;
         QuerySlot q_slot;

         Enumeration e = g.elements();
         while (e.hasMoreElements())
         {
            f = ((PSEVersions)e.nextElement()).current_version();
            // For each frame in the group, walk the query frame seeing if there
            // is a match or not.
            if (match_frame(f, qf))
            {
               s = f.slot_at(0);
               note = s.name() + ": " + s.value().toString();
               v.addElement( new KeyNotePair(f.get_key(), note ) );
            }
         }

         tr.commit();
         new Sorter().sort(v);
         return v;
      }
      catch (ObjectStoreException e)
      {
         throw new FrameException(this,
            FrameException.OS_ERROR, e.toString());
      }
      finally
      {
         if (Transaction.inTransaction())
         {
            tr = Transaction.current();
            tr.abort();
         }
      }
   }

   //---------------------------------------------------
   // functions that provide the integrated aspects
   // of a library, making sure shared references
   // are the same.
   //

   private PSEFrame create_stub_frame(PSEFrame f)
   {
      return new PSEFrame(f, true);
   }

   /**
   * Before checking in a frame, check all of the subframes to see if they should
   * be stored in groups in the libraries.  That is, if a subframe is part of a
   * group that is stored in the library, then that subframe should be identical
   * to one of the same key in the library.  This might mean adding the subframe
   * to the library, or copying the subframe from the library.  In either case,
   * the subframe stored in the parent frame is a stub, with slots=null, to be
   * filled out when needed from the library.
   * @param f The frame for which we'll be checking sub frames.
   * @return The same frame with the subframes appropriately filled in.
   */
   private PSEFrame check_sub_frames(PSEFrame f) throws FrameException
   {
      if (f.is_stub())
      {
         return f;
      }

      int i, j;
      PSESlot slot, vslot;
      PSEFrame sf;
      PSEList kl;

      if (f.is_integrated())
      {
         sf = check_sub_frames(f.system_frame());
         f.set_system(sf);
      }
      // Walk the slots of the frame, looking for sub frames.
      for (i=0; i<f.size(); i++)
      {
         slot = f.slot_at(i);
         if (slot.is_frame())
         {
            sf = check_sub_frames((PSEFrame)slot.value());
            sf = integrate_sub_frame(sf);
            slot.set_value(sf);
            f.set_slot(i, slot);
         }
         if (slot.is_list())
         {
            kl = (PSEList)slot.value();
            for (j=0; j<kl.length(); j++)
            {
               vslot = (PSESlot)kl.slot_at(j);
               if (vslot.is_frame())
               {
                  sf = check_sub_frames((PSEFrame)vslot.value());
                  sf = integrate_sub_frame(sf);
                  vslot.set_value(sf);
                  kl.set_slot_at(j, vslot);
               }
            }
            slot.set_value(kl);
            f.set_slot(i, slot);
         }
      }
      return f;
   }

   /**
   * Having determined a frame has its sub frames correctly integrated, it is time
   * to integrate this frame into the library.  This means ensuring it is stored
   * in its group, if it has a group.  If there is ambiguity between the copy in
   * question and the copy in the library, then use the more recent of the two.
   * @param f The frame to be integrated.
   * @return The frame after integration with key and other fields set correctly.
   */
   private PSEFrame integrate_sub_frame(PSEFrame f) throws FrameException
   {
      PSEGroup g = get_group(f.group_name());
      if (g == null)
         return f;

      String key = f.get_key();
      if (key == null)
      {
         key = g.put_frame(f);
         f.set_key(key);
      }
      else
         if ( f.get_update_date() == g.get_frame(key).get_update_date() )
            ;
         else if ( f.get_update_date() > g.get_frame(key).get_update_date() )
            g.put_frame(f);
         else
            f = g.get_frame(key);

      // Return a stub copy (slots = null) of the frame.  The key will
      // be used to fill the slots when necessary.
      return create_stub_frame(f);
   }

   /**
   * When retrieving and integrated frame from the library, it is necessary
   * to fill in various subframes with the correct current values from the
   * copies of those frames stored in their appropriate groups.
   * @param f The frame whose stub frames need to be filled.
   * @return The frame with stubs filled in.
   */
   private PSEFrame fill_stubs(PSEFrame f) throws FrameException
   {
      int i,j;
      PSEList kl;
      PSESlot slot, vslot;
      Class value_class;
      PSEFrame sf;

      if (f == null)
         return null;

      if (f.is_integrated())
      {
         sf = fill_stubs(f.system_frame());
         f.set_system(sf);
      }

      for (i=0; i<f.size(); i++)
      {
         slot = f.slot_at(i);
         if (slot.is_frame())
         {
            sf = (PSEFrame)slot.value();
            if (sf.is_stub())
               sf = get_pseframe(sf.group_name(), sf.get_key());
            else
               sf = fill_stubs(sf);
            slot.set_value(sf);
            f.set_slot(i, slot);
         }
         else if (slot.is_list())
         {
            kl = (PSEList)slot.value();
            for (j=0; j<kl.length(); j++)
            {
               vslot = (PSESlot)kl.slot_at(j);
               if (vslot.is_frame())
               {
                  sf = (PSEFrame)vslot.value();
                  if (sf.is_stub())
                     sf = get_pseframe(sf.group_name(), sf.get_key());
                  else
                     sf = fill_stubs(sf);
                  vslot.set_value(sf);
                  kl.set_slot_at(j, vslot);
               }
            }
            slot.set_value(kl);
            f.set_slot(i, slot);
         }
      }
      return f;
   }


   //---------------------------------------------
   // Functions to support the query function.
   //

   private boolean match_frame(PSEFrame f, QueryFrame qf) throws FrameException
   {
      int i;
      Object value, value1;
      QuerySlot q_slot;

      if (f == null)
         return false;

      // if the query has a key, just use the key
      String qkey = qf.get_key();
      if (qkey != null)
      {
         String fkey = f.get_key();
         if (fkey != null && qkey.equals(fkey))
            return true;
         else
            return false;
      }

      for (i=0; i<qf.size(); i++)
      {
         q_slot = qf.slot_at(i);
         value = f.get(q_slot.name);
         if (value == null)
            return false;
         if (! match_slot(value, q_slot.query_op) )
            return false;
      }

      for (i=0; i<qf.get_system_size(); i++)
      {
         q_slot = qf.system_slot_at(i);
         value = f.get_system(q_slot.name);
         if (value  == null)
            return false;
         if (! match_slot(value, q_slot.query_op) )
            return false;
      }

      return true;
   }

   private boolean match_slot(Object value, QueryOp query_op) throws FrameException
   {
      int j;
      PSEFrame f2;
      PSEList kl;
      String s;
      QueryOp qop1, qop2;

      Object value1 = query_op.value1;
      Object value2 = query_op.value2;

      switch (query_op.op)
      {
      case QueryOp.EQUALS:
         if ( value.equals(value1) )
            return true;
         break;
      case QueryOp.GREATER_THAN:
         if (((Number)value).longValue() > ((Number)value1).longValue())
            return true;
         break;
      case QueryOp.LESS_THAN:
         if (((Number)value).longValue() < ((Number)value1).longValue())
            return true;
         break;
      case QueryOp.MATCH_FRAME:
         f2 = (PSEFrame)value;
         if (f2.is_stub())
            f2 = ((PSEGroup)get_group(f2.group_name())).get_frame(f2.get_key());
         if ( match_frame(f2, (QueryFrame)value1) )
            return true;
         break;
      case QueryOp.CONTAINS_ITEM:
         kl = (PSEList)value;
         for (j=0; j<kl.length(); j++)
            if ( kl.slot_at(j).value().equals(value1) )
               return true;
         break;
      case QueryOp.CONTAINS_FRAME:
         kl = (PSEList)value;
         for (j=0; j<kl.length(); j++)
         {
            f2 = (PSEFrame)kl.slot_at(j).value();
            if (f2.is_stub())
               f2 = ((PSEGroup)get_group(f2.group_name())).get_frame(f2.get_key());
            if ( match_frame(f2, (QueryFrame)value1) )
               return true;
         }
         break;
      case QueryOp.CONTAINS_STRING:
         s = (String)value;
         if (s.indexOf((String)value1) >= 0)
            return true;
         break;
      case QueryOp.STARTS_WITH:
         s = (String)value;
         if (s.startsWith((String)value1))
            return true;
         break;
      case QueryOp.ENDS_WITH:
         s = (String)value;
         if (s.endsWith((String)value1))
            return true;
         break;
      case QueryOp.OR:
         qop1 = (QueryOp)value1;
         qop2 = (QueryOp)value2;
         if (match_slot(value, qop1) || match_slot(value, qop2))
            return true;
         break;
      case QueryOp.AND:
         qop1 = (QueryOp)value1;
         qop2 = (QueryOp)value2;
         if (match_slot(value, qop1) && match_slot(value, qop2))
            return true;
         break;
      default:
         throw new FrameException(this, FrameException.INVALID_QUERY);
      }
      return false;
   }
}


