// KnowledgeLibraryI

package amzi.frames;

import java.util.*;

/**
* A dictionary of frame groups, indexed by group name.
* The idea is a library or archive contains many frame
* groups, each of which contains many frames.
* @author Amzi! inc.
*/
public interface KnowledgeLibraryI
{
   /**
   * Initialize a library server.
   */
   public void initialize() throws FrameException;

   /**
   * Initialize a library server.
   */
   public Thread initial_thread() throws FrameException;

   /**
   * Initialize a library server.
   */
   public void initialize(Thread th) throws FrameException;

   /**
   * Creates a new Knowledge Library.
   */
   public void create(String db_name) throws FrameException;

   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException;

   /**
   * Close an open Knowledge Library.
   */
   public void close() throws FrameException;

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException;

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException;

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException;

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException;

   /**
   * Get a frame from the library based on its group name and
   * frame key and version number
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @param version The version number.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key, int version) throws FrameException;

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException;

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException;

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException;
}