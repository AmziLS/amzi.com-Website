// KnowledgeFrame.java

package amzi.frames;

import java.util.*;
import java.text.*;
import java.io.*;

/**
* The core KnowledgeFrame object that stores a vector of
* slots.
* @author Amzi! inc.
*/
public class KnowledgeFrame implements Serializable
{
   private Vector slots;

   // System attributes
   private String group;
   private String key;
   private KnowledgeFrame system;

   static transient DateFormat df;
   static XMLParser xp = null;

   static
   {
      // Format the datetime like: 3/19/98 12:32:14 PM
      df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.US);
      df.setTimeZone(TimeZone.getDefault());
   }

   /**
   * Construct a knowledge frame that contains system information
   * if integrate is set to true, or not if set to false.
   * @param group The name of the group.
   * @param integrate Whether to add system information or not.
   */
   public KnowledgeFrame(String group, boolean integrate) throws FrameException
   {
      slots = new Vector(5,5);
      this.group = group;
      key = null;
      // Create the system frame.
      if (integrate)
      {
         system = new KnowledgeFrame("system", false);
         long now = System.currentTimeMillis();
         system.set("update date", new Long(now));
         system.set("create date", new Long(now));
         system.set("access control list",
            new KnowledgeFrame("access control list", false));
      }
      else
         system = null;
   }

   public KnowledgeFrame(String group) throws FrameException
   {
      this(group, true);
   }

   /**
   * Constructor used for those cases, such as the xml parser,
   * that want to add the pieces later.
   */
   public KnowledgeFrame() throws FrameException
   {
      slots = new Vector(5,5);
      group = null;
      key = null;
   }

   public static KnowledgeFrame readXML(File f) throws FrameException
   {
      KnowledgeFrame kf = null;
      try
      {
         FileReader fr = new FileReader(f);
         if (xp == null)
            xp = new XMLParser(fr);
         else
            xp.ReInit(fr);

         kf = xp.XMLFrame();
         fr.close();
      }
      catch (FileNotFoundException ex)
      {
         throw new FrameException(FrameException.NO_SUCH_FILE, ex.getMessage());
      }
      catch (ParseException ex)
      {
         throw new FrameException(FrameException.XML_PARSE, f.getName() + ex.getMessage());
      }
      catch (IOException ex)
      {
         throw new FrameException(FrameException.IO_ERROR, f.getName() + ex.getMessage());
      }

      return kf;
   }

   public static Vector readXMLs(File f) throws FrameException
   {
      Vector v = null;
      try
      {
         FileReader fr = new FileReader(f);
         if (xp == null)
            xp = new XMLParser(fr);
         else
            xp.ReInit(fr);

         v = xp.XMLFrames();
         fr.close();
      }
      catch (FileNotFoundException ex)
      {
         throw new FrameException(FrameException.NO_SUCH_FILE, ex.getMessage());
      }
      catch (ParseException ex)
      {
         throw new FrameException(FrameException.XML_PARSE, f.getName() + ex.getMessage());
      }
      catch (IOException ex)
      {
         throw new FrameException(FrameException.IO_ERROR, f.getName() + ex.getMessage());
      }

      return v;
   }

   /**
   * Test if the frame is integrated into the library, meaning
   * it is in its own group.
   */
   public boolean is_integrated() throws FrameException
   {
      if ( system == null )
         return false;
      else
         return true;
   }

   /**
   * Sets the value for a given slot.  If the slot doesn't exist, it
   * is created, otherwise the value is replaced.
   * @param slot_name The name of the slot to set.
   * @param value The value to give the slot.
   */
   public void set(String slot_name, Object value) throws FrameException
   {
      if (slot_exists(slot_name))
         ((KnowledgeSlot)slots.elementAt(slot_number(slot_name))).value = value;
      else
         slots.addElement( new KnowledgeSlot(slot_name, value) );

      //set_system( "update date", new Long(System.currentTimeMillis()) );
   }

   /**
   * Allow a library to stub out this frame, because it is stored
   * in the library already.  When retrieved, the frame will be
   * replaced with the library version stored under the key.
   */
   public void to_stub()
   {
      if (key != null)
      {
         slots = null;
      }
   }

   /**
   * Tell whether or not this frame has been stubbed out or not.
   */
   public boolean is_stub()
   {
      if (slots == null)
         return true;
      else
         return false;
   }

   /**
   * Get the value for a given slot.
   * @param slot_name - The name of the slot.
   * @return The object stored in that slot.
   */
   public Object get(String slot_name) throws FrameException
   { return ((KnowledgeSlot)slots.elementAt(slot_number(slot_name))).value; }

   /**
   * Gets the full slot at a given position.
   * @param i The position for the slot.
   * @return The slot at that position.
   */
   public KnowledgeSlot slot_at(int i) throws FrameException
   { return (KnowledgeSlot)slots.elementAt(i); }

   /**
   * Add a new slot to this frame.
   */
   public void add_slot(KnowledgeSlot ks)
   { slots.addElement(ks); }

   /**
   * Remove a slot from a frame.
   */
   public void remove(String slot_name)
   {
      int i = slot_number_no_error(slot_name);
      if (i < 0)
         return;
      else
         slots.removeElementAt(i);
   }

   public String group_name()
   { return group; }

   public long get_create_date() throws FrameException
   { return ((Long)get_system("create date")).longValue(); }

   public long get_update_date() throws FrameException
   { return ((Long)get_system("update date")).longValue(); }

   public String get_create_date_string() throws FrameException
   { return df.format(new Date(((Long)get_system("create date")).longValue())); }

   public String get_update_date_string() throws FrameException
   { return df.format(new Date(((Long)get_system("update date")).longValue())); }

   public String get_key()
   { return key; }

   public int get_version() throws FrameException
   {
      if ( system != null && system.slot_exists("version") )
         return ((Integer)system.get("version")).intValue();
      else
         return 0;
   }

   /**
   * Get the size of this frame.
   * @return The number of slots in the frame.
   */
   public int size() throws FrameException
   {
      if (slots == null)
         throw new FrameException(this, FrameException.NULL_SLOTS,
            group + "(" + key + ")");

      return slots.size();
   }

   /**
   * Get a string which is an excerpt from the frame that can
   * be used for display as a summary of the frame's contents.
   */
   public String summary() throws FrameException
   {
      if (slots == null)
         return "stubbed out frame";
      else if (slots.size() == 0)
         return "empty frame with no slots";
      else
      {
         KnowledgeSlot s = (KnowledgeSlot)slots.elementAt(0);
         if (s.is_frame())
            return s.summary();
         else
            return s.summary();
      }
   }

   /**
   * Augments the vector of sub-slots for this slot with the new
   * value, or creates a new slot with a vector if the slot didn't
   * exist.
   * @param slot_name The slot name.
   * @param item_name The name of the item slot in the vector.
   * @param value The value to be added to the vector.
   */
   public void add_list_item(String slot_name, String item_name, Object value) throws FrameException
   {
      KnowledgeList kl;
      KnowledgeSlot ks = new KnowledgeSlot(item_name, value);

      if (slot_exists(slot_name))
      {
         kl = (KnowledgeList)get(slot_name);
         kl.add_slot(ks);
      }
      else
      {
         kl = new KnowledgeList();
         kl.add_slot(ks);
         add_slot(new KnowledgeSlot(slot_name, kl));
      }
      //set_system( "update date", new Long(System.currentTimeMillis()) );
   }

   /**
   * Augments the vector of sub-slots for this slot with the new
   * value, or creates a new slot with a vector if the slot didn't
   * exist.  The sub-slots are given the default name of "item".
   * @param slot_name The slot name.
   * @param value The value to be added to the vector.
   */
   public void add_list_item(String slot_name, Object value) throws FrameException
   {
      add_list_item(slot_name, "item", value);
   }

   /**
   * Get the slot number for a given slot name.
   * @param slot_name The name of the slot.
   * @return The slot number.
   */
   public int slot_number(String slot_name) throws FrameException
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((KnowledgeSlot)slots.elementAt(i)).name.equals(slot_name) )
            return i;
      }
      throw new FrameException(FrameException.UNKNOWN_SLOT_NAME,
         slot_name + " in group " + group);
   }

   /**
   * Get the slot number for a given slot name.
   * @param slot_name The name of the slot.
   * @return The slot number.
   */
   public int slot_number_no_error(String slot_name)
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((KnowledgeSlot)slots.elementAt(i)).name.equals(slot_name) )
            return i;
      }
      return -1;
   }

   /**
   * Determine if a slot exists or not.
   * @param slot_name The slot name.
   * @return true if the slot exists, otherwise false.
   */
   public boolean slot_exists(String slot_name)
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((KnowledgeSlot)slots.elementAt(i)).name.equals(slot_name) )
            return true;
      }
      return false;
   }

   public String toString()
   {
      try
      {
         return group + " " + summary();
      }
      catch (FrameException e)
      {
         return "error creating string " + e.getMessage();
      }
   }

   public boolean same_as(KnowledgeFrame f) throws FrameException
   {
      if (same_state(f) && same_contents(f))
         return true;
      else
         return false;
   }
   
   /**
   * Compare to frames by their system state information,
   * including version to make sure they are the same.
   */
   public boolean same_state(KnowledgeFrame f) throws FrameException
   {
      if ( (get_key() == null) && (f.get_key() == null) )
         ;
      else if ( (get_key() != null) && (f.get_key() != null) )
      {
         if ( ! get_key().equals(f.get_key()) )
            return false;
      }
      else
         return false;

      if ( ! group_name().equals(f.group_name()) )
         return false;

      //if ( get_update_date() != f.get_update_date() )
      //   return false;

      if ( get_version() != f.get_version() )
         return false;

      return true;
   }

   public boolean same_contents(KnowledgeFrame f) throws FrameException
   {
      if ( size() != f.size() )
         return false;

      for (int i=0; i < size(); i++)
      {
         if ( ! slot_at(i).same_contents(f.slot_at(i)) )
            return false;
      }

      return true;
   }

   /**
   * Dump the contents of a frame into a string for printing.
   * This function uses the Java functions to determine the
   * Java type (class) of a value in a slot, and takes appropriate
   * action based on that information.  Vector elements are listed
   * as separate list item, and KnowledgeFrames are dealt with by
   * recursively calling toString() on them with an appropriate
   * level of indentation.  (Note that for non-KnowledgeArchive
   * values, the normal Java toString() method is used.)
   * @return The string.
   */
   public String toFullString() throws FrameException
   {
      return toFullString(0);
   }

   public String toFullString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("Group: " + group);
      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      if (key != null)
         sb.append("Key: " + key);
      else
         sb.append("Key: " + "null");

      if (is_integrated())
      {
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Create Date: " + get_create_date_string());
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Update Date: " + get_update_date_string());
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Version: " + get_version());
      }

      if (is_stub())
      {
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Slots stubbed out");
      }

      for (int i=0; i < slots.size(); i++)
         sb.append( ((KnowledgeSlot)slots.elementAt(i)).toFullString(indent) );

      return sb.toString();
   }

   /**
   * Dump the contents of a frame into a tagged string for easy
   * parsing.
   * @return The string.
   */
   public String toXMLString() throws FrameException
   {
      return "<?XML version=\"1.0\" standalone=\"yes\"?>" + "\n" + 
         toTaggedString(0);
   }

   /**
   * Dump the contents of a frame into a tagged string for easy
   * parsing.
   * @return The string.
   */
   public String toTaggedString() throws FrameException
   {
      return toTaggedString(0);
   }

   public String toTaggedString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("<KnowledgeFrame group=\"" + group_name() + "\"");
      // Don't export the key, can't reload in different archive.
      //if (get_key() != null)
      //   sb.append(" key=\"" + get_key() + "\"");
      sb.append(">");

      if (is_integrated())
         sb.append( system.toTaggedString(indent+2) );

      for (int i=0; i < slots.size(); i++)
         sb.append( ((KnowledgeSlot)slots.elementAt(i)).toTaggedString(indent+2) );

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("</KnowledgeFrame>");
      return sb.toString();
   }

   // System functions

   /**
   * Get the system frame.
   */
   public KnowledgeFrame system_frame()
   {
      // Usually the caller has checked if the frame is integrated.
      return system;
   }

   /**
   * Get the value of a slot in the system subframe of
   * an integrated frame. Returns null if not an integrated
   * frame.
   */
   public Object get_system(String slot_name) throws FrameException
   {
      if (! is_integrated())
         return null;
      return system_frame().get(slot_name);
   }

   /**
   * Each integrated frame has a subframe of system information
   * that can be set by these functions.
   */
   public void set_system(String slot_name, Object value) throws FrameException
   {
      if (! is_integrated())
         return;
      system_frame().set(slot_name, value);
   }

   public void set_system(KnowledgeFrame system)
   {
      this.system = system;
   }

   /**
   * Create a new system frame for this knowledge frame.
   */
   public void create_system() throws FrameException
   {
      system = new KnowledgeFrame("system", false);
      long now = System.currentTimeMillis();
      system.set("update date", new Long(now));
      system.set("create date", new Long(now));
      system.set("access control list",
         new KnowledgeFrame("access control list", false));
   }

   public void set_key(String key)
   {
      this.key = key;
   }

   public void set_group(String g) { group = g; }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}