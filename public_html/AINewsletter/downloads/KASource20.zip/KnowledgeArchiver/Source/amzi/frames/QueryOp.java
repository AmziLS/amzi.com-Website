// QueryOp

package amzi.frames;

import java.io.*;
import java.util.*;

/**
* Operators and values to be used in tests for
* QuerySlots.
* @author  Amzi! inc.
*/
public class QueryOp implements Serializable
{
   public final static int EQUALS = 1;
   public final static int GREATER_THAN = 2;
   public final static int AFTER = 2;
   public final static int LESS_THAN = 3;
   public final static int BEFORE = 3;
   public final static int CONTAINS_ITEM = 4;
   public final static int MATCH_FRAME = 5;
   public final static int CONTAINS_FRAME = 6;
   public final static int STARTS_WITH = 7;
   public final static int ENDS_WITH = 8;
   public final static int OR = 9;
   public final static int AND = 10;
   public final static int CONTAINS_STRING = 11;

   // Allow direct access to fields as this might
   // be a little faster.
   public int op;
   public Object value1;
   public Object value2;

   public QueryOp(int op, Object value1)
   {
      this.op = op;
      this.value1 = value1;
      this.value2 = null;
   }

   public QueryOp(int op, Object value1, Object value2)
   {
      this.op = op;
      this.value1 = value1;
      this.value2 = value2;
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}