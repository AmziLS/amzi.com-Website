// Pets.java

import amzi.frames.*;
import java.util.*;
import amzi.ka.*;

/**
* A simple example of the use of a KnowledgeLibary.
*/
public class Pets
{
   GEKOLibrary pets;
   long time1, time2;

   public static void main(String[] args) throws Exception
   {
      Pets app = new Pets();
      app.go();
   }

   public Pets() throws Exception
   {
      // Create a new KnowledgeLibrary - a library can
      // contain multiple groups of frames.  In this case
      // it will be containing a group of 'dog' frames
      // and a group of 'duck' frames.
      pets = new RemoteGEKOs();
      pets.connect("192.168.0.5:8080");
      pets.create("pets");
      //pets.logon(new KnowledgeFrame("duck"));
      pets.add_group("dog");
      pets.add_group("duck");
      pets.add_group("owner");
      pets.add_group("toy");
   }

   public void go() throws Exception
   {
      // Populate the library.
      populate();

      // This first chunk of code tests a feature used
      // when browsing the library.  The get_key_notes()
      // function returns a list (vector) with an element
      // for each frame in a group.  The element has two
      // parts, a lookup key for the frame (to allow quick
      // access to the frame) and a note string containing the
      // value of one of the slots in the frame.
      System.out.println("--- Key Notes Test ---");
      // Get keys for the dog group and use the name slot
      // for the note.
      Vector v = pets.get_key_notes("dog");
      KeyNotePair kn;
      for (int i = 0; i < v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("--- End Key Notes Test ---\n");

      // Call the library print_all() function to see if all
      // of the data we entered is indeed in there.
      //System.out.println("--- Print All Test ---");
      //pets.print_all();

      //System.out.println("--- Aging the people ---");
      //age_owners();
      //pets.print_all();

      System.out.println("--- Testing queries ---");
      do_queries();

      System.out.println("--- toString() test ---");
      KnowledgeSlot s;
      KnowledgeFrame f = pets.get_frame("dog", "dog1001");
      for (int i=0; i<f.size(); i++)
         System.out.println( f.slot_at(i).toString() );
      System.out.println("We picked frame: " + f.summary());
      System.out.println("--- Tagged format test ---");
      System.out.println(f.toTaggedString());
      System.out.println("--- Equals tests ---");
      KnowledgeFrame f2 = pets.get_frame("dog", "dog1001");
      System.out.println("Comparing:");
      System.out.println(f.toTaggedString());
      System.out.println(f2.toTaggedString());

      if (f.equals(f2))
         System.out.println(f.summary() + " = " + f2.summary());
      else
         System.out.println(f.summary() + " != " + f2.summary());
      if (f.same_state(f2))
         System.out.println(f.summary() + " same_state " + f2.summary());
      else
         System.out.println(f.summary() + " !same_state " + f2.summary());
      if (f.same_contents(f2))
         System.out.println(f.summary() + " same_contents " + f2.summary());
      else
         System.out.println(f.summary() + " !same_contents " + f2.summary());

      f2 = pets.get_frame("dog", "dog1002");
      if (f.equals(f2))
         System.out.println(f.summary() + " = " + f2.summary());
      else
         System.out.println(f.summary() + " != " + f2.summary());
      if (f.same_state(f2))
         System.out.println(f.summary() + " same_state " + f2.summary());
      else
         System.out.println(f.summary() + " !same_state " + f2.summary());
      if (f.same_contents(f2))
         System.out.println(f.summary() + " same_contents " + f2.summary());
      else
         System.out.println(f.summary() + " !same_contents " + f2.summary());
   }

   public void do_queries() throws Exception
   {
      // A bunch of different queries.  Note that, like the get_key_note
      // function that returns a key-note pair list, each of the queries
      // returns the same.
      int i;
      KeyNotePair kn;
      QueryFrame qf, qf2, qf3;
      Vector v;
      
      // A simple query for dogs that chase balls
      qf = new QueryFrame("dog");
      qf.set("hobbies", new QueryOp(QueryOp.CONTAINS, "chase balls") );
      v = pets.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("---");

      // More complex, looking for owners whose name starts with dennis
      // and ends with merritt
      qf = new QueryFrame("owner");
      qf.set("name", new QueryOp(QueryOp.AND,
         new QueryOp(QueryOp.STARTS_WITH, "Dennis"),
         new QueryOp(QueryOp.ENDS_WITH, "Merritt") ));
      v = pets.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("---");

      // How about starts with dennis OR ends with merritt.
      qf = new QueryFrame("owner");
      qf.set("name", new QueryOp(QueryOp.OR,
         new QueryOp(QueryOp.STARTS_WITH, "Dennis"),
         new QueryOp(QueryOp.ENDS_WITH, "Merritt") ));
      v = pets.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("---");

      // Nested frames in vectors, finding all the dogs who have owners
      // (a subframe) who have on their list of toys (frames in a vector)
      // a toy whose color is pink.
      qf = new QueryFrame("dog");
      qf2 = new QueryFrame("owner");
      qf3 = new QueryFrame("toy");
      qf3.set("color", new QueryOp(QueryOp.EQUALS, "pink") );
      qf2.set("toys", new QueryOp(QueryOp.CONTAINS_FRAME, qf3) );
      qf.set("owner", new QueryOp(QueryOp.MATCH_FRAME, qf2) );
      qf.set_system("create date", new QueryOp(QueryOp.BEFORE, new Long(time2)) );
      v = pets.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("---");

      qf = new QueryFrame("dog");
      qf.set("sound", new QueryOp(QueryOp.OR,
         new QueryOp(QueryOp.EQUALS, "bark"),
         new QueryOp(QueryOp.EQUALS, "howl") ));
      v = pets.query(qf);
      for (i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
      }
      System.out.println("---");
    }

   public void populate() throws Exception
   {
      // First create some toys

      KnowledgeFrame bike = new KnowledgeFrame("toy", true);
      bike.set("type", "bike");
      bike.set("color", "green");
      pets.put_frame(bike);

      System.out.println("bike in ok");

      KnowledgeFrame plane = new KnowledgeFrame("toy", true);
      plane.set("type", "plane");
      plane.set("color", "pink");
      pets.put_frame(plane);

      System.out.println("plane in ok");

      KnowledgeFrame car = new KnowledgeFrame("toy", true);
      car.set("type", "car");
      car.set("color", "white");

      KnowledgeFrame car2 = new KnowledgeFrame("toy", true);
      car2.set("type", "car");
      car2.set("color", "black");

      // Then some people that use the toys

      KnowledgeFrame dm = new KnowledgeFrame("owner", true);
      dm.set("name", "Dennis Merritt");
      dm.set("age", new Integer(52));
      dm.add_list_item("toys", bike);
      dm.add_list_item("toys", plane);
      dm.add_list_item("toys", car2);


      KnowledgeFrame mm = new KnowledgeFrame("owner", true);
      mm.set("name", "Mary Merritt");
      mm.set("age", new Integer(38));
      mm.add_list_item("toys", plane);

      KnowledgeFrame db = new KnowledgeFrame("owner", true);
      db.set("name", "Dennis Bowman");
      db.set("age", new Integer(35));
      db.add_list_item("toys", car);

      KnowledgeFrame jb = new KnowledgeFrame("owner", true);
      jb.set("name", "Jenny Bowman");
      jb.set("age", new Integer(34));
      jb.add_list_item("toys", car);

      // Finally some dogs and their owners

      KnowledgeFrame kato = new KnowledgeFrame("dog", true);
      kato.set("name", "Kato");
      kato.set("sound", "bark");
      kato.set("owner", dm);
      kato.add_list_item("hobbies", "bark at UPS");
      kato.add_list_item("hobbies", "bark at FedEx");
      kato.add_list_item("hobbies", "chase Ollie");

      KnowledgeFrame ella = new KnowledgeFrame("dog", true);
      ella.set("name", "Ella");
      ella.set("sound", "yip yap");
      ella.set("owner", mm);
      ella.add_list_item("hobbies", "bark at whatever");
      ella.add_list_item("hobbies", "chase balls");
      ella.add_list_item("hobbies", "eat people food");

      System.out.println("pausing");
      time1 = System.currentTimeMillis();
      time2 = time1 + 3000;

      while (System.currentTimeMillis() < time2)
         ;
      System.out.println("done pausing");


      KnowledgeFrame ollie = new KnowledgeFrame("dog", true);
      ollie.set("name", "Ollie");
      ollie.set("sound", "howl");
      ollie.set("owner", dm);
      ollie.add_list_item("hobbies", "hunt wabbits");
      ollie.add_list_item("hobbies", "wrestle with Kato");

      KnowledgeFrame sam = new KnowledgeFrame("dog", true);
      sam.set("name", "Sam");
      sam.set("sound", "bark");
      sam.set("owner", db);
      sam.add_list_item("hobbies", "chase balls");
      sam.add_list_item("hobbies", "swimming");
      sam.add_list_item("hobbies", "chase Ollie");

      KnowledgeFrame susie = new KnowledgeFrame("dog", true);
      susie.set("name", "Susie");
      susie.set("sound", "bark");
      susie.set("owner", jb);
      susie.add_list_item("hobbies", "swimming");
      susie.add_list_item("hobbies", "jump on people");

      // Put the dogs in the KnowledgeLibrary

      pets.put_frame(kato);
      pets.put_frame(ella);
      pets.put_frame(ollie);
      pets.put_frame(sam);
      pets.put_frame(susie);

      // And some ducks

      KnowledgeFrame leona = new KnowledgeFrame("duck", true);
      leona.set("name", "Leona");
      leona.set("sound", "QUACK");
      leona.add_list_item("hobbies", "make more ducks");
      leona.add_list_item("hobbies", "fight wild animals");

      KnowledgeFrame bif = new KnowledgeFrame("duck", true);
      bif.set("name", "Bif");
      bif.set("sound", "quack");
      bif.add_list_item("hobbies", "follow Leona around");
      bif.add_list_item("hobbies", "splash in the pond");

      pets.put_frame(leona);
      pets.put_frame(bif);
   }

   public void age_owners() throws Exception
   {
      int age;
      KnowledgeFrame t = new KnowledgeFrame("toy", true);
      t.set("type", "dice");
      t.set("color", "white with black dots");
      KnowledgeFrame p;
      Vector v = pets.get_key_notes("owner");
      KeyNotePair kn;
      for (int i = 0; i < v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         p = pets.get_frame("owner", kn.get_key());
         age = ((Integer)p.get("age")).intValue();
         age++;
         p.set("age", new Integer(age));
         p.add_list_item("toys", t);
         pets.put_frame(p);
      }
      // update the toys as well
      v = pets.get_key_notes("toy");
      for (int i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         t = pets.get_frame("toy", kn.get_key());
         t.set("fun", new Boolean(true));
         pets.put_frame(t);
      }
   }
}