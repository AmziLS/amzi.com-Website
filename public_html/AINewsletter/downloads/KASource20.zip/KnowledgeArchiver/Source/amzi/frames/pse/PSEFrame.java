// PSEFrame.java

package amzi.frames.pse;

import amzi.frames.*;
import java.util.*;
import java.text.*;
import java.io.*;
import COM.odi.*;
import COM.odi.util.*;

/**
* The core KnowledgeFrame object that stores a vector of
* slots.
* @author Amzi! inc.
*/
class PSEFrame
{
   private OSVector slots;

   // System attributes
   private String group;
   private String key;
   private PSEFrame system;

   static transient DateFormat df;

   static
   {
      // Format the datetime like: 3/19/98 12:32:14 PM
      df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.US);
      df.setTimeZone(TimeZone.getDefault());
   }

   /*
   void test()
   {
      System.out.println("just a garbage new method to see what it does");
   }
   */

   PSEFrame(KnowledgeFrame f) throws FrameException
   {
      group = f.group_name();
      key = f.get_key();
      if (f.is_integrated())
         system = new PSEFrame(f.system_frame());
      else
         system = null;
      int i;
      if (! f.is_stub())
      {
         slots = new OSVector();
         for (i=0; i<f.size(); i++)
            slots.addElement( new PSESlot(f.slot_at(i)) );
      }
      else
         slots = null;
   }

   KnowledgeFrame make_KnowledgeFrame() throws FrameException
   {
      KnowledgeFrame f;
      if (is_integrated())
      {
         f = new KnowledgeFrame(group, true);
         f.set_system( system_frame().make_KnowledgeFrame() );
      }
      else
      {
         f = new KnowledgeFrame(group, false);
      }
      f.set_key(key);

      if (slots != null)
         for (int i=0; i<slots.size(); i++)
            f.add_slot( ((PSESlot)slots.elementAt(i)).make_KnowledgeSlot() );
      else
         f.to_stub();

      return f;
   }

   /**
   * Construct a knowledge frame that contains system information
   * if integrate is set to true, or not if set to false.
   * @param group The name of the group.
   * @param integrate Whether to add system information or not.
   */
   PSEFrame(String group, boolean integrate) throws FrameException
   {
      slots = new OSVector();
      this.group = group;
      key = null;
      // Create the system frame.
      if (integrate)
      {
         system = new PSEFrame("system", false);
         long now = System.currentTimeMillis();
         system.set("update date", new Long(now));
         system.set("create date", new Long(now));
         system.set("access control list",
            new PSEFrame("access control list", false));
      }
      else
         system = null;
   }

   /**
   * Construct a KnowledgeFrame from an existing one, with
   * the option of copying the slots structure or making it
   * null, thus creating a stub frame.
   * @param f The existing frame.
   * @param stub true if this is to be a stub copy.
   */
   PSEFrame(PSEFrame f, boolean stub)
   {
      this.group = f.group;
      this.key = f.key;
      this.system = f.system;
      if (stub == true)
         slots = null;
      else
         this.slots = f.slots;
   }


   /**
   * Sets the value for a given slot.  If the slot doesn't exist, it
   * is created, otherwise the value is replaced.
   * @param slot_name The name of the slot to set.
   * @param value The value to give the slot.
   */
   void set(String slot_name, Object value) throws FrameException
   {
      if (slot_exists(slot_name))
         ((PSESlot)slots.elementAt(slot_number(slot_name))).value = value;
      else
         slots.addElement( new PSESlot(slot_name, value) );

      //set_system( "update date", new Long(System.currentTimeMillis()) );
   }

   /**
   * Allow a library to stub out this frame, because it is stored
   * in the library already.  When retrieved, the frame will be
   * replaced with the library version stored under the key.
   */
   void to_stub()
   {
      if (key != null)
      {
         slots = null;
      }
   }

   /**
   * Tell whether or not this frame has been stubbed out or not.
   */
   boolean is_stub()
   {
      if (slots == null)
         return true;
      else
         return false;
   }

   /**
   * Get the value for a given slot.
   * @param slot_name - The name of the slot.
   * @return The object stored in that slot.
   */
   Object get(String slot_name) throws FrameException
   { return ((PSESlot)slots.elementAt(slot_number(slot_name))).value; }

   /**
   * Gets the full slot at a given position.
   * @param i The position for the slot.
   * @return The slot at that position.
   */
   PSESlot slot_at(int i) throws FrameException
   { return (PSESlot)slots.elementAt(i); }

   /**
   * Add a new slot to this frame.
   */
   void add_slot(PSESlot ks)
   { slots.addElement(ks); }

   String group_name()
   { return group; }

   long get_create_date() throws FrameException
   { return ((Long)get_system("create date")).longValue(); }

   long get_update_date() throws FrameException
   { return ((Long)get_system("update date")).longValue(); }

   String get_create_date_string() throws FrameException
   { return df.format(new Date(((Long)get_system("create date")).longValue())); }

   String get_update_date_string() throws FrameException
   { return df.format(new Date(((Long)get_system("update date")).longValue())); }

   String get_key()
   { return key; }

   /**
   * Get the size of this frame.
   * @return The number of slots in the frame.
   */
   int size() throws FrameException
   {
      if (slots == null)
         throw new FrameException(this, FrameException.NULL_SLOTS,
            group + "(" + key + ")");

      return slots.size();
   }

   /**
   * Get a string which is an excerpt from the frame that can
   * be used for display as a summary of the frame's contents.
   */
   String summary() throws FrameException
   {
      if (slots == null)
         return "stubbed out frame";
      else if (slots.size() == 0)
         return "empty frame with no slots";
      else
      {
         PSESlot s = (PSESlot)slots.elementAt(0);
         if (s.is_frame())
            return s.summary();
         else
            return s.summary();
      }
   }

   /**
   * Augments the vector of sub-slots for this slot with the new
   * value, or creates a new slot with a vector if the slot didn't
   * exist.
   * @param slot_name The slot name.
   * @param item_name The name of the item slot in the vector.
   * @param value The value to be added to the vector.
   */
   void add_list_item(String slot_name, String item_name, Object value) throws FrameException
   {
      PSEList kl;
      PSESlot ks = new PSESlot(item_name, value);

      if (slot_exists(slot_name))
      {
         kl = (PSEList)get(slot_name);
         kl.add_slot(ks);
      }
      else
      {
         kl = new PSEList();
         kl.add_slot(ks);
         add_slot(new PSESlot(slot_name, kl));
      }
      //set_system( "update date", new Long(System.currentTimeMillis()) );
   }

   /**
   * Augments the vector of sub-slots for this slot with the new
   * value, or creates a new slot with a vector if the slot didn't
   * exist.  The sub-slots are given the default name of "item".
   * @param slot_name The slot name.
   * @param value The value to be added to the vector.
   */
   void add_list_item(String slot_name, Object value) throws FrameException
   {
      add_list_item(slot_name, "item", value);
   }

   /**
   * Get the slot number for a given slot name.
   * @param slot_name The name of the slot.
   * @return The slot number.
   */
   int slot_number(String slot_name) throws FrameException
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((PSESlot)slots.elementAt(i)).name.equals(slot_name) )
            return i;
      }
      throw new FrameException(FrameException.UNKNOWN_SLOT_NAME,
         slot_name + " in group " + group);
   }

   /**
   * Determine if a slot exists or not.
   * @param slot_name The slot name.
   * @return true if the slot exists, otherwise false.
   */
   boolean slot_exists(String slot_name)
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((PSESlot)slots.elementAt(i)).name.equals(slot_name) )
            return true;
      }
      return false;
   }

   public String toString()
   {
      try
      {
         return group + " " + summary();
      }
      catch (FrameException e)
      {
         return "error creating string";
      }
   }

   /**
   * Dump the contents of a frame into a string for printing.
   * This function uses the Java functions to determine the
   * Java type (class) of a value in a slot, and takes appropriate
   * action based on that information.  Vector elements are listed
   * as separate list item, and KnowledgeFrames are dealt with by
   * recursively calling toString() on them with an appropriate
   * level of indentation.  (Note that for non-KnowledgeArchive
   * values, the normal Java toString() method is used.)
   * @return The string.
   */
   String toFullString() throws FrameException
   {
      return toFullString(0);
   }

   String toFullString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("Group: " + group);
      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      if (key != null)
         sb.append("Key: " + key);
      else
         sb.append("Key: " + "null");

      if (is_integrated())
      {
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Create Date: " + get_create_date_string());
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Update Date: " + get_update_date_string());
      }

      if (is_stub())
      {
         sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
         sb.append("Slots stubbed out");
      }

      for (int i=0; i < slots.size(); i++)
         sb.append( ((PSESlot)slots.elementAt(i)).toFullString(indent) );

      return sb.toString();
   }

   /**
   * Dump the contents of a frame into a tagged string for easy
   * parsing.
   * @return The string.
   */
   public String toXMLString() throws FrameException
   {
      return "<?XML version=\"1.0\" standalone=\"yes\"?>" + "\n" + 
         toTaggedString(0);
   }

   /**
   * Dump the contents of a frame into a tagged string for easy
   * parsing.
   * @return The string.
   */
   String toTaggedString() throws FrameException
   {
      return toTaggedString(0);
   }

   String toTaggedString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer(512);
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("<KnowledgeFrame group=\"" + group_name() + "\"");
      if (get_key() != null)
         sb.append(" key=\"" + get_key() + "\"");
      sb.append(">");

      if (is_integrated())
         sb.append( system.toTaggedString(indent+2) );

      for (int i=0; i < slots.size(); i++)
         sb.append( ((PSESlot)slots.elementAt(i)).toTaggedString(indent) );

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("</KnowledgeFrame>");
      return sb.toString();
   }


   //----------------------------------------------------------
   // Functions relating to the system frame in the system
   // slot, or intended for internal use.  These need to
   // be somehow broken out.

   /**
   * Sets a full slot at a given position.  Note that this
   * method does not change the update date, as it is only
   * intended to be used for internal maintenance of a frame.
   * @param i The position for the slot.
   * @param s The slot to replace.
   */
   void set_slot(int i, PSESlot s) throws FrameException
   { slots.setElementAt(s, i); }


   /**
   * Test if the frame is integrated into the library, meaning
   * it is in its own group.
   */
   boolean is_integrated() throws FrameException
   {
      if ( system == null )
         return false;
      else
         return true;
   }

   /**
   * Get the system frame.
   */
   PSEFrame system_frame()
   {
      // Usually the caller has checked if the frame is integrated.
      return system;
   }

   /**
   * Each integrated frame has a subframe of system information
   * in slot 0, which can be set by this function.
   */
   void set_system(String slot_name, Object value) throws FrameException
   {
      if (! is_integrated())
         return;
      system_frame().set(slot_name, value);
   }

   /**
   * The system frame can be set with this function.
   */
   void set_system(PSEFrame system)
   {
      this.system = system;
   }

   /**
   * Get the value of a slot in the system subframe of
   * an integrated frame. Returns null if not an integrated
   * frame.
   */
   Object get_system(String slot_name) throws FrameException
   {
      if (! is_integrated())
         return null;
      return system_frame().get(slot_name);
   }

   void set_key(String k)
   { key = k; }
}
