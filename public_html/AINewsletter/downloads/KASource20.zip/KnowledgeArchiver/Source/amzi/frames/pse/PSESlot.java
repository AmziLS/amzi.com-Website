// PSESlot

package amzi.frames.pse;

import amzi.frames.*;
import amzi.ka.db.*;

import java.util.*;

import COM.odi.*;
import COM.odi.util.*;

/**
* PSE version of a slot.
* @author Amzi! inc.
*/
class PSESlot
{
   // Static information for testing slot types

   static transient Class list_class;
   static transient Class frame_class;
   //static transient Class code_class;
   static transient Class cLong;
   static transient Class cShort;
   static transient Class cFloat;
   static transient Class cString;
   static transient Class cDouble;
   static transient Class cInteger;
   static transient Class cBoolean;
   static transient Class cVector;
   static transient Class cOSVector;

   static
   {
      try
      {
         list_class = Class.forName("amzi.frames.pse.PSEList");
         frame_class = Class.forName("amzi.frames.pse.PSEFrame");
         //code_class = Class.forName("amzi.ka.db.PSECode");
         cLong = Class.forName("java.lang.Long");
         cShort = Class.forName("java.lang.Short");
         cFloat = Class.forName("java.lang.Float");
         cString = Class.forName("java.lang.String");
         cDouble = Class.forName("java.lang.Double");
         cInteger = Class.forName("java.lang.Integer");
         cBoolean = Class.forName("java.lang.Boolean");
         cVector = Class.forName("java.util.Vector");
         cOSVector = Class.forName("COM.odi.util.OSVector");
      }
      catch (Exception e)
      {}
   }

   // The actual slot values

   String name = "";
   Object value = null;

   // Constructors and creators for PSESlots
   // are TransientSlots.

   PSESlot(KnowledgeSlot s) throws FrameException
   {
      name = s.name();
      Object o = s.value();
      if (s.is_list())
         value = new PSEList( (KnowledgeList)o );
      else if (s.is_frame())
         value = new PSEFrame( (KnowledgeFrame)o );
      else if (o.getClass() == cVector)
      {
         Vector v = (Vector)o;
         OSVector osv = new OSVector( v.size() );
         for (int i=0; i<v.size(); i++)
            osv.addElement(v.elementAt(i));
         value = osv;
      }
      else
         value = o;
   }

   KnowledgeSlot make_KnowledgeSlot() throws FrameException
   {
      Object o;

      if (value == null)
         return new KnowledgeSlot(name, null);

      Class c = value.getClass();

      if (c == PSESlot.frame_class)
         o = ((PSEFrame)value).make_KnowledgeFrame();
      else if (c == PSESlot.list_class)
         o = ((PSEList)value).make_KnowledgeList();
      //else if (c == PSESlot.code_class)
      //   o = ((PSECode)value).makeCode();
      else if (c == cOSVector)
      {
         OSVector osv = (OSVector)value;
         Vector v = new Vector( osv.size() );
         for (int i=0; i<osv.size(); i++)
            v.addElement(osv.elementAt(i));
         o = v;
      }
      else
         o = value;
      return new KnowledgeSlot(name, o);
   }

   // Constructors

   public PSESlot()
   {
      name = "item";
      value = null;
   }

   public PSESlot(String name)
   {
      this.name = name;
      this.value = null;
   }

   public PSESlot(String name, Object value)
   {
      this.name = name;
      this.value = value;
   }

   /**
   * Get the name of this slot.
   * @return The name.
   */
   String name() { return name; }

   /**
   * Get the value of this slot.
   * @return The value.
   */
   Object value() { return value; }

   /**
   * Change the value of this slot.
   * @param v The new value.
   */
   void set_value(Object v) { value = v; }

   /**
   * If this slot's value is a KnowledgeList, add
   * this slot to the list.
   * @param s The slot to add.
   * @throws FrameException if the slot is not a list.
   */
   void add_value(PSESlot s) throws FrameException
   {
      if (is_list())
         ((PSEList)value).add_slot(s);
      else
         throw new FrameException(this, FrameException.NOT_A_LIST_SLOT, name);
   }

   /**
   * Is the value a KnowledgeFrame.
   * @return true if value is a frame, otherwise false.
   */
   boolean is_frame()
   {
      if (value.getClass() == frame_class)
         return true;
      else
         return false;
   }

   /**
   * Is the value a KnowledgeList.
   * @return true if value is a list, otherwise false.
   */
   boolean is_list()
   {
      if (value.getClass() == list_class)
         return true;
      else
         return false;
   }

   /**
   * Return a summary string suitable for presentation in a GUI. The
   * string is just an identification, and is not intended to be a full
   * dump of the contents of the slot, which might be KnowledgeFrame
   * or KnowledgeList.
   * @return The summary string.
   * @throws A FrameException if there is a problem getting the summary.
   */
   String summary() throws FrameException
   {
      if (is_frame())
         return ((PSEFrame)value).summary();
      else if (is_list())
         return "";
      else
         return value.toString();
   }

   /**
   * An implementation of toString that returns the summary
   * string for this slot.
   * @return The summary string, or null if an error occurred
   * getting it.
   */
   public String toString()
   {
      try
      {
         return name + ": " + summary();
      }
      catch (FrameException e)
      {
         return null;
      }
   }

   /**
   * Return a fully indented string suitbable for displaying the
   * contents of the slot.  This routine is part of a recursive
   * set of similar calls in KnowledgeFrame and KnowledgeList.
   * @param indent The amount of space to indent on an output line.
   * @return The string.
   */
   String toFullString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer();
      int k;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append(name + ": ");

      if (is_list())
         sb.append( ((PSEList)value).toFullString(indent+1) );
      if (is_frame())
         sb.append( ((PSEFrame)value).toFullString(indent+1) );
      else
         sb.append( value.toString() );

      return sb.toString();
   }

   /**
   * A starting position for toFullString(int).
   */
   String toFullString() throws FrameException
   {
      return toFullString(0);
   }

   /**
   * Return a tagged string suitbable for dumping and reloading
   * Knowledge objects.
   * @param indent Indentation for readability
   * @return The string.
   */
   String toTaggedString(int indent) throws FrameException
   {
      StringBuffer sb = new StringBuffer();
      int k;
      String jtype, katype;
      Class c = null;

      sb.append("\n"); for (k=0; k<indent; k++) sb.append("  ");
      sb.append("<Slot name='" + name + "'>");

      if (is_list())
         sb.append( ((PSEList)value).toTaggedString(indent+1) );
      if (is_frame())
         sb.append( ((PSEFrame)value).toTaggedString(indent+1) );
      else
      {
         katype = null;
         if      (c == cLong)  katype = "Long";
         else if (c == cShort)  katype = "Short";
         else if (c == cFloat)  katype = "Float";
         else if (c == cString)  katype = "String";
         else if (c == cDouble)  katype = "Double";
         else if (c == cInteger)  katype = "Integer";
         else if (c == cBoolean)  katype = "Boolean";

         if (katype != null)
         {
            sb.append("<" + katype + ">");
            sb.append(toXML(value.toString()));
            sb.append("</" + katype + ">");
         }
         else
         {
            jtype = value.getClass().getName();
            sb.append("<JavaClass type=\"" + jtype + "\">");
            sb.append(toXML(value.toString()));
            sb.append("</JavaClass>");
         }
      }

      sb.append("</Slot>");
      return sb.toString();
   }

   /**
   * A starting position for toFullString(int).
   */
   String toTaggedString() throws FrameException
   {
      return toTaggedString(0);
   }

   /**
   * Replace < and > with &GT and &LT for XML output.
   * Also note that ampersands, less thans, greater thans,
   * apostophres and quotes all need to be represented
   * in the data as &amp; &lt; &gt; &apos; &quot;
   */
   private String toXML(String in)
   {
      StringBuffer out = new StringBuffer("");
      for (int i=0; i<in.length(); i++)
      {
         char c = in.charAt(i);
         switch (c)
         {
         case '&':
            out.append("&amp;"); break;
         case '<':
            out.append("&lt;"); break;
         case '>':
            out.append("&gt;"); break;
         case '\'':
            out.append("&apos;"); break;
         case '\"':
            out.append("&quot;"); break;
         default:
            out.append(c);
         }
      }
      return out.toString();
   }
}

