import java.io.*;

public class x1
{
   public static void main(String[] args)
   {
      Long l = new Long(3);
      System.out.println("l class is: ");
      System.out.println(l.getClass().getName());
      System.out.println("done");
   }
}