// QueryFrame

package amzi.frames;

import java.util.*;
import java.io.*;

public class QueryFrame implements Serializable
{
   String group;
   Vector system;
   Vector slots;
   String key;

   public QueryFrame(String group)
   {
      this.group = group;
      system = new Vector(5,5);
      slots = new Vector(5,5);
      key = null;
   }

   public String group_name() { return group; }

   public void set(String slot_name, QueryOp query_op)
   {
      slots.addElement(new QuerySlot(slot_name, query_op));
   }

   public void set_key(String k) { key = k; }
   public String get_key() { return key; }

   public QuerySlot slot_at(int i)
   {
      return (QuerySlot)slots.elementAt(i);
   }

   public int size()
   {
      return slots.size();
   }

   // Queries for the system slots of a frame.

   public void set_system(String slot_name, QueryOp query_op)
   {
      system.addElement(new QuerySlot(slot_name, query_op));
   }

   public QueryOp get_system(String slot_name) throws FrameException
   {
      return ((QuerySlot)system.elementAt(system_slot_number(slot_name))).query_op;
   }

   public QuerySlot system_slot_at(int i) throws FrameException
   {
      return (QuerySlot)system.elementAt(i);
   }

   public int get_system_size()
   {
      return system.size();
   }

   /**
   * Get the slot number for a given slot name.
   * @param slot_name The name of the slot.
   * @return The slot number.
   */
   private int slot_number(String slot_name) throws FrameException
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((QuerySlot)slots.elementAt(i)).name.equals(slot_name) )
            return i;
      }
      throw new FrameException(FrameException.UNKNOWN_SLOT_NAME, slot_name);
   }

   /**
   * Get the slot number for a given slot name.
   * @param slot_name The name of the slot.
   * @return The slot number.
   */
   private int system_slot_number(String slot_name) throws FrameException
   {
      for (int i=0; i < slots.size(); i++)
      {
         if ( ((QuerySlot)system.elementAt(i)).name.equals(slot_name) )
            return i;
      }
      throw new FrameException(FrameException.UNKNOWN_SLOT_NAME, slot_name);
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }

}