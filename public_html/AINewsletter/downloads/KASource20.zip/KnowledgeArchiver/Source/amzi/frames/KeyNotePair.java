// KeyNotePair.java

package amzi.frames;

import java.io.*;

/**
 * A class designed to hold a KnowledgeFrame key and a descriptive
 * summary for the frame.  These will be returned in vectors for
 * client browsing of a KnowledgeGroup.
 * For example, the descriptive text might be a person frame
 * might be the person's name, and a browser would present the
 * user with a list of frames identified by person name.  When
 * one was selected, the key is then used to retrieve the
 * full frame.
 *
 * @author  Amzi! inc.
 */
public class KeyNotePair implements Serializable
{
   String key;
   String summary;

   /**
    * Constructor must have both key and note.
    *
    * @param key The frame key.
    * @param summary Descriptive text
    */
   public KeyNotePair(String key, String summary)
   {
      this.key = key;
      this.summary = summary;
   }

   public String get_key() { return key; }
   public String summary() { return summary; }

   public String toString()
   {
      return summary;
   }

   // Implementation of the Serializable interface

   protected void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   protected void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}