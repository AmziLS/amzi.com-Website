// ggLog.java

package amzi.ka.gg;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

import java.awt.event.*;
import java.io.*;
import java.awt.*;
import java.util.*;

class ggLog extends JInternalFrame
{
   BrowserContainer mf;
   JTextArea text;

   ggLog(BrowserContainer mf) throws Exception
   {
      super("Log", true, true, true, true);
      this.mf = mf;
      mf.register(this);
      ui_init();
   }

   void ui_init() throws Exception
   {
      addInternalFrameListener(new logFrameListener(this));
      text = new JTextArea();
      JScrollPane s = new JScrollPane(text);
      getContentPane().add("Center", s);
	  setSize(405,305);
   }

   public void write(String s)
   {
      text.append(s);
      try {
        setSelected(false);
      } catch (Exception e) {};
   }

   public void writeln(String s)
   {
      text.append(s + "\n");
      try {
        setSelected(false);
      } catch (Exception e) {};
   }

   //----------------------------------
   // inner classes for listeners etc.
   //

   private class logFrameListener extends InternalFrameAdapter
   {
      private ggLog m_log;
      
      public logFrameListener(ggLog log) {
         m_log = log;
      }
      
      public void internalFrameClosing(InternalFrameEvent e)
      {
         MainFrame.println("Frame closed: log");
         mf.deregister(m_log);
      }
   }
}
