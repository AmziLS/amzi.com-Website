/**
 * KASocketServer
 *
 * @author  Amzi! inc.
 */

package amzi.ka.server;

import amzi.frames.*;
import amzi.ka.*;
import java.net.*;
import java.io.*;

public class KASocketServer extends Thread
{
   ServerSocket  ss_socket;
   boolean       ss_listen;
   GEKOLibrary   gl;
   static int    listen_port = 1001;

   public static void main(String args[])
   {
      try
      {
         KASocketServer ss = new KASocketServer(listen_port);
         ss.start();

         BufferedReader din =
            new BufferedReader(new InputStreamReader(System.in));

         ss.display_help();
         System.out.print("KAServer>");
         String command = din.readLine();

         while (! command.equals("exit"))
         {
            if (command.equals("report"))
               ss.report_threads();
            else
               ss.display_help();

            System.out.print("KAServer>");
            command = din.readLine();
         }
         ss.stop_listening();
      }
      catch (IOException e)
      {
         System.out.println("KAServer IO Error");
      }
      catch (Exception e)
      {
         System.out.println("Some kind of exception: " + e.getMessage());
      }
      finally
      {
         System.out.println("quitting");
         System.exit(0);
      }
   }

   public KASocketServer(int port)
   {
      try
      {
         ss_socket = new ServerSocket(port);
         ss_listen = true;
      }
      catch (IOException e)
      {
         System.out.println("KAServer IO Error opening ServerSocket");
      }
   }

   private static void display_help() throws IOException
   {
      System.out.println("The Knowledge Archive Socket Server supports");
      System.out.println("the following commands:");
      System.out.println("  help     - shows this information");
      System.out.println("  report   - shows information of interest");
      System.out.println("  exit     - exits the Knowledge Archiver");
   }

   public void report_threads()
   {
      System.out.println("Nothing to report now");
   }

   public void stop_listening()
   {
      ss_listen = false;
   }

   public void run()
   {
      try
      {
         gl = new GEKOLibraryI_PSE();
         gl.initialize();
      }
      catch (FrameException e)
      {
         System.out.println("Error starting socket server: "
            + e.getMessage());
         return;
      }

      Socket sock;

      try
      {
         while (ss_listen)
         {
            sock = ss_socket.accept();
            System.out.println("Server Connected");

            new KAThread(sock, gl, this).start();
         }

         System.out.println("Server shutting down");
         ss_socket.close();
      }
      catch (IOException e)
      {
         System.out.println("KAServer IO Error while listening for sockets");
      }
      catch (FrameException e)
      {
         System.out.println("FrameException error while listening: " + e.getMessage());
         e.printStackTrace();
      }
   }
}
