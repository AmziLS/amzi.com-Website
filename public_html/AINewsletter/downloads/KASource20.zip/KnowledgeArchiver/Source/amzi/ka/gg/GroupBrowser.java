package amzi.ka.gg;

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;
import java.beans.*;

public class GroupBrowser extends Browser 
implements ActionListener, PropertyChangeListener {
    
    KnowledgeFrame m_frame = null;
    private GEKOClientI m_lib; // The client library for this session
    private String m_archive_name;
    
    public GroupBrowser(GEKOClientI lib, BrowserContainer bc, String archivename) {
        m_lib = lib;        
        m_archive_name = archivename;
        init(null, "", bc);
    }

    public void init(KnowledgeFrame f, String filename, BrowserContainer bc) {
        JPanel bpanel = new JPanel(new FlowLayout());       

        super.init(f, filename, bc);     
        
        m_left_panel.add("South", bpanel);
        m_tree.setRootVisible(false);
        try {
            Vector groups = m_lib.get_groups();
            for(int i=0; i<groups.size(); i++) {
                m_root.add(new DefaultMutableTreeNode(groups.elementAt(i)));
            }
        } catch (Exception e) {
            MainFrame.println("GroupBrowser:init():" + e);
        }
        m_tree.expandPath(new TreePath(m_root));         
        setTitle("Groups in " + m_archive_name);       
        // for frame upload events
        bc.getPropertyChange().addPropertyChangeListener(this);
    }
    
    public Object getBrowsedObjectForDisplay() {
        return m_tree.getSelectionPath().getLastPathComponent();
    }

    public BrowserEditor getBrowserEditor(Object node) {
        return new GroupsEditor(this, m_lib, m_browser_container);
    }    
    
    public void actionPerformed(ActionEvent e) {
        Cursor old_curse = m_browser_container.getCursor();
        m_browser_container.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        
        if (e.getActionCommand().equals("query")) {
            QBEBrowser b;
            b = new QBEBrowser(m_lib, m_browser_container, (String)getBrowsedObjectForDisplay().toString());
            m_browser_container.register(b);
            b.getPropertyChangeSupport().addPropertyChangeListener(this);
            setVisible(false);
        }
        m_browser_container.setCursor(old_curse);        
    }
    
    public void propertyChange(PropertyChangeEvent evt) {
        String propname = evt.getPropertyName();
        
        if (propname.equals("queryresults")) {
            // A query was performed or the query was abandoned
            QueryResults results = (QueryResults) evt.getNewValue();
            if (null == results) { // Abandoned
                setVisible(true);
            } else { // results has our vector of KeynotePairs in it
                ((GroupsEditor)m_current_editor).populate(results.getResults());
                setVisible(true);
            }
        } else if (propname.equals("groupchange")) {
            // Some browser uploaded a frame somewhere
            String group = evt.getNewValue().toString();
            GroupsEditor ed = (GroupsEditor)m_current_editor;
            // Am I displaying this group ??
            String groupdisplayed = ((DefaultMutableTreeNode)getBrowsedObjectForDisplay()).getUserObject().toString();
            // then repopulate it
            if (groupdisplayed.trim().equals(group.trim())) {
                try {
                    ed.populate();
                } catch (Exception e) {};
            }
        }
    }
    
    // Enable our query buttoin when we have made a selection
    public void valueChanged(TreeSelectionEvent e) {
        super.valueChanged(e);
    }
} 