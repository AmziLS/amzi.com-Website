/*
		A basic implementation of the JInternalFrame class.
*/
package amzi.ka.gg;


import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;


import amzi.ka.*;
import amzi.frames.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;
import amzi.ka.gg.editors.*;

public class KnowledgeFrameBrowser extends Browser implements ActionListener {
    // A browser is a tree and a panel on which context sensitive
    // things happen. This one knows about knowledge frames

    /// The frame
    KnowledgeFrame m_frame = null;
    KnowledgeFrameCellRenderer m_cell_renderer;
    TreeFrameMapper m_tfm;
    // The schema for this frame ...
    KnowledgeFrame m_schema_frame;
    // The filename of file that created the frame
    String m_filename = "";
    JMenuBar m_menu;    
    JMenu m_fileMenu, m_elementMenu, m_helpMenu;    
    JMenuItem m_fileCloseItem, m_fileUploadItem, m_fileUploadCloseItem,
              m_fileSaveItem, m_fileSaveAsItem, m_fileCloseAndInsertItem;
    JMenuItem m_elementNewElementItem, m_elementArchivedElementItem, 
              m_elementEditElementItem, m_elementDeleteElementItem;
    JMenuItem m_helpProcedureItem, m_helpSlotItem;
    
	public KnowledgeFrameBrowser() {}
	
	public KnowledgeFrameBrowser(boolean embedded) {
	    super(embedded);
	}

    /** 
    * Build the tree structure from the KF
    */
    public void init(KnowledgeFrame g, String filename, BrowserContainer bc) {
        super.init(g, filename, bc);
        m_tree.setRootVisible(false); 
        m_frame = g;        
        if (null != g.get_key())
            setColor(Color.red);        
        if (! m_embedded) {
            String title = "[" + g.group_name() + "] ";
            try {
                if ("".equals(g.summary().trim()))
                    title = title + "<new frame>";
                else
                    title = title + g.summary().trim();
            } catch (Exception e) {
                title = title + "UNKNOWN FRAME";
            }
                
            if (null == g.get_key())
                setTitle("Workspace Element: " + title);
            else
                setTitle("Archived Element: " + title);
        }
        m_tfm = new TreeFrameMapper(m_tree, g, bc.getSchemaSource());            
        m_tree.setModel(new GGTreeModel(m_root, m_tfm));
        m_tree.setCellRenderer(m_cell_renderer = new KnowledgeFrameCellRenderer(this));
        m_tree.expandPath(new TreePath(m_root));
        GekkoTreeNode gekoroot;
        m_root.setUserObject(gekoroot = new GekkoTreeNode("Root"));
        // Fore completeness -- the whole frame is associated with the (hidden) node "root"
        m_tfm.map(gekoroot, g);
        addMenus();
        
    } 

    private void addMenus() {
		m_menu = new JMenuBar();
 
  		m_fileMenu = new javax.swing.JMenu();
		m_fileMenu.setText("Browser");
		m_fileMenu.setActionCommand("File");
		m_fileMenu.setMnemonic('b');
		m_fileMenu.setAlignmentY(0.5F);
		m_fileMenu.setAlignmentX(0.5F);
		m_fileMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);		
		
		m_menu.add(m_fileMenu);
 
 		m_fileCloseItem = new GMenuItem(this, "Close", "close", "Close browser", 'c');
		m_fileMenu.add(m_fileCloseItem);
 
 		m_fileUploadItem = new GMenuItem(this, "Upload", "upload", "Upload to archive", 'u');
	    m_fileMenu.add(m_fileUploadItem);

 		m_fileUploadCloseItem = new GMenuItem(this, "Upload&Close", "uploadandclose", "Upload to archive the close browser", 'p');
//	    m_fileMenu.add(m_fileUploadCloseItem);
		
 		m_fileCloseAndInsertItem = new GMenuItem(this, "Close and Insert", "closeandinsert", "Insert frame in target slot then close", 'i');
    	m_fileCloseAndInsertItem.setEnabled(false);
	    m_fileMenu.add(m_fileCloseAndInsertItem);
		
 		m_fileSaveItem = new GMenuItem(this, "Save", "save", "Save knowledge frame to its file", 's');
		m_fileMenu.add(m_fileSaveItem);
		
 		m_fileSaveAsItem = new GMenuItem(this, "SaveAs", "saveas", "Save knowledge frame to new file", 'a');
		m_fileMenu.add(m_fileSaveAsItem);
    
 		m_elementMenu = new javax.swing.JMenu();
		m_elementMenu.setText("Element");
		m_elementMenu.setActionCommand("Element");
		m_elementMenu.setMnemonic('e');
		m_elementMenu.setAlignmentY(0.5F);
		m_elementMenu.setAlignmentX(0.5F);
		m_elementMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);		
		m_menu.add(m_elementMenu);
 
 		m_elementNewElementItem = new GMenuItem(this, "Insert New Element", "newelement", "Replace current selection with new archival component", 'n');
		m_elementMenu.add(m_elementNewElementItem);
 
 		m_elementArchivedElementItem = new GMenuItem(this, "Insert Archived Element", "archivedelement", "Replace current selection with archival component", 'a');
		m_elementMenu.add(m_elementArchivedElementItem);
 
 		m_elementEditElementItem = new GMenuItem(this, "Edit Element", "editelement", "Edit the current archival selection", 'e');
		m_elementMenu.add(m_elementEditElementItem);
  
 		m_elementDeleteElementItem = new GMenuItem(this, "Delete Element", "deleteelement", "Remove an item from a list", 'd');
		m_elementMenu.add(m_elementDeleteElementItem);        

 		m_helpMenu = new javax.swing.JMenu();
		m_helpMenu.setText("Help");
		m_helpMenu.setActionCommand("Help");
		m_helpMenu.setAlignmentY(0.5F);
		m_helpMenu.setAlignmentX(0.5F);
		m_helpMenu.setMnemonic('h');
		m_helpMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);		
		m_menu.add(m_helpMenu);
		
 		m_helpProcedureItem = new GMenuItem(this, "Procedures", "procedurehelp", "Get help on general procedures", 'p');
		m_helpMenu.add(m_helpProcedureItem);        
		
 		m_helpSlotItem = new GMenuItem(this, "Slot", "slothelp", "Get help on selected frame slot", 's');
		m_helpMenu.add(m_helpSlotItem);        

		setInsertableNode(false);
		setEditableNode(false);
		m_elementDeleteElementItem.setEnabled(false);
		
		if (! m_embedded)
		    setJMenuBar(m_menu);
    }
    
    /**
    * Set up insert menu
    */
    public void setTarget(Browser b, Object val) {
        super.setTarget(b, val);
    	m_fileCloseAndInsertItem.setEnabled(true);    
    	m_fileUploadItem.setEnabled(false);
    	m_fileUploadCloseItem.setEnabled(false);
    }   
    
    /*
    * Set menus options to match archival insertability
    */
    protected void setInsertableNode(boolean i) {
        if (i) {
            m_elementNewElementItem.setEnabled(true);
            m_elementArchivedElementItem.setEnabled(true);
        } else {
            m_elementNewElementItem.setEnabled(false);
            m_elementArchivedElementItem.setEnabled(false);
        }
    }
    
    protected void setNewNode(boolean i) {
        if (i) 
            m_elementNewElementItem.setEnabled(true);
        else
            m_elementNewElementItem.setEnabled(false);
    }
        
    /*
    * Set menu options to refkect archival editability 
    */
    protected void setEditableNode(boolean e) {
        if (e) {
		    m_elementEditElementItem.setEnabled(true);
		} else {
		    m_elementEditElementItem.setEnabled(false);		    
		}
    }
    
    /*
    * Set menu options to reflect list deleteability 
    */
    protected void setDeleteableNode() {
        try {
            Object val = m_tfm.getPathedObject(m_tree.getSelectionPath().getParentPath());
            setDeleteableNode(val instanceof KnowledgeList);
		} catch (Exception e) {
 	        m_elementDeleteElementItem.setEnabled(false);				    
 	    }
    }
    
    protected void setDeleteableNode(boolean d) {
        if (d) {
		    m_elementDeleteElementItem.setEnabled(true);
        } else {
	        m_elementDeleteElementItem.setEnabled(false);		    
	    }
    }
    
        
    // Is the frame component archival ??
    protected boolean isArchival(Object obj) {
        if (null == m_browser_container.getSession())
            return false;
        if (null == obj) {
            return false;
        }
        else if (obj instanceof KnowledgeList)
            return true;
        else if (obj instanceof KnowledgeFrame) {
            // Hardwire for now -- should really check groups !!
            String group = ((KnowledgeFrame)obj).group_name();
            if (group.equals("person") || group.equals("variable") ||
                group.equals("citation") || group.equals("keyword"))
                return true;
            else
                return false;
        } else {
            // Dennis -- please let me go up the knowledge frame tree
            /// oh, please, please please ... ah, well ..
            /******* I HAVE A STUPID DESIGN PROBLEM HERE WHICH TOTALLY
            ****  CAUGHT ME OUT AT THE LAST MOMENT. IT TURNS OUT THAT
            ****  BY FLUKE I WAS DECIDING SOMETHING ISN'T ARCHIVAL SIMPLE
            ****  BY THE FACT IT HAS A NULL PARENT (I.E. m_tfm THINKS
            ****  IS IS THE TOP OF THE TREE -- WHICH, OF COURSE, IT WILL
            ****  BE. I HAVE NO IDEA WHERE WHY HEAD WAS ON THIS ONE, __BUT__
            ****  I IMPROVED THE CODE BY ADDING A DUMMY GEKKOTREENODE AT THE
            ****  TOP (SEE INIT() ABOVE) WHICH PROMPTLY MEANS I CAN'T EDIT
            ****  ANYTHING. THEN WASTED 6 HOURS TRYING TO FIND OUT WHAT HAPPENED ..
            ****  SO THE FOLLOWING IS &&&&&HACK&&&&&&
            */
            if (m_tree.getSelectionPath().getParentPath().getLastPathComponent() == m_root)
                return false;
            /***** end of hack *****/
            
            try { // Parent is frame or list so no recursion possible
                return isArchival(m_tfm.getPathedObject(m_tree.getSelectionPath().getParentPath()));            
            } catch (Exception e) {
            }
        }
        return false;        
    }
    
    /** Do we have a generated==true slot in the schema of object i.e.
    * is the frame obj auto-generated
    */
    protected boolean isGenerated(Object obj) {
        TreeNodeSchema tns;
        
        if (null == obj) {
            return false;
        }        
        tns = m_tfm.getTreeNodeSchema(obj);
        if (null != tns)
            if ("true".equals(tns.get("generated")))
                return true;
        return false;
    }
    
    public TreeFrameMapper getTreeFrameMapper() {
        return m_tfm;
    }

    public SchemaSource getSchemaSource() {
        return m_browser_container.getSchemaSource();
    }
    
    // Synch tree and frame back. The frame which had oldvalue
    // as a slot value now has that slot value set to newvalue. Update
    // the GekkoBrowser's tree accordingly
    public void resynch(Object oldvalue, Object newvalue) {
        m_tfm.resynch(oldvalue, newvalue);
    }
    
    public Object getBrowsedObject() throws Exception {
        return m_tfm.getBrowsedObject();
    }
    
    /**
    * Return the browsed object i.e. the Gekko -- we do a bit of fancy stuff
    * here to make the ui more intuitive
    */
    public Object getBrowsedObjectForDisplay() {
        Object obj = null;
        boolean archival, generated, fungible, localeditable;
        try {
            obj = getBrowsedObject();
            archival = isArchival(obj);
            generated = isGenerated(obj);
            fungible = (! generated) &&  archival;
            localeditable = (! generated) && (! archival);
            if (null == obj) {
                setInsertableNode(false);
                setEditableNode(false);
                setDeleteableNode(false);
                m_current_editor.setEnabled(false);
                return "";
            } else if (obj instanceof KnowledgeSlot) {
                setInsertableNode(fungible);
                setEditableNode(fungible);
                setDeleteableNode(false);
                m_current_editor.setEnabled(localeditable);
                return obj;                
            } else if (obj instanceof KnowledgeFrame) {
                setInsertableNode(fungible);
                setEditableNode(fungible);
                if (! generated)
                    setDeleteableNode(); // complex decision
                else
                    setDeleteableNode(false);
                m_current_editor.setEnabled(false);
                return "";
            } else if (obj instanceof KnowledgeList) {
                setInsertableNode(fungible);
                setEditableNode(false);
                setDeleteableNode(false);                
                m_current_editor.setEnabled(false);
                return "";
            } else {
                m_current_editor.setEnabled(true);
                setInsertableNode(false);
                setEditableNode(false);
                setDeleteableNode(false);
                return obj;
            }   
        } catch (Exception e) {
            MainFrame.println("KnowledgeFrameBrowser:getBrowsedObjectForDisplay():" + e + " :" + obj);
            return null;
        }
    }

        
    /**
    * Save back to the file the gekko came from (in XML format).
    * Will overwrite old contents
    */
    public void save() {
        if (0 == m_filename.length()) {
            saveas();
        } else {
            try {
                PrintWriter pw = new PrintWriter (new FileOutputStream(m_filename));
                pw.print(m_frame.toXMLString());
                pw.flush();
                pw.close();
            } catch (Exception e) {
                MainFrame.println("GekkoBrowser:save():" + e);
            }
        }
        setClean();
    }
    /**
    * Save to specified file (in XML format)
    */
    public void save(String filename) {
        try {
            PrintWriter pw = new PrintWriter (new FileOutputStream(filename));
            pw.print(m_frame.toXMLString());
            pw.flush();
            pw.close();
            m_filename = filename;
        } catch (Exception e) {
            MainFrame.println("GekkoBrowser:save():" + e);
        }
        setClean();
    }

    /** 
    * Specify a filename to save to ..
    */
    public void saveas() {
        JFileChooser fc = new JFileChooser(".");
        if (0 == fc.showSaveDialog(this)) {
            save(fc.getSelectedFile().toString());
        }          
        setClean();
    }
    
    /** Choose editor according to TreeNodeSchema type */
    
    public BrowserEditor getBrowserEditor(Object node) {
        GekkoTreeNode gtn;
        TreeNodeSchema tns = null;
        BrowserEditor ed = null;
        
        if (null != node) {
            gtn = (GekkoTreeNode) ((DefaultMutableTreeNode) node).getUserObject();        
            if (null != gtn) {
                tns = gtn.getTreeNodeSchema();
                if (null != tns) {
                    String type = tns.get("type");
                    String choice = tns.get("choices");                
                    if (null != choice) {
                        if (choice.trim().length() > 0) {
                            ed = new ChoiceEditor(choice);
                            ed.setBrowser(this);
                            return ed;
                        }
                    }
                    if (null == type)
                        ed = new TextAreaEditor();
                    else if ("text_line".equals(type))
                        ed = new TextLineEditor();
                    else if ("text_area".equals(type))
                        ed = new TextAreaEditor();
                    else // default
                        ed = new TextAreaEditor();
                } else // no schema
                    ed = new TextAreaEditor();
            }
        } else
            ed = new TextAreaEditor();
        
        ed.setBrowser(this);
        return ed;
    }
    
    /** Called when we are switching to edit in a browser -- obj is the
    * newly selected tree node
    */
    public void prepare(Object obj) {
    }

    /** Called when we are about to discard the editor -- gives us chance to clean
    * up any extant verification panel
    */
    public void prepare() {
    }
    
    // Make sure we can see the node
    public void expandTo(GekkoTreeNode node) {
        DefaultTreeModel model;
        TreePath path;
        
        model = (DefaultTreeModel) m_tree.getModel();
        path = new TreePath(model.getPathToRoot(node.getParent()));
        m_tree.expandPath(path);        
    }
    
    public void editSelectedElement() {
        KnowledgeFrame kf;
        KnowledgeFrameBrowser kfb;
        
        try {
            kf = (KnowledgeFrame) getBrowsedObject();
            kfb = new KnowledgeFrameBrowser();
            kfb.init(kf, "", m_browser_container);
            m_browser_container.register(kfb);
            kfb.setTarget(this, kf);            
        } catch (Exception e) {
            MainFrame.println("KnowledgeFrameBrowser:editSelectedElement(): " + e);
        }
    }
    /**
    * Open a new editor of appropriate type, edit component seperately
    * then whiz it up to the archive and back down to right place
    */    
    public void insertSelectedElement() 
    {
        Object val;
        KnowledgeFrame kf;
        String groupname = "";
        
        try {
            val = getBrowsedObject(); 
            if (val instanceof KnowledgeFrame) {
                kf = (KnowledgeFrame) val;
                groupname = kf.group_name();
            } else if (val instanceof KnowledgeList) {
                DefaultMutableTreeNode listnode;               
                listnode = (DefaultMutableTreeNode) m_tree.getSelectionPath().getLastPathComponent();
                groupname = ((GekkoTreeNode) listnode.getUserObject()).getTreeNodeSchema().getSchemaName();                
            }  
            // Now create a browser and set its "target" to val
            SchemaSource schema_source = m_browser_container.getSchemaSource();
            Schema schema;
            Browser b;

            try {
                schema = new Schema(schema_source.getSchema(groupname), schema_source);
                b = m_browser_container.addNewBrowser(schema.newFrame(schema.NO_DEFAULTS), groupname);            
                b.setTarget(this, val);
            } catch (Exception e0) {
                throw e0;
            }            
        } catch (Exception e) {
            MainFrame.println("KnowledgeFrameBrowser:insertSelectedElement(): " + e);
        }        
    }
    
    /**
    * The current selection must be a slot in a list. Delete it
    * and re-jigger the browser's tree
    */    
    private void deleteSelectedElement() {
        // Sadly we can't get to the parent on the
        // kf side, so walk up to parent on treenode
        // side, check it is a list, then go back
        // to object and delete the correponding kf
        // object from the delete the child on the tree side
        Object val;
        int i;
        GekkoTreeNode gtn;
        KnowledgeList kl;
        try {
            val = m_tfm.getPathedObject(m_tree.getSelectionPath().getParentPath());
            if (val instanceof KnowledgeList) {
                kl = (KnowledgeList)val;
                val = getBrowsedObject();
                for ( i = 0; i < kl.length(); ++i) {
                    if (kl.slot_at(i).value() == val) {
                        kl.remove_slot_at(i);
                        ((DefaultTreeModel) m_tree.getModel()).removeNodeFromParent(
                                        (DefaultMutableTreeNode)m_tree.getSelectionPath().getLastPathComponent());
                        break;
                    }
                }
                ((DefaultTreeModel) m_tree.getModel()).nodeStructureChanged((DefaultMutableTreeNode) m_tfm.getTreeNode(kl).getParent());                    
                for (i = 0; i < kl.length(); ++i) {
                    val = kl.slot_at(i).value();
                    gtn = m_tfm.getTreeNode(val);
                    gtn.setLabel(m_tfm.ITEM_PREFIX + i);
                }
                setDirty();
            } else {
                throw new Exception();
            }
        } catch (Exception e) {
            ErrorMessage.message(this, ErrorMessage.EM_NOT_LIST_ITEM);
        }            
    }
    
    /** We must have a selection in the tree that corresponds to
    * either a list with archived elements or an archived frame. 
    * Open up a group browser on only and add to (list) or replace (frame)
    * the selected element with th elicked element
    */
    private void insertArchivedElement() {
        Object targetobject;
        KnowledgeFrame kf;
        String group;
        GroupsEditor ge;
        try {
            targetobject = getBrowsedObject(); 
            if (targetobject instanceof KnowledgeFrame) {
                kf = (KnowledgeFrame) targetobject;
                group = kf.group_name();
            } else if (targetobject instanceof KnowledgeList) {
                DefaultMutableTreeNode listnode;
                
                listnode = (DefaultMutableTreeNode) m_tree.getSelectionPath().getLastPathComponent();
                group = ((GekkoTreeNode) listnode.getUserObject()).getTreeNodeSchema().getSchemaName();
            } else {
                ErrorMessage.message(this, ErrorMessage.EM_BAD_ITEM);
                return;                
            } 
            // Now do it
            ge = ((new ArchivalElementPicker(m_browser_container.getSession().getLib(), 
                            m_browser_container))).pickArchivalElement(
                                 this, group, "Group: " + group, "Select a " + group);
            if (null != ge) {
                updateTarget(ge.getSelectedFrame(), targetobject);
            }
        } catch (Exception e) {
            MainFrame.println("KnowledgeFrameBrowser:insertArchiveElement(): " + e);
        }        
    }
    
    // val is either a list or subframe in m_frame. frame is being
    // resp added to it or replaces it. Called by a browser which has
    // created the frame and has just uploaded it
    public void updateTarget(KnowledgeFrame frame, Object targetobject) throws Exception {
        Object parval;
        KnowledgeFrame kf, kf2;
        KnowledgeSlot ks;
        KnowledgeList kl;
        GekkoTreeNode gtn;
        DefaultMutableTreeNode dtn, newnode,listnode;
        
        if (targetobject instanceof KnowledgeFrame) {
            kf = (KnowledgeFrame) targetobject;
            dtn = (DefaultMutableTreeNode)( m_tfm.getTreeNode(targetobject).getParent().getParent());
            parval = m_tfm.getMappedObject((GekkoTreeNode)dtn.getUserObject());
            if (parval instanceof KnowledgeList) {
                kl = (KnowledgeList)parval;
                for (int i = 0; i < kl.length(); ++i) {
                    if (kl.slot_at(i).value() == targetobject) {
                        kl.slot_at(i).set_value(frame);
                        break;
                    }
                }
            } else if (parval instanceof KnowledgeFrame) {
                kf2 = (KnowledgeFrame) parval;
                for (int i = 0; i < kf2.size(); ++i) {
                    if (kf2.slot_at(i).value() == targetobject) {
                        kf2.slot_at(i).set_value(frame);
                        break;
                    }
                }                    
            } else {
                MainFrame.println("KnowledgeFrameBrowser:updateTarget(): Parent is neither list nor frame");
                return; // Before doing damage
            }
            resynch(kf, frame);                        
        } else if (targetobject instanceof KnowledgeList) {               
            listnode = (DefaultMutableTreeNode)( m_tfm.getTreeNode(targetobject).getParent());            
            newnode = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(m_tfm.ITEM_PREFIX + listnode.getChildCount()));
            gtn.setParent(newnode);
            kl = (KnowledgeList)targetobject;
            kl.add_slot(ks = new KnowledgeSlot("index", frame));    
            m_tfm.buildTree(newnode, frame);
            listnode.add(newnode);
            m_tfm.map(gtn, frame);        
            ((DefaultTreeModel) m_tree.getModel()).nodeStructureChanged(listnode);
        } else {
        }
        setDirty();
    }
    
    /** Upload the frame to the archive, clean the browser and
    * notify listeners that a frame put event has occured
    * (so any group browsers can redisplay if they need to)
    */
    public GEKOClientI uploadFrame(KnowledgeFrame frame) throws Exception  {
        GEKOClientI lib = m_browser_container.getSession().getLib();        
        lib.put_frame(frame);
        setClean();
        m_property_change.firePropertyChange("frameput", null, frame);        
        return lib;
    }
    
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        String helpdir = "file://localhost/ka/help"; // for help system
        
        try { m_current_editor.looseFocus();} catch (Exception ex) {}
        
        if (cmd.equals("close")) {
            close();
        } else if (cmd.equals("upload")) {
            // Upload the frame
            try {
                uploadFrame(m_frame);  
            } catch (Exception ex) {
                ErrorMessage.message(this, ErrorMessage.EM_UPLOAD_ERROR);
                MainFrame.println("KnowledgeFrameBrowser[uploading]:" + ex);
                close();
            }
        } else if (cmd.equals("closeandinsert")) {
            // Upload the frame and also call back targeted browser
            // of course this should be done using events ... will
            // do it right in my copious spare time
            try {
                GEKOClientI lib;
                Vector key_note_pairs; // Sigh -- just want a reload api
                KeyNotePair knp; 
                
                lib = uploadFrame(m_frame);

                // Now have to find the frame in the archive and get it back down
                if (null != m_target_browser) {
                    key_note_pairs = lib.get_key_notes(m_frame.group_name());
                    for (int i = 0; i < key_note_pairs.size(); ++i) {
                        if ((knp = (KeyNotePair)key_note_pairs.elementAt(i)).summary().equals(m_frame.summary())) {
                               m_target_browser.updateTarget(     
                                    lib.get_frame(m_frame.group_name(), knp.get_key()), 
                                    m_target_object);                               
                               close();
                        }
                    }                    
                    close();  // To avoid problems
                }
            } catch (Exception ex) {
                ErrorMessage.message(this, ErrorMessage.EM_UPLOAD_ERROR);
                MainFrame.println("KnowledgeFrameBrowser[uploading]:" + ex);
                close();
            }
            
        } else if (cmd.equals("save")) {
            save();
        } else if (cmd.equals("saveas")) {
            saveas();
        } else if (cmd.equals("newelement")) {
            insertSelectedElement();
        } else if (cmd.equals("archivedelement")) {
            insertArchivedElement();
        } else if (cmd.equals("deleteelement")) {
            deleteSelectedElement();
        } else if (cmd.equals("editelement")) {
            editSelectedElement();
        } else if (cmd.equals("procedurehelp")) {
            new Help(this, helpdir + "/kfbrowsehelp.html");
        } else if (cmd.equals("slothelp")) {
            try {
                GekkoTreeNode gkn = ((GekkoTreeNode) getBrowsedTreeNode().getUserObject());
                String slotname = gkn.toString();
                Object obj;
                // Get _PARENT_ of selected object
                TreePath path = m_tree.getSelectionPath();
                if (null == path ) {
                    ErrorMessage.message(this, ErrorMessage.EM_SLOT_SELECTION_ERROR, null);                    
                    return;
                }
                obj = m_tfm.getPathedObject(path.getParentPath());                
                /* For slot info the url is:
                *      schema_<group_name_of_parent>.html#slot_name
                */
                String helpfile;
                if (obj instanceof KnowledgeFrame) {
                    KnowledgeFrame kf = (KnowledgeFrame) obj;
                    helpfile = helpdir + "/schema_";
                    helpfile = helpfile + kf.group_name().replace(' ', '_') + ".html";
                    helpfile = helpfile +  "#" + slotname.replace(' ', '_');
                    new Help(this, helpfile);
                } else if (obj instanceof KnowledgeList) {
                    helpfile = helpdir + "/schema_";
                    helpfile = helpfile + gkn.getTreeNodeSchema().get("schema").replace(' ', '_') + ".html";
                    new Help(this, helpfile);
                } else {
                    MainFrame.println("Help not supported for this guy yet:" + obj.getClass() + " ::: " + gkn.getTreeNodeSchema().get("schema"));
                }
            } catch (Exception ex) {
                ErrorMessage.message(this, ErrorMessage.EM_SLOT_SELECTION_ERROR, null);
            }

        }
    }
}
