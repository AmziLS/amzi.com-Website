// PSERule.java

package amzi.ka.db;

import amzi.frames.*;
import amzi.kb.*;

import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

public class PSERule
{
   String name = null;
   PSETest model_system = null;
   PSETest controlled_variables = null;
   PSETest conditions = null;
   PSEAction action;
   PSEVariable dependent_variable;

   public PSERule(String n)
   {
      name = n;
   }

   public PSERule()
   {
      name = null;
   }

   public Rule makeRule()
   {
      Rule r = new Rule(name);
      if (conditions != null)
         r.set_conditions(conditions.makeTest());
      r.set_action(action.makeAction());
      r.set_dependent_variable(dependent_variable.makeVariableKey());
      if (model_system != null)
         r.add_precondition(model_system.makeTest());
      if (controlled_variables != null)
         r.add_precondition(controlled_variables.makeTest());
      return r;
   }

   public void set_conditions(PSETest t) { conditions = t; }
   public void set_action(PSEAction a) { action = a; }
   public void set_dependent_variable(PSEVariable v) { dependent_variable = v; }
   public void set_model_system(PSETest t) { model_system = t; }
   public void set_controlled_variables(PSETest t) { controlled_variables = t; }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();

      sb.append("rule " + name + ":");

      if (conditions != null)
         sb.append("IF " + conditions.toString());
      else
         sb.append("IF true");

      sb.append("THEN " + action.toString());

      return sb.toString();
   }

   public void print(PrintStream o)
   {
      o.println("RULE " + name);

      if (conditions != null)
      {
         o.println("IF");
         conditions.print(o);
      }
      else
      {
         o.println("IF true");
      }

      o.println("THEN");
      action.print(o);
   }
}