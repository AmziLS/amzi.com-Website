package amzi.ka.gg;

import java.awt.*;
import javax.swing.*;
import amzi.ka.*;
import amzi.ka.gg.editors.*;
import amzi.frames.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;

/**
* For now queries are typed in as unvalidated simple text. 
* Maybe get fancier later. 
*/

public class QBEEditor extends TextLineEditor {
}

