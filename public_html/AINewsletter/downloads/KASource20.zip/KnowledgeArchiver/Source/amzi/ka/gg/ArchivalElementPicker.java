package amzi.ka.gg;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Enumeration;
import java.beans.*;

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;

public class ArchivalElementPicker implements PropertyChangeListener {
    private Vector m_query_results;
    private BrowserContainer m_container;
    private GEKOClientI m_lib = null;
    
    public ArchivalElementPicker(GEKOClientI lib, BrowserContainer bc) {
        m_lib = lib;
        m_container = bc;
    }
    
    /** 
    * Offer a pick list dialog of all entries in given group
    * and either return the GroupsEditor with picked/queried frame 
    * or null if cancelled out. This is modal.
    */
    public GroupsEditor pickArchivalElement(JComponent parent, String group, String title, String msg) {
        return pickArchivalElement(parent, group, title, msg, true, null);
    }
                        
    public GroupsEditor pickArchivalElement(JComponent parent, String group, String title, 
                    String msg, boolean enablequery, Vector pop) {
        Object val;      
        GroupsEditor ge;        
        Cursor old_curse = parent.getCursor();  
        parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));           

        try {
            JPanel panel = new JPanel(new BorderLayout());
            ge = new GroupsEditor( m_lib, m_container);
            ge.setGroup(group);
            if (null == pop)
                ge.populate();
            else
                ge.populate(pop);
            JScrollPane p = new JScrollPane(ge.getWidget());
            p.setPreferredSize(new Dimension(120, 100));
            panel.add(p);

            
            GGDialog option = new GGDialog(enablequery ? GGDialog.OK_CANCEL_QUERY_DIALOG : GGDialog.OK_CANCEL_DIALOG, 
                                  "Archived Frame Selection: " + group, 
                                  enablequery ? "Select archived frame or create a query" : "Select archived frame", 
                                          p, ge.getWidget());
            /* If a query then we have to do some hoop dancing
            */
            if (option.getValue().equals("Query")) {
                QBEBrowser b = new QBEBrowser(m_lib, m_container, group, true);
                b.getPropertyChangeSupport().addPropertyChangeListener(this);               
                option = new GGDialog(GGDialog.OK_CANCEL_DIALOG,
                                      "Archived Frame Query: " + group,
                                      "Create and submit a query to the archive",
                                      b.getMainPanel(), null);

                if (! option.getValue().equals("Cancel")) {
                    b.doQuery();// Yuk - we handle this all on our current thread
                    if (null != m_query_results) {// .. so by here the result is set
                        ge = pickArchivalElement(parent, group, title, msg, false, m_query_results);
                        m_query_results = null;
                    }                    
                }              
            } else if (option.getValue().equals("Cancel"))
                ge = null;
        } catch (Exception e) {
            MainFrame.println("ArchivalElementPicker:pickArchivalElement(): " + e);
            ge = null;
        }
        parent.setCursor(old_curse);
        return ge;
    }
    
    public void propertyChange(PropertyChangeEvent evt) {
        String propname = evt.getPropertyName();
        
        if (propname.equals("queryresults")) {
            // A query was performed or the query was abandoned
            if (null != evt.getNewValue()) {
                m_query_results = ((QueryResults) evt.getNewValue()).getResults();
            } else
                m_query_results = null;           
        }                
    }    
}

// .. sigh .. non-modal dialog box with clickable list of
// results from query
