package amzi.ka.gg;

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;
import java.util.Hashtable;
import java.util.Vector;
import java.io.*;

/** Permits the getting of schema information either from the archive or
* local from a file -- masks the source
*/
public class SchemaSource {
    private File m_schema_file;
    private GEKOClientI m_lib;
    private Hashtable m_cache;
    
    public SchemaSource(File file) {
        m_schema_file = file;
        m_lib = null;
        init_file();
    }
    
    public SchemaSource(GEKOClientI lib) {
        m_lib = lib;
        m_schema_file = null;
        init_lib();
    }
    
    /**
    * Initialize from local file
    */
    private void init_file() {
        m_cache = new Hashtable();
    }
    
    /**
    * Initialize from archive
    */
    private void init_lib() {
        m_cache = new Hashtable();
        
    }

    /** Get the schema from the source given its name. Also provides
    * caching to keep costs down
    */
    public KnowledgeFrame getSchema(String name) {
        KnowledgeFrame kf;
        
        kf = (KnowledgeFrame) m_cache.get(name);
        if (null != kf)
            return kf;
        if (null == m_lib) {
            // Get it from file -- which is already in cache
            // so if we got here we have an error --
            return null;  // Can't find it
        } else {
            QueryFrame qf;
            Vector key_note_pairs;
            KeyNotePair kn;            
            
            qf = new QueryFrame("schema");
            qf.set("group", new QueryOp(QueryOp.EQUALS, name));
            try {
                key_note_pairs = m_lib.query(qf);
                if (key_note_pairs.size() != 1)
                    MainFrame.println("Schema:getSource() - key_note_pairs.size() != 1");    
                kn = (KeyNotePair)key_note_pairs.firstElement();
                kf = m_lib.get_frame("schema", kn.get_key());           
                m_cache.put(name, kf);
                return kf;
            } catch (Exception e) {
                MainFrame.println("SchemaSource:getSchema(): " + e);
                return null;
            }
        }
    }
   
    /** 
    * Find frame in group with a named slot containing the given value 
    */
   public KnowledgeFrame simpleQuery(String group, String slot_name, String value)
         throws FrameException
   {
        if (null != m_lib) {
            // Create a new query frame for the group.
            QueryFrame qf = new QueryFrame(group);

            // Set a query slot pattern match for the simple equals case.
            qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

            // The query returns a vector of key_note_pairs that
            // satisfy the query.  We'll just take the first one
            // or return null.
            Vector answers = m_lib.query(qf);
            if (answers.isEmpty())
                return null;
      
            // Retrieve the desired frame.
            String key = ((KeyNotePair)answers.firstElement()).get_key();
            return m_lib.get_frame(group, key);
        } else {
            return null;
        }
   }
    
}