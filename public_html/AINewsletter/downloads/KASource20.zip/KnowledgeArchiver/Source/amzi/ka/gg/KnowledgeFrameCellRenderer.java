package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import amzi.frames.*;

/**
*  A minor overide to the default renderer to handle verified/no verified
* which we simply indicate by rendering the icon in red (for now)
*/
public class KnowledgeFrameCellRenderer extends DefaultTreeCellRenderer {
    /** I'd love to be able to just overide paint() but the #&%$Q thing
    * uses some private variables (which should and will be protected. Haha!)
    * so I have to copy over the renderer code and the two private vars here
    */
    // These two ivars will be made protected later.
    /** True if has focus. */
    private boolean hasFocus;
    /** True if draws focus border around icon as well. */
    private boolean drawsFocusBorderAroundIcon;
    
    private KnowledgeFrameBrowser m_browser;
    
    private boolean m_verifying;
    
    private Color m_oldbgc;
    
    public KnowledgeFrameCellRenderer(KnowledgeFrameBrowser browser) {
        m_browser = browser;
        m_oldbgc = getBackgroundNonSelectionColor();
    }
    
    /** Am I currently verifying ??*/
    public void setVerifying(boolean val) {
        m_verifying = val;        
    }
    
    /**
      * Configures the renderer based on the passed in components.
      * The value is set from messaging value with toString().
      * The foreground color is set based on the selection and the icon
      * is set based on on leaf and expanded.
      */
    public Component getTreeCellRendererComponent(JTree tree, Object value,
						  boolean sel,
						  boolean expanded,
						  boolean leaf, int row,
						  boolean hasFocus) 
    {

	/*    String  stringValue = tree.convertValueToText(value, sel,
					  expanded, leaf, row, hasFocus);
    */
        GekkoTreeNode gkn = null;
        Object obj;
        TreeFrameMapper tfm;
        String decoration = "";
        Graphics g;
        
        tfm = m_browser.getTreeFrameMapper();
        gkn = (GekkoTreeNode)((DefaultMutableTreeNode) value).getUserObject();
            
        obj = tfm.getMappedObject(gkn);
        
        if (obj instanceof KnowledgeSlot) try {
            decoration = " -- " + ((KnowledgeSlot) obj).summary();
        } catch (Exception e) {
        }
        else if (obj instanceof KnowledgeFrame) try {
            decoration = " -- " + ((KnowledgeFrame) obj).summary();
        } catch (Exception e2) {
        } 
        else if (obj instanceof KnowledgeList) {
        }        
        else if (null != obj)
            decoration = " -- " + obj.toString();
        decoration = gkn.toString() + decoration;
        /** The following is the best I can do to get rid of the
        * apparent inability to dynamically resize a label with any
        * degree of reliability (the dreaded ".." problem)
        */
        g = getGraphics();
        if (null != g && getPreferredSize().width < 400) {
            setPreferredSize(new Dimension(400, getPreferredSize().height));
            invalidate();
        }
        setText(decoration);
        
	    this.hasFocus = hasFocus;

	    if(sel) {
	        setForeground(getTextSelectionColor());
	    }
    	else
	        setForeground(getTextNonSelectionColor());
    
        // If I am not verifiedthen flag me ... red if I am not acknowledge and ornage
        // if I am not verified but aknowledged
        setBackgroundNonSelectionColor(m_oldbgc);
        if (m_verifying) {
            if ( ! gkn.isVerified()) {
                if (! gkn.isAcknowledged())
                    setBackgroundNonSelectionColor(Color.red);
                else
                    setBackgroundNonSelectionColor(Color.orange);
            } else {
                if (sel)
                    setBackground(getBackgroundSelectionColor());
                else
                    setBackground(getBackgroundNonSelectionColor());                
            }
        } else {            
            if (sel)
                setBackground(getBackgroundSelectionColor());
            else
                setBackground(getBackgroundNonSelectionColor());
        }
                           
    	if (leaf) {
	        setIcon(getLeafIcon());
    	} else if (expanded) {
	        setIcon(getOpenIcon());
    	} else {
	        setIcon(getClosedIcon());
    	}
	    
	    selected = sel;

    	return this;
    }
}