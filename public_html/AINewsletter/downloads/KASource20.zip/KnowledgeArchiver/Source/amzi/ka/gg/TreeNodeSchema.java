package amzi.ka.gg;

import amzi.frames.*;

public class TreeNodeSchema {
   
    protected int m_type;
    protected KnowledgeFrame m_schema;
    protected String m_schema_name;
    
    public TreeNodeSchema(KnowledgeFrame schema, String schema_name) {
        m_schema = schema;
        m_schema_name = schema_name;
    }
    
    public String get(String name) {
        try {
            if (m_schema.slot_exists(name))
                return m_schema.get(name).toString();
        } catch (Exception e) {
        }
        return null;
    }
    
    public String getSchemaName() {
        return m_schema_name;
    }    
}