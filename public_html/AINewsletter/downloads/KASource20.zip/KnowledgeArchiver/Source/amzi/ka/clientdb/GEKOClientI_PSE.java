// GEKOClientI_PSE.java

package amzi.ka.clientdb;

import amzi.ka.net.*;
import amzi.ka.*;
import amzi.ka.db.*;
import amzi.frames.*;
import amzi.kb.*;

import java.util.*;
import java.io.*;

/**
* An implementation of the client's interface to KA that
* is designed to run stand-alone on the client, without
* connecting to the server.
*/
public class GEKOClientI_PSE implements GEKOClientI
{
   static File archive_path = new File("/KArchives");

   GEKOLibraryI gekos = null;

   /**
   * Static function used to find the available GEKO knowledge
   * archives.
   */
   public static Vector libraries()
   {
      String[] files = archive_path.list(new ODBFilter());
      Vector v = new Vector();
      for (int i=0; i<files.length; i++)
         v.addElement( files[i].substring(0, files[i].indexOf(".odb")) );
      return v;
   }

   public GEKOClientI_PSE()
   {
      gekos = null;
   }

   /**
   * Connect to a library server.
   */
   public void connect(String host) throws FrameException
   {
      report("connect");
      return;
   }

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port) throws FrameException
   {
      report("connect");
      return;
   }

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port, String proxy_host, String proxy_port) throws FrameException
   {
      report("connect");
      return;
   }

   /**
   * Allow a user to log onto the server.
   */
   public boolean logon(String user_id, String password) throws FrameException
   {
      report("logon");
      return true;
   }

   /**
   * Allow a user to log into the library.
   */
   public void logoff() throws FrameException
   {
      report("logoff");
      return;
   }

   /**
   * Initialize a library server.
   */
   public void initialize() throws FrameException
   {
      report("initialize");
      ensure_library();
      gekos.initialize();
   }

   /**
   * Initialize a library server.
   */
   public void initialize(Thread th) throws FrameException
   {
      report("initialize");
      ensure_library();
      gekos.initialize(th);
   }

   /**
   * Creates a new open Knowledge Library.
   */
   public void create(String db_name) throws FrameException
   {
      report("create");
      ensure_library();
      gekos.create(db_name, null, null);
   }

   /**
   * Create a new Knowledge Library from the named schema.
   */
   public void create(String db_name, String schema_file_name) throws FrameException
   {
      report("create");
      ensure_library();
      gekos.create(db_name, schema_file_name, null);
   }

   /**
   * Create a new closed Knowledge Library starting with the
   * person frame for the archivist.
   */
   public void create(String db_name, String schema_file_name, KnowledgeFrame archivist) throws FrameException
   {
      report("create");
      ensure_library();
      gekos.create(db_name, schema_file_name, archivist);
   }

   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException
   {
      report("opening: " + db_name);
      ensure_library();
      gekos.open(db_name);
   }

   /**
   * Close an open Knowledge Library.
   */
   public void close(String archive) throws FrameException
   {
      report("close");
      gekos.close();
      gekos = null;
   }

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException
   {
      report("add_group");
      check_library();
      gekos.add_group(group);
   }

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException
   {
      report("get_groups");
      check_library();
      return gekos.get_groups();
   }

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException
   {
      report("put_frame");
      check_library();
      return gekos.put_frame(f);
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException
   {
      report("remove_frame");
      check_library();
      gekos.remove_frame(f);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key and version.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @param version The version number
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key, int version) throws FrameException
   {
      report("get_frame " + key);
      check_library();
      return gekos.get_frame(group, key, version);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException
   {
      report("get_frame " + key);
      check_library();
      return gekos.get_frame(group, key);
   }

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException
   {
      report("get_key_notes");
      check_library();
      return gekos.get_key_notes(group);
   }

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException
   {
      report("query");
      check_library();
      return gekos.query(qf);
   }

   //----------------------------
   // KA-specific functions
   //

   /**
   * Get an array of available archive names.
   */
   public Vector get_archives() throws FrameException
   {
      report("get_archives");
      return GEKOClientI_PSE.libraries();
   }

   /**
   * Check to see if a geko exists for the given title.
   * @param title The title string.
   * @param geko The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_geko(String title, KnowledgeFrame geko) throws FrameException
   {
      report("check_geko");
      check_library();
      return gekos.check_geko(title, geko);
   }

   /**
   * Check to see if an author exists with the given name.
   * @param name The name string.
   * @param author The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_author(String name, KnowledgeFrame author) throws FrameException
   {
      report("check_author");
      check_library();
      return gekos.check_author(name, author);
   }

   /**
   * Check to see if a variable exists with the given name.
   * @param name The name string.
   * @param variable The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_variable(String name, KnowledgeFrame variable) throws FrameException
   {
      report("check_variable");
      check_library();
      return gekos.check_variable(name, variable);
   }

   /**
   * Check to see if a citation exists with the given body.
   * @param body The body string.
   * @param citation The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_citation(String body, KnowledgeFrame citation) throws FrameException
   {
      report("check_citation");
      check_library();
      return gekos.check_citation(body, citation);
   }

   /**
   * Check to see if a keyword exists with the given body.
   * @param item The keyword string.
   * @param keyword The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_keyword(String item, KnowledgeFrame keyword) throws FrameException
   {
      report("check_keyword");
      check_library();
      return gekos.check_keyword(item, keyword);
   }

   /**
   * Get all the variables from the archive formatted
   * for inferencing.
   */
   public Variable[] get_variables() throws FrameException
   {
      report("get_variables");
      check_library();
      return gekos.get_variables();
   }

   /**
   * Get all the links from the archive formatted
   * for inferencing.
   */
   public Link[] get_links() throws FrameException
   {
      report("get_links");
      check_library();
      return gekos.get_links();
   }

   /**
   * Get all the rules from the gekos in the archive
   * formatted for inferencing.
   */
   public Rule[] get_rules() throws FrameException
   {
      report("get_rules");
      check_library();
      return gekos.get_rules();
   }

   private void report(String s)
   {
      //System.out.println(s);
   }

   private void ensure_library() throws FrameException
   {
      if (gekos == null)
      {
         // Open a new library, starting a new OS session with
         // this thread.  Real users will join this thread.
         gekos = (GEKOLibraryI)new GEKOLibraryI_PSE();
         gekos.initial_thread();
      }
   }

   private void check_library() throws FrameException
   {
      if (gekos == null)
      {
         throw new KAFrameException(KAFrameException.NO_OPEN_ARCHIVE);
      }
   }
}

/**
* Filter class used to find archive file names.
*/
class ODBFilter implements FilenameFilter
{
   public boolean accept(File f, String n)
   {
      return n.endsWith(".odb");
   }
}
