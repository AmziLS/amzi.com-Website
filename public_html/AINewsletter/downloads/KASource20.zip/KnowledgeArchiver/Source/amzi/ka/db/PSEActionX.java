// PSEAction.java

package amzi.ka.db;

import amzi.frames.*;
import amzi.kb.*;

import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

public class PSEAction
{
   PSEVariable var;
   Object value;

   public PSEAction(PSEVariable var, Object val)
   {
      this.var = var;
      value = val;
   }

   public Action makeAction()
   {
      Action a = new Action(var.makeVariableKey());
      if (value.getClass() == PSEClasses.cPSEVariable)
      {
         a.set_value( ((PSEVariable)value).makeVariableKey() );
      }
      else if (value.getClass() == PSEClasses.cPSEExpression)
         a.set_value( ((PSEExpression)value).makeExpression() );
      else
         a.set_value(value);

      return a;
   }

   public String toString()
   {
      return var.toString() + " = " + value.toString();
   }

   public void print(PrintStream o)
   {
      o.println(this.toString());
   }

}