package amzi.ka.gg;


import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;


import amzi.ka.*;
import amzi.frames.*;


/** Redefine isLeaf to work from the frame content. This avoids
* this cosmetic problem of lists becoming leaves if you delete
* all their elements (which looks very confusing)
*/
public class GGTreeModel extends DefaultTreeModel {
    private TreeFrameMapper m_tfm;
    
    public GGTreeModel(TreeNode root, TreeFrameMapper tfm) {
        super(root);
        m_tfm = tfm;        
    }
    
    public boolean isLeaf(Object node) {
        GekkoTreeNode gtn;
        DefaultMutableTreeNode dtn;
        
        try {
            dtn = (DefaultMutableTreeNode) node;
            gtn = (GekkoTreeNode) (dtn.getUserObject());
            node = m_tfm.getMappedObject(gtn);
            if (gtn.toString().equals("root")) // !!
                return false;
            if (node instanceof KnowledgeFrame)
                return false;
            else if (node instanceof KnowledgeList)
                return false;
            else if (dtn.getChildCount() > 0)
                return false;        
            else 
                return true;
        } catch (Exception e) {
            MainFrame.println("GGTreeModel:isLeaf(): " + e);
        }
        return false;
    }
}
