package amzi.ka.gg;

import javax.swing.*;

/** Submenu is list of groups .. */
public class GNewObjectMenuItem extends GMenuItem {
    private BrowserContainer m_bc;
    
    public GNewObjectMenuItem(BrowserContainer bc) {
        super("NewObject", "newobject", "Create a new object browser");
        m_bc = bc;            
    }
    
    public MenuElement[] getSubElements() { 
        JMenuItem me[] = new JMenuItem[1];
        
        me[0] = new GMenuItem("subStr", "substr", "hahahahah");
        return me;
    }   
}
