// KAClasses.java

package amzi.ka;

public class KAClasses
{
   public static Class cString;
   public static Class cVector;

   static
   {
      try
      {
         cString = Class.forName("java.lang.String");
         cVector = Class.forName("java.util.Vector");
      }
      catch (Exception ex)
      {
         System.out.println("*** Problem initializing classes ***");
      }
   }
}