package amzi.ka;

import java.io.*;

/**
 * KAMessage
 * This class is used as a general purpose communicator object
 * for the sockets interface.
 *
 * @author  Amzi! inc.
 */
public class KAMessage implements Serializable
{
   // KnowledgeLibrary messages

   public final static int INITIALIZE = 100;
   public final static int CONNECT = 101;
   public final static int CREATE = 102;
   public final static int OPEN = 103;
   public final static int CLOSE = 104;

   public final static int ADD_GROUP = 201;
   public final static int GET_GROUPS = 202;
   public final static int PUT_FRAME = 203;
   public final static int GET_FRAME = 204;
   public final static int GET_KEY_NOTES = 205;
   public final static int QUERY = 206;

   // GEKOLibrary extension messages

   public final static int LOGON = 701;
   public final static int CHECK_GEKO = 702;
   public final static int CHECK_AUTHOR = 703;
   public final static int CHECK_VARIABLE = 704;
   public final static int CHECK_CITATION = 705;
   public final static int CHECK_KEYWORD = 706;

   // Response messages

   public final static int ERROR = 2001;
   public final static int OK = 2002;

   public int message_id;
   public Object argument;

   /**
    * Construct a message of type m with an argument.
    *
    * @param  m  the type of message
    * @param  a  the argument of the message
    */
   public KAMessage(int m, Object a)
   {
      message_id = m;
      argument = a;
   }

   /**
    * Construct a message of type m with no argument.
    *
    * @param  m  the type of message
    */
   public KAMessage(int m)
   {
      message_id = m;
      argument = null;
   }

   public int get_message_id() { return message_id; }
   public Object get_argument() { return argument; }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}