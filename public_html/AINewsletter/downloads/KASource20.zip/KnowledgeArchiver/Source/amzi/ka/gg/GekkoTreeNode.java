package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import amzi.frames.*;

/** Our tree node -- supports state for "in-tree" verification. Imp note --
* this is all wrong - I should be using events to trigger stuff. Ah well, I'll
* fix it RSN.
*/
public class GekkoTreeNode {
    private String m_text;
    // Was I succesfully verified 
    private boolean m_verified;
    // If not then why not
    private int m_last_error;
    // My last warning was acknowledged
    private boolean m_acknowledged;
    // And the error that was acknowledged
    private int m_acknowledged_error;
    // The TreeNode that owns you
    private TreeNode m_parent;
    // The attach point and the subtree to be attached in the case that
    // the gekko is modified by downloading a subtree from the archive
    private KnowledgeSlot m_graft_point;
    // Schema info for the object this frame represents
    private TreeNodeSchema m_tree_node_schema;
    
    private Object m_graft;
    
    public GekkoBrowser m_gekko_browser;
    
    public GekkoTreeNode(String text) {
        m_text = text;
        m_verified = true; // OK till proven otherwise
        m_acknowledged = false;  
        m_acknowledged_error = m_last_error = -1;
        m_tree_node_schema = null;
    }

    public void setLabel(String label) {
        m_text = label;
    }
        
    public String toString() {
        return m_text;
    }
    
    public void setTreeNodeSchema(TreeNodeSchema scheme) {
        m_tree_node_schema = scheme;
    }
    
    public TreeNodeSchema getTreeNodeSchema() {
        return m_tree_node_schema;
    }
    
    /**
    * Prepare for grafting so we can graft at a future time
    * (i.e. when th euser presses the download button)
    */
    public void setGraft(KnowledgeSlot graft_point, Object graft) {
        m_graft_point = graft_point;
        m_graft = graft;
    }

    /** 
    * Set the graft into place -- notice this just fixes up the
    * knowledge frame so we invoke the resynch on browser
    */
    public void graft(GekkoBrowser browser) {
        Object old_value;
        old_value = m_graft_point.value();
        m_graft_point.set_value(m_graft);
        browser.resynch(old_value, m_graft);
        MainFrame.println("Graft: " + m_graft_point + ":" + m_graft);
    }
    
    /** 
    * The GekkoTreeNode is actually the user object of 
    * @param node
    */
    public void setParent(TreeNode node) {
        m_parent = node;
    }
    
    public TreeNode getParent() {
        return m_parent;
    }
    
    public void setVerified(boolean val) {
        m_verified = val;
    }
    
    public boolean isVerified() {
        return m_verified;
    }
    
    public boolean getAcknowledged() {
        return m_acknowledged;
    }
    
    public void setAcknowledged(boolean ack) {
        m_acknowledged = ack;
        if (ack)
            m_acknowledged_error = m_last_error;
    }
    
    /** Called if I don't verify -- was the error causing
    * my invalid state the same as the last (acknowledged)
    * error -- if so then I am ok, otherwise this is a new error
    */
    public boolean isAcknowledged() {
        if ((! m_verified) && m_acknowledged && 
            (m_last_error == m_acknowledged_error)) {
                return true;
            }
        // New error
        m_acknowledged = false;
        m_acknowledged_error = -1;
        return false;            
    }
    
    /**
    * Either I'm verified or I'm not because of a current
    * error which happens to be the same as my last error,
    * which was acknowledged
    */
    public boolean isAcknowledgedOrVerified() {
        return (isVerified() || isAcknowledged());
    }
     
    public void setLastError(int val) {
        m_last_error = val;
    }
    
    public int getLastError() {
        return m_last_error;
    }
}

