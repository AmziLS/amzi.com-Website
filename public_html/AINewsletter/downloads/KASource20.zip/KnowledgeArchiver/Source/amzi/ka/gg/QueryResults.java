package amzi.ka.gg;

import java.util.Vector;

public class QueryResults {
    
    private Vector m_results;
    private String m_group;
    
    public QueryResults(Vector r, String g) {
        m_results = r;
        m_group = g;
    }
    
    public Vector getResults() {
        return m_results;
    }
    
    public String getGroup() {
        return m_group;
    }
}