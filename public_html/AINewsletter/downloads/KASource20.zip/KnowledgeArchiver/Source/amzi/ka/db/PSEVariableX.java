// PSEVariable.java

package amzi.ka.db;

import amzi.kb.*;
import amzi.frames.*;

import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

/**
* A simple class to store a DB key in, which
* is just a string, but we can tell the difference
* this way.
*/
public class PSEVariable
{
   String key;

   public PSEVariable(String k)
   {
      key = k;
   }

   public VariableKey makeVariableKey()
   {
      return new VariableKey(key);
   }

   public String get_key() { return key; }

   public String toString()
   {
      return key;
   }
}