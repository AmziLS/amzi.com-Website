package amzi.ka.gg;

import javax.swing.*;
import amzi.ka.*;
import amzi.frames.*;
import java.beans.*;
import java.awt.event.*;

/** The basic browser editor. Note that it up to each subclass to
* enforce synchronization between editor contents and the tree
* Also it is up to the editor to maintain the clean/dirty state
* of the browser by using m_browser.setClean(), m_browser.setDirty()
* and m_browser.isDirty()
*/
public class BrowserEditor extends JPanel {
    protected Object m_val;
    protected PropertyChangeSupport m_property_change;   
    protected Browser m_browser = null;
    
    public void setBrowser(Browser b) {
        m_browser = b;
    }
    
    /** Event notification mechanism
    */
    public PropertyChangeSupport getPropertyChange() {
        return m_property_change;
    }

    /** A GekkoLeafEditor wraps a component --
    */    
    public JComponent getWidget() {
        return (JComponent) this;
    }
    /** Set the contents of the editor widget to the value of the
    * leaf slot (text for now). It's up to the widget to do what it wants to with this
    */
    public void setValue(Object value) throws Exception {
        m_val = value;    
    }
    
    /** Grant or veto the right to loose focus. This means basically do a check
    * on the validity of the data and update the "value" object.
    * If looseFocus is declined then the data has
    to be corrected before you can continue
    */
    public boolean looseFocus() throws Exception {
        return true;
    }
    
    /** Make sure node and editing panel contain same data */
    public void synchValue() {};
    
    /** En/Dis able editing in editor window */
    public void setEnabled(boolean flag) {};
    
    /** Sets the editor to a certain color */
    public void setColor(java.awt.Color color) {
        setBackground(color);
    }
}