// GEKOTokenizer

package amzi.ka;

import java.io.*;
import java.util.*;

/**
 * Splits up a GEKO text file into tokens peculiar
 * to that format.  The tokens are frame names, slot names and
 * slot values.  Slot values are just long strings.
 *
 * @author  Amzi! inc.
 */
public class GEKOTokenizer
{
   /**
   * A slot definition that maps the text string
   * name of a slot with its integer ID number, and
   * type (frame or slot).
   */
   public static class Slot
   {
      public String name;
      public int type;
      public int id;

      public Slot(String n, int t, int i)
      {
         name = n;
         type = t;
         id = i;
      }
   }

   // token types
   public static final int SLOT   = 0;
   public static final int FRAME  = 1;
   public static final int VECTOR = 2;
   public static final int VALUE  = 3;
   public static final int EOF    = 4;

   // For ease of parsing, each slot and frame
   // type has an associated integer which is returned
   // when a token is found.  The integer can be used
   // in a switch statement.

   // Slot IDs
   public static final int TITLE = 100;
   public static final int NAME = 101;
   public static final int INSTITUTION = 102;
   public static final int EMAIL = 103;
   public static final int BIOGRAPHY = 104;
   public static final int KNOWLEDGE_NARRATIVE = 106;
   public static final int KEYWORD = 107;
   public static final int SOURCE_FRAME_COMMENTS = 108;
   public static final int FILE_NAME = 109;
   public static final int SUBCLASS = 110;
   public static final int STATUS = 111;
   public static final int VERSION_NUMBER = 112;
   public static final int VERSION_DATE = 113;
   public static final int REVISION_DATE = 114;
   public static final int COMMENTS = 115;
   public static final int TYPE = 116;
   public static final int DESCRIPTION = 117;
   public static final int RULE = 119;
   public static final int FORMULA = 120;
   public static final int USE = 121;
   public static final int KNOWLEDGE_FRAME_COMMENTS = 122;

   public static final int BODY = 123;
   public static final int PEER_REVIEWED = 124;
   public static final int CITATION_CODE = 125;
   public static final int TECHNICAL_FRAME_COMMENTS = 126;
   public static final int END = 127;

   public static final int LIMITS = 128;
   public static final int SHAPE = 129;
   public static final int FUZZY_RULE = 130;
   public static final int DEFINITION = 131;
   public static final int DATA = 132;
   public static final int INTERPOLATE = 133;

   public static final int NAME_OF_APPLICATION = 134;
   public static final int DEVELOPER_NAME = 135;
   public static final int DEVELOPER_EMAIL = 136;

   public static final int EXPIRATION_DATE = 137;
   public static final int CONTRACT_ID_NUMBER = 138;
   public static final int RESTRICTION = 139;

   public static final int FRAMEID = 140;
   public static final int TIMESTAMP = 141;
   public static final int MODEL_SYSTEM = 142;
   public static final int DECLARATIVE_STATEMENTS = 143;

   // Frame IDs
   public static final int AUTHOR = 201;
   public static final int SOURCE_CITATIONS = 202;
   public static final int SUPPORT_CITATIONS = 203;
   public static final int KEYWORDS = 204;
   public static final int PEER_REVIEWS = 205;
   public static final int REVIEW = 206;
   public static final int USAGE_LOG = 207;
   public static final int SESSION = 208;
   public static final int INDEPENDENT_VARIABLES = 209;
   public static final int VARIABLE = 210;
   public static final int DEPENDENT_VARIABLES = 211;
   public static final int MAJOR_CONTROLLED_VARIABLES = 212;
   public static final int CITATION = 213;

   public static final int FUZZY_SETS = 214;
   public static final int FUZZY_SET = 215;
   public static final int HEDGES = 216;
   public static final int HEDGE = 217;
   public static final int TABLE = 218;


   public static final int SOURCE_FRAME = 301;
   public static final int TECHNICAL_FRAME = 302;
   public static final int KNOWLEDGE_FRAME = 303;


   // These are the public variables the user
   // will pick up directly.
   public int token_type;
   public Slot slot;   // some slots are frames
   public String value;  // value of a slot
   public int line_number;  // current line number in file

   /**
   * An array of slots that can be searched to find the ID
   * and type associated with a given input string token.
   */
   private static Slot[] slots =
   {
      new Slot("Title", SLOT, TITLE),
      new Slot("Name", SLOT, NAME),
      new Slot("Institution", SLOT, INSTITUTION),
      new Slot("Email", SLOT, EMAIL),
      new Slot("Biography", SLOT, BIOGRAPHY),
      new Slot("Knowledge Narrative", SLOT, KNOWLEDGE_NARRATIVE),
      new Slot("Keyword", SLOT, KEYWORD),
      new Slot("Source Frame Comments", SLOT, SOURCE_FRAME_COMMENTS),
      new Slot("Filename", SLOT, FILE_NAME),
      new Slot("Subclass", SLOT, SUBCLASS),
      new Slot("Status", SLOT, STATUS),
      new Slot("Version Number", SLOT, VERSION_NUMBER),
      new Slot("Version Date", SLOT, VERSION_DATE),
      new Slot("Revision Date", SLOT, REVISION_DATE),
      new Slot("Comments", SLOT, COMMENTS),
      new Slot("Type", SLOT, TYPE),
      new Slot("Description", SLOT, DESCRIPTION),
      new Slot("Table", SLOT, TABLE),
      new Slot("Rule", SLOT, RULE),
      new Slot("Formula", SLOT, FORMULA),
      new Slot("Use", SLOT, USE),
      new Slot("Knowledge Frame Comments", SLOT, KNOWLEDGE_FRAME_COMMENTS),

      new Slot("Body", SLOT, BODY),
      new Slot("Peer Reviewed", SLOT, PEER_REVIEWED),
      new Slot("Citation Code", SLOT, CITATION_CODE),
      new Slot("Technical Frame Comments", SLOT, TECHNICAL_FRAME_COMMENTS),
      new Slot("End", SLOT, END),

      new Slot("Limits", SLOT, LIMITS),
      new Slot("Shape", SLOT, SHAPE),
      new Slot("Fuzzy Rule", SLOT, FUZZY_RULE),
      new Slot("Definition", SLOT, DEFINITION),
      new Slot("Data", SLOT, DATA),
      new Slot("Interpolate", SLOT, INTERPOLATE),

      new Slot("Name of Application", SLOT, NAME_OF_APPLICATION),
      new Slot("Developer Name", SLOT, DEVELOPER_NAME),
      new Slot("Developer Email", SLOT, DEVELOPER_EMAIL),

      new Slot("Expiration Date", SLOT, EXPIRATION_DATE),
      new Slot("Contract/ID Number", SLOT, CONTRACT_ID_NUMBER),
      new Slot("Restriction", SLOT, RESTRICTION),

      new Slot("FrameID", SLOT, FRAMEID),
      new Slot("Timestamp", SLOT, TIMESTAMP),
      new Slot("Model System", FRAME, MODEL_SYSTEM),
      new Slot("Declarative Statements", SLOT, DECLARATIVE_STATEMENTS),

      new Slot("Author", FRAME, AUTHOR),
      new Slot("Source Citations", FRAME, SOURCE_CITATIONS),
      new Slot("Support Citations", FRAME, SUPPORT_CITATIONS),
      new Slot("Keywords", SLOT, KEYWORDS),
      new Slot("Peer Review(s)", FRAME, PEER_REVIEWS),
      new Slot("Review", FRAME, REVIEW),
      new Slot("Usage Log", FRAME, USAGE_LOG),
      new Slot("Session", FRAME, SESSION),
      new Slot("Independent Variables", FRAME, INDEPENDENT_VARIABLES),
      new Slot("Variable", FRAME, VARIABLE),
      new Slot("Dependent Variables", FRAME, DEPENDENT_VARIABLES),
      new Slot("Major Controlled Variables", FRAME, MAJOR_CONTROLLED_VARIABLES),
      new Slot("Citation", FRAME, CITATION),

      new Slot("Fuzzy Sets", FRAME, FUZZY_SETS),
      new Slot("Fuzzy Set", FRAME, FUZZY_SET),
      new Slot("Hedges", FRAME, HEDGES),
      new Slot("Hedge", FRAME, HEDGE),
      new Slot("Table", FRAME, TABLE),

      new Slot("Source Frame", FRAME, SOURCE_FRAME),
      new Slot("Technical Frame", FRAME, TECHNICAL_FRAME),
      new Slot("Knowledge Frame", FRAME, KNOWLEDGE_FRAME)
   };

   private static Hashtable slot_table;

   private StreamTokenizer in;
   private LineNumberReader inline;
   private boolean expecting_value;
   private File file_name;
   private boolean pushed_back;

   /**
   * The static initializer, used to save the hashtable version
   * of the slot_table, to allow quick access to slot information
   * based on input tokens.
   */
   static
   {
      // Put the array of slots into a hashtable
      slot_table = new Hashtable();
      for (int i = 0; i < slots.length; i++)
      {
         slot_table.put(slots[i].name.toLowerCase(), slots[i]);
      }
   }

   /**
   * Construct a tokenizer for a given input file
   * name.
   * @param f The input file name.
   */
   public GEKOTokenizer(String f) throws KAFrameException
   {
      initialize(new File(f));
   }

   /**
   * Construct a tokenizer for a given input Java
   * file.
   * @param f The Java file (which is just a cleverer
   * way of storing a file name).
   */
   public GEKOTokenizer(File f) throws KAFrameException
   {
      initialize(f);
   }

   /**
   * Initializes a Java StreamTokenizer to track line numbers
   * and with the characters needed to locate the tokens of
   * interest in a GEKO file.  As it turns out, white space is
   * not interesting, and really just the location of colons
   * and semicolons is important.
   */
   private void initialize(File f) throws KAFrameException
   {
      try
      {
         file_name = f;
         inline = new LineNumberReader(new FileReader(file_name));
         in = new StreamTokenizer(inline);
         in.resetSyntax();
         in.wordChars(0, 255);
         in.ordinaryChar('/');
         in.ordinaryChar('*');
         in.slashStarComments(true);
         in.ordinaryChar(':');
         in.ordinaryChar(';');
         //in.ordinaryChar(' ');
         //in.ordinaryChar('\n');

         expecting_value = false;
         pushed_back = false;
      }
      catch (IOException e)
      {
         throw new KAFrameException(this,
            KAFrameException.IO_ERROR,
            e.toString());
      }
   }

   public void close() throws KAFrameException
   {
      try
      {
         inline.close();
      }
      catch (IOException e)
      {
         throw new KAFrameException(this,
            KAFrameException.IO_ERROR,
            e.toString());
      }
   }

   /**
   * Get the next GEKO token. It is determined from the
   * string values and : or ; positioning in the file, which
   * are returned from the Java stream tokenizer.
   *
   * Note that,
   * following the StreamTokenizer lead, there are public
   * variables in GEKOTokenizer that are set, and these are
   * picked up directly by the calling class, GEKOStreamView.
   * So, for example, the slot_id of a slot is not returned
   * directly, but placed in a public variable where it can
   * be examined.  This works well for push backs, as the
   * tokenizer doesn't have to do anything to 'reread' a token.
   *
   * Note that the expecting_value flag is set based on whether
   * the tokenizer thinks it is looking for a slot name, ending
   * in :, or a value ending in ;;.
   * @return the integer ID of the token type.
   */
   public int nextToken() throws KAFrameException
   {
      if (pushed_back)
      {
         pushed_back = false;
         return token_type;
      }

      StringBuffer buffer = new StringBuffer();
      String key;
      boolean done = false;
      int next_token;

      try
      {
         while (! done)
         {
            in.nextToken();
            switch(in.ttype)
            {
            case StreamTokenizer.TT_EOF:
               token_type = EOF;
               done = true;
               break;
            case StreamTokenizer.TT_WORD:
               // Just keep tacking strings onto the buffer until we
               // reach an interesting character.
               buffer.append(in.sval);
               break;
            //case ' ':
            //case '\n':
            case '/':
            case '*':
               // Put these comment characters back in as they
               // are found.
               buffer.append((char)in.ttype);
               break;
            case ':':
               if (expecting_value)
                  // in this case the : is just a character
                  buffer.append(':');
               else
               {
                  // we've found a slot name, so get all its
                  // details, or report an error if we don't
                  // recognize it.
                  key = buffer.toString().trim().toLowerCase();
                  slot = (Slot)slot_table.get(key);
                  if (slot == null)
                  {
                     throw new KAFrameException(this,
                        KAFrameException.TEXT_BAD_SLOT,
                        key + get_file_info());
                  }

                  switch(slot.type)
                  {
                  case SLOT:
                     expecting_value = true;
                     token_type = SLOT;
                     break;
                  case FRAME:
                     expecting_value = false;
                     token_type = FRAME;
                     break;
                  default:
                     throw new KAFrameException(this,
                        KAFrameException.TEXT_BAD_SLOT,
                        key + get_file_info());
                  }
                  if (key.equals("end"))
                     token_type = EOF;
                  done = true;
               }
               break;
            case ';':
               if (! expecting_value)
                  throw new KAFrameException(this,
                     KAFrameException.TEXT_UNEXPECTED_SEMICOLON,
                     get_file_info());
               else
               // A ;; ends the value, but there might be
               // single ; as part of the text.
               {
                  if (';' == (next_token = in.nextToken()))
                  {
                     token_type = VALUE;
                     value = buffer.toString();
                     expecting_value = false;
                     done = true;
                  }
                  else
                     buffer.append(';' + in.sval);
               }
               break;

            default:
               throw new KAFrameException(this,
                  KAFrameException.TEXT_PARSE_ERROR,
                  get_file_info());
            }
         }
      }
      catch (IOException e)
      {
         throw new KAFrameException(this,
            KAFrameException.IO_ERROR,
            e.toString());
      }

      return token_type;
   }


   public String get_file_info()
   {
      // return file information for error messages, the line
      // number is provided by the Java file filter.
      return " " + file_name + "[" + inline.getLineNumber() + "]";
   }

   /**
   * Tell the tokenizer to return the same thing next time it
   * is called.  Because the information about a token is stored
   * in public variables, all push back has to do is nothing.
   * Just return the same thing next time it is called.
   */
   public void pushBack()
   {
      pushed_back = true;
   }
}