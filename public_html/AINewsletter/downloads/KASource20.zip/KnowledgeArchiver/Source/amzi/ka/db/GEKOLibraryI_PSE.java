// GEKOLibraryI_PSE

package amzi.ka.db;

import amzi.frames.*;
import amzi.frames.pse.*;
import amzi.ka.*;
import amzi.kb.*;
import java.util.*;
import java.io.*;

/**
* An implementation of GEKOLibrary designed
* to run on the server, supporting multiple
* client threads.  Note that if we are running
* from an environment, such as RMI, that creates
* unexpected new threads, we need to call
* kl.initialize(main_thread) as a precaution
* before each call.
* @author Amzi! inc.
*/
public class GEKOLibraryI_PSE implements GEKOLibraryI
{
   KnowledgeLibraryI kl;
   static File archive_path = new File("/KArchives");
   /**
   * The thread used to create this instance.  Other threads
   * are initialized using this thread.  When working with
   * RMI, which creates random new threads, we need to call
   * kl.initialize(main_thread) before each kl call.
   */
   Thread main_thread; 

   /**
   * Static function used to find the available GEKO knowledge
   * archives.
   */
   public static Vector libraries()
   {
//System.out.println("GEKOLibraryI_PSE:libraries " + Thread.currentThread().toString());
      //String dir = "f:/KnowledgeArchiver/gekos";
      //System.out.println("Directory: " + dir);
      //String[] files = (new File(archive_path)).list(new ODBFilter());
      String[] files = archive_path.list(new ODBFilter());
      Vector v = new Vector();
      for (int i=0; i<files.length; i++)
         v.addElement( files[i].substring(0, files[i].indexOf(".odb")) );
      return v;
   }

   public GEKOLibraryI_PSE() throws FrameException
   {
//System.out.println("GEKOLibraryI_PSE:constructor " + Thread.currentThread().toString());
      kl = new KnowledgeLibraryI_PSE();
   }

   //---------------------------------------------------
   // GEKOLibrary extensions

   /**
   * Allow a user to log into the library.
   */
   public void logon(KnowledgeFrame person) throws FrameException
   {}

   /**
   * Allow a user to log out of the library.
   */
   public void logoff(KnowledgeFrame person) throws FrameException
   {}

   /**
   * Initialize a Knowledge Library.
   */
   public void initialize() throws FrameException
   {
      kl.initialize();
   }

   /**
   * Initialize a Knowledge Library.
   * @return The initial thread used for the session.
   */
   public Thread initial_thread() throws FrameException
   {
      main_thread = kl.initial_thread();
//System.out.println("GEKOLibraryI_PSE:initial_thread\n" +
//                   "  this thread " + Thread.currentThread().toString() +
//                   "\n  main thread " + main_thread);
      return main_thread;
   }

   /**
   * Initialize a Knowledge Library by associating the
   * current thread with an existing session.
   * @param th The main thread associated with the session.
   */
   public void initialize(Thread th) throws FrameException
   {
//System.out.println("GEKOLibraryI_PSE:initialize(th) " + Thread.currentThread().toString());
      kl.initialize(th);
   }

   /**
   * Creates a new Knowledge Library.
   */
   public void connect(String ip) throws FrameException
   {}

   /**
   * Creates a new Knowledge Library.
   */
   public void connect(String ip, String port) throws FrameException
   {}

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port, String proxy_host, String proxy_port) throws FrameException
   {}

   /**
   * Creates a new open Knowledge Library.
   */
/*
   public void create(String db_name, String schema_file_name) throws FrameException
   {
      kl.initialize(main_thread);
      kl.create(new File(archive_path, db_name).getPath());

      if (schema_file_name == null)
         return;

      Vector schemas = KnowledgeFrame.readXMLs(
            new File(archive_path, schema_file_name + ".sch") );

      for (int i=0; i < schemas.size(); i++)
      {
         KnowledgeFrame schema = (KnowledgeFrame)schemas.elementAt(i);
         String group = (String)schema.get("group");
         kl.add_group(group);
         put_frame(schema);
      }
   }
*/

   /**
   * Creates a new Knowledge Library.
   */
   public void create(String db_name, String schema_file_name, KnowledgeFrame archivist) throws FrameException
   {
      kl.initialize(main_thread);
      kl.create(new File(archive_path, db_name).getPath());

      // For a closed library, we add a group for archive level information
      // and create an ACL with the archivist as the super user.
      if (archivist != null)
         kl.add_group("archive");

      // Read and load the schemas
      if (schema_file_name == null)
      {
         System.out.println("Created archive with no schema");
         return;
      }
      System.out.println("Creating archive from schema: " + schema_file_name + ".sch");
      Vector schemas = KnowledgeFrame.readXMLs(
            new File(archive_path, schema_file_name + ".sch") );

      for (int i=0; i < schemas.size(); i++)
      {
         KnowledgeFrame schema = (KnowledgeFrame)schemas.elementAt(i);
         String group = (String)schema.get("group");
         kl.add_group(group);
         put_frame(schema);
      }
   }

   /**
   * Creates a new closed Knowledge Library for archivist.
   */
/*
   public void create(String db_name, String schema_file_name, KnowledgeFrame archivist) throws FrameException
   {
      create(db_name, schema_file_name);

      // For a closed library, we add a group for archive level information
      // and create an ACL with the archivist as the super user.
      if (archivist != null)
         kl.add_group("archive");
   }
*/


   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException
   {
      kl.initialize(main_thread);
System.out.println("GEKOLibraryI_PSE:open " + Thread.currentThread().toString());
      kl.open(new File(archive_path, db_name).getPath());
   }

   /**
   * Close an open Knowledge Library.
   */
   public void close() throws FrameException
   {
      kl.initialize(main_thread);
      kl.close();
   }

   /**
   * Check to see if a geko exists for the given title.
   * @param title The title string.
   * @param geko The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_geko(String title, KnowledgeFrame geko) throws FrameException
   {
      kl.initialize(main_thread);
      //If the frame is new, check for a duplicate
      if (geko.get_key() == null)
      {
         QueryFrame qfs = new QueryFrame("Source Frame");
         qfs.set("Title", new QueryOp(QueryOp.EQUALS, title));
         QueryFrame qf = new QueryFrame("geko");
         qf.set("Source Frame", new QueryOp(QueryOp.MATCH_FRAME, qfs));
         Vector v = kl.query(qf);
         if (v.size() > 0)
           return NEW_DUP;
         return NEW_OK;
      }
      //Otherwise, check if it's modified
      else
      {
         KnowledgeFrame g2 = get_frame(geko.group_name(), geko.get_key());
         if (geko.same_state(g2))
            return OLD_OK;
         else
            return OLD_MOD;
      }
   }

  /**
  * Check to see if an author exists with the given name.
  * @param name The name string.
  * @param author The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_author(String name, KnowledgeFrame author) throws FrameException
  {
      kl.initialize(main_thread);
    //If the frame is new, check for a duplicate
    if (author.get_key() == null)
    {
      QueryFrame qf = new QueryFrame("person");
      qf.set("Name", new QueryOp(QueryOp.EQUALS, name));
      Vector v = kl.query(qf);
      if (v.size() > 0)
        return NEW_DUP;
      return NEW_OK;
    }
    //Otherwise, check if it's modified
    else
      {
      KnowledgeFrame a2 = kl.get_frame(author.group_name(), author.get_key());
      System.out.println("comparing authors");
      if (author.same_state(a2))
        return OLD_OK;
      else
        return OLD_MOD;
    }
  }

  /**
  * Check to see if a variable exists with the given name.
  * @param name The name string.
  * @param variable The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_variable(String name, KnowledgeFrame variable) throws FrameException
  {
      kl.initialize(main_thread);
    //If the frame is new, check for a duplicate
    if (variable.get_key() == null)
    {
      QueryFrame qf = new QueryFrame("variable");
      qf.set("Name", new QueryOp(QueryOp.EQUALS, name));
      Vector v = kl.query(qf);
      if (v.size() > 0)
        return NEW_DUP;
      return NEW_OK;
    }
    //Otherwise, check if it's modified
    else
      {
      KnowledgeFrame v2 = kl.get_frame(variable.group_name(), variable.get_key());
      if (variable.same_state(v2))
        return OLD_OK;
      else
        return OLD_MOD;
    }
  }

  /**
  * Check to see if a citation exists with the given body.
  * @param body The body string.
  * @param citation The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_citation(String body, KnowledgeFrame citation) throws FrameException
  {
      kl.initialize(main_thread);
    //If the frame is new, check for a duplicate
    if (citation.get_key() == null)
    {
      QueryFrame qf = new QueryFrame("citation");
      qf.set("Body", new QueryOp(QueryOp.EQUALS, body));
      Vector v = kl.query(qf);
      if (v.size() > 0)
        return NEW_DUP;
      return NEW_OK;
    }
    //Otherwise, check if it's modified
    else
      {
      KnowledgeFrame c2 = kl.get_frame(citation.group_name(), citation.get_key());
      if (citation.same_state(c2))
        return OLD_OK;
      else
        return OLD_MOD;
    }
  }

  /**
  * Check to see if a keyword exists with the given body.
  * @param word The keyword string.
  * @param keyword The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_keyword(String word, KnowledgeFrame keyword) throws FrameException
  {
      kl.initialize(main_thread);
    //If the frame is new, check for a duplicate
    if (keyword.get_key() == null)
    {
      QueryFrame qf = new QueryFrame("keyword");
      qf.set("word", new QueryOp(QueryOp.EQUALS, word));
      Vector v = kl.query(qf);
      if (v.size() > 0)
        return NEW_DUP;
      return NEW_OK;
    }
    //Otherwise, check if it's modified
    else
      {
      KnowledgeFrame k2 = get_frame(keyword.group_name(), keyword.get_key());
      if (keyword.same_state(k2))
        return OLD_OK;
      else
        return OLD_MOD;
    }
  }

   /**
   * Put a new frame up of type 'link'.  It defines relationships
   * between variables, so it must be checked specifically for
   * this particular case.
   */
   public String put_link(KnowledgeFrame link) throws FrameException
   {
      kl.initialize(main_thread);

      String declare = (String)link.get("Declaration");
      KnowledgeFrame existing_link = simple_query("link", "Declaration", declare);
      if (null != existing_link)
      {
         return existing_link.get_key();
      }

      String declaration = (String)link.get("Declaration");

      StringTokenizer tokens = new StringTokenizer(declaration, " ");
      String v1name, ttype, v2name;
      String type;

      try
      {
         v1name = tokens.nextToken();
         ttype = tokens.nextToken();
         v2name = tokens.nextToken();
      }
      catch (NoSuchElementException ex)
      {
         throw new KAFrameException(this, KAFrameException.BAD_LINK_DECLARATION, declaration);
      }

      type = Link.check_type(ttype);
      if (type == null)
      {
         type = ttype;
         //throw new KAFrameException(this, KAFrameException.BAD_LINK_TYPE, ttype);
      }

      link.set("Type", type);

      KnowledgeFrame var1, var2;

      var1 = simple_query("variable", "Name", v1name);
      if (var1 == null)
         throw new KAFrameException(this, KAFrameException.NO_SUCH_VARIABLE, v1name);

      var2 = simple_query("variable", "Name", v2name);
      if (var2 == null)
         throw new KAFrameException(this, KAFrameException.NO_SUCH_VARIABLE, v2name);

      link.set("Variable 1", var1);
      link.set("Variable 2", var2);

      return kl.put_frame(link);
   }

   /**
   * Put a new frame up of type 'variable'.  We need to check
   * the generated 'choices' field and build it from 'menu'
   * if necessary.
   */
   public String put_variable(KnowledgeFrame var) throws FrameException
   {
      String key=null;
      try {
      kl.initialize(main_thread);

      if (dup_var_name(var))
      {
         throw new KAFrameException(this, KAFrameException.DUPLICATE_FRAME, "variable: " + (String)var.get("Name"));
      }

      String type = (String)var.get("Type");
      System.out.println("Putting a variable");
      if (type.equals("string"))
      {
         String menu = (String)var.get("Menu");
         if (menu != null && menu.length() > 2)
         {
            System.out.println(" its a string with menu = " + menu);
            Vector choices;
            Object o = var.get("Choices");
            if (o == null || o.getClass() != KAClasses.cVector)
               choices = new Vector();
            else
               choices = (Vector)o;

            Vector items = get_items(menu);
            String item;
            if (items != null)
            {
               for (int i=0; i<items.size(); i++)
               {
                  item = (String)items.elementAt(i);
                  if (choices.isEmpty() || ! choices.contains(item))
                     choices.addElement(item);
               }
            }
            var.set("Choices", choices);
         }
      }

      key = kl.put_frame(var);
      } catch (Exception ex) {
         System.out.println(ex.getMessage());
         ex.printStackTrace(); }

      return key;
   }

   /**
   * Get quoted string items from a bigger string.
   */
   private Vector get_items(String menu)
   {
      Vector items = new Vector();
      int q1 = menu.indexOf('"');
      int q2;
      while (q1 >= 0)
      {
         q2 = menu.indexOf('"', q1+1);
         q2++;
         items.addElement( menu.substring(q1,q2) );
         q1 = menu.indexOf('"', q2);
      }
      if (items.isEmpty())
         return null;
      else
         return items;
   }

   /**
   * Put up a new GEKO.  Note that this is all a bit kludgy and
   * should be redesigned at sometime.  However, what this code
   * does is read the source code in the knowledge frame of the
   * GEKO and compiles it into a PSERule structure which is stored
   * in the archive.
   */
   public String put_geko(KnowledgeFrame geko) throws FrameException
   {
      System.out.println("*** putting a geko ***");
      kl.initialize(main_thread);

      if (dup_title_check(geko))
      {
         String title = (String)((KnowledgeFrame)geko.get("Source Frame")).get("Title");
         throw new KAFrameException(this, KAFrameException.DUPLICATE_FRAME, "geko: " + title);
      }

      KnowledgeFrame gkf = (KnowledgeFrame)geko.get("Knowledge Frame");
      KnowledgeBuilder kb;
      String key = null;
      String type = (String)gkf.get("Type");
      
      try
      {
         kb = new KnowledgeBuilder(geko, this);
         gkf = kb.parse_kb();
         // sucessful, so mark it an amkes type frame
         gkf.set("Type", "amkes");
         geko.set("Knowledge Frame", gkf);
         System.out.println("*** geko all set ***");
         key = kl.put_frame(geko);
         System.out.println("*** geko really done now ***");
      }
      /*
      catch (KBException ex)
      {
         if (! type.equals("khi"))
         {
            //System.out.println("*** KBException: " + ex.getMessage());
            //ex.printStackTrace();
            throw new KAFrameException(this, KAFrameException.KB_EXCEPTION, ex.getMessage());
         }
         System.out.println("*** bad geko, stored anyway ***");
         key = kl.put_frame(geko);
         System.out.println("*** stored ***");
      }
      */
      catch (Exception ex)
      {
         System.out.println("*** Exception: " + ex.getMessage());
         ex.printStackTrace();
         throw new KAFrameException(this, KAFrameException.EXCEPTION, ex.getMessage());
      }
      catch (Error ex)
      {
         System.out.println("*** Exception: " + ex.getMessage());
         ex.printStackTrace();
         throw new KAFrameException(this, KAFrameException.EXCEPTION, ex.getMessage());
      }

      return key;
   }

   private boolean dup_var_name(KnowledgeFrame var) throws FrameException
   {
      String name = (String)var.get("Name");
      QueryFrame qf = new QueryFrame("variable");
      qf.set("Name", new QueryOp(QueryOp.EQUALS, name));
      Vector v = kl.query(qf);
      if (v.size() > 0)
      {
         String key1 = var.get_key();
         String key2 = ((KeyNotePair)v.firstElement()).get_key();
         if (key1 != null && key1.equals(key2))
            return false;
         else
            return true;
      }
      else
         return false;
   }

   private boolean dup_title_check(KnowledgeFrame geko) throws FrameException
   {
      String title = (String)((KnowledgeFrame)geko.get("Source Frame")).get("Title");
      QueryFrame qfs = new QueryFrame("Source Frame");
      qfs.set("Title", new QueryOp(QueryOp.EQUALS, title));
      QueryFrame qf = new QueryFrame("geko");
      qf.set("Source Frame", new QueryOp(QueryOp.MATCH_FRAME, qfs));
      Vector v = kl.query(qf);
      if (v.size() > 0)
      {
         String key1 = geko.get_key();
         String key2 = ((KeyNotePair)v.firstElement()).get_key();
         if (key1 != null && key1.equals(key2))
            return false;
         else
            return true;
      }
      else
         return false;
   }

   /**
   * Find a knowledge frame based on a query in which a single slot is
   * compared against a single value.  Return just the first if there
   * are multiple solutions.
   */
   private KnowledgeFrame simple_query(String group, String slot_name, String value)
         throws FrameException
   {
      // Create a new query frame for the group.
      QueryFrame qf = new QueryFrame(group);

      // Set a query slot pattern match for the simple equals case.
      qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

      // The query returns a vector of key_note_pairs that
      // satisfy the query.  We'll just take the first one
      // or return null.
      Vector answers = kl.query(qf);
      if (answers.isEmpty())
         return null;
      
      // Retrieve the desired frame.
      String key = ((KeyNotePair)answers.firstElement()).get_key();
      return kl.get_frame(group, key);
   }

   /**
   * Get an array of all the variables in the archive,
   * stored as KB variables for inferencing.
   */
   public Variable[] get_variables() throws FrameException
   {
      Vector kns = get_key_notes("variable");
      KeyNotePair kn;

      Variable[] vars = new Variable[kns.size()];
      Variable v;
      String mvs;
      String ts;
      boolean mvb;
      Object o;
      KnowledgeFrame kfv;

      int i;
      for (i=0; i<kns.size(); i++)
      {
         kn = (KeyNotePair)kns.elementAt(i);
         kfv = (KnowledgeFrame)get_frame("variable", kn.get_key());
         v = new Variable();
         v.set_key( new VariableKey(kfv.get_key()) );
         v.set_name( (String)kfv.get("Name") );

         ts = (String)kfv.get("Type");
         ts = ts.trim();

         if      (ts.equalsIgnoreCase("string"))  v.set_type(Variable.V_STRING);
         else if (ts.equalsIgnoreCase("int"))     v.set_type(Variable.V_INT);
         else if (ts.equalsIgnoreCase("float"))   v.set_type(Variable.V_FLOAT);
         else if (ts.equalsIgnoreCase("boolean")) v.set_type(Variable.V_BOOLEAN);

         mvs = (String)kfv.get("Single Valued");
         mvb = Boolean.valueOf(mvs).booleanValue();
         v.set_multivalued( !mvb );

         o = kfv.get("Choices");
         if (o != null && o.getClass() == KAClasses.cVector)
            v.set_menu((Vector)o);

         vars[i] = v;
      }

      return vars;
   }

   /**
   * Get an array of all the links in the archive.
   */
   public Link[] get_links() throws FrameException
   {
      Vector kns = get_key_notes("link");
      KeyNotePair kn;

      Link link;
      Vector vlinks = new Vector();
      KnowledgeFrame kfl, kfv;
      String type;

      int i;
      for (i=0; i<kns.size(); i++)
      {
         kn = (KeyNotePair)kns.elementAt(i);
         kfl = (KnowledgeFrame)get_frame("link", kn.get_key());

         type = (String)kfl.get("Type");
         if (type != null)
         {
            link = new Link(Link.int_type(type));

            kfv = (KnowledgeFrame)kfl.get("Variable 1");
            link.set_var1( new VariableKey(kfv.get_key()) );

            kfv = (KnowledgeFrame)kfl.get("Variable 2");
            link.set_var2( new VariableKey(kfv.get_key()) );

            vlinks.addElement(link);
         }
      }

      Link[] links = new Link[vlinks.size()];
      for (i=0; i<vlinks.size(); i++)
         links[i] = (Link)vlinks.elementAt(i);

      return links;
   }

   /**
   * Get an array of all the rules in the archive.
   */
   public Rule[] get_rules() throws FrameException
   {
      Vector kns = get_key_notes("geko");
      KeyNotePair kn;
      Rule[] rules;
      String current_geko = null;

      try
      {
         // use a vector because some gekos have multiple rules
         Vector vrules = new Vector();
         Code c;
         KnowledgeFrame kfg;
         KnowledgeFrame kfkf;
         String type;

         int i,j;

         for (i=0; i<kns.size(); i++)
         {
            kn = (KeyNotePair)kns.elementAt(i);
            current_geko = kn.summary();

System.out.println(kn.get_key() + ": " + current_geko);
            try
            {
               kfg = (KnowledgeFrame)get_frame("geko", kn.get_key());
               kfkf = (KnowledgeFrame)kfg.get("Knowledge Frame");
               type = (String)kfkf.get("Type");
               if (type.equals("amkes"))
               {
                  c = get_code(kfg);
                  for (j=0; j<c.rules.length; j++)
                     vrules.addElement(c.rules[j]);
               }
            }
            catch (FrameException ex)
            {
System.out.println("caught error: " + ex.get_error_number());
               if (ex.get_error_number() == FrameException.MISSING_KEY)
                  throw new FrameException(this, FrameException.MISSING_KEY,
                        "in geko: " + current_geko);
               else
                  throw ex;
            }
         }
         rules = new Rule[vrules.size()];
         for (i=0; i<vrules.size(); i++)
            rules[i] = (Rule)vrules.elementAt(i);
      }
      catch (Exception ex)
      {
         System.out.println("*** Exception: " + ex.getMessage());
         ex.printStackTrace();
         throw new KAFrameException(this, KAFrameException.EXCEPTION, ex.getMessage());
      }

      return rules;
   }

   private Code get_code(KnowledgeFrame geko) throws FrameException
   {
      KnowledgeFrame gkf = (KnowledgeFrame)geko.get("Knowledge Frame");
      KnowledgeBuilder kb;
      Code c;
      
      try
      {
         kb = new KnowledgeBuilder(geko, this);
         kb.set_to_from_mode(KnowledgeBuilder.KB_MODE_FROM_ARCHIVE);
         c = kb.parse_archive_geko();
      }
      catch (KBException ex)
      {
         System.out.println("*** KBException: " + ex.getMessage());
         ex.printStackTrace();
         throw new KAFrameException(this, KAFrameException.KB_EXCEPTION, ex.getMessage());
      }
      catch (Exception ex)
      {
         System.out.println("*** Exception: " + ex.getMessage());
         ex.printStackTrace();
         throw new KAFrameException(this, KAFrameException.EXCEPTION, ex.getMessage());
      }

      return c;
   }


   //---------------------------------------------------
   // Basic KnowledgeLibrary interface

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException
   {
      kl.initialize(main_thread);
      kl.add_group(group);
   }

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException
   {
      kl.initialize(main_thread);
      return kl.get_groups();
   }

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException
   {
      if (f.group_name().equals("link"))
         return put_link(f);

      if (f.group_name().equals("geko"))
         return put_geko(f);

      if (f.group_name().equals("variable"))
         return put_variable(f);

      kl.initialize(main_thread);
      return kl.put_frame(f);
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException
   {
      kl.initialize(main_thread);
      kl.remove_frame(f);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key and version
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @param version The version number.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key, int version) throws FrameException
   {
      KnowledgeFrame kf=null;

      try {
      kl.initialize(main_thread);
      kf = kl.get_frame(group, key, version);
      } catch (Exception ex) {
         System.out.println(ex.getMessage());
         ex.printStackTrace(); }

      return kf;
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException
   {
      KnowledgeFrame kf=null;

      try {
      kl.initialize(main_thread);
      kf = kl.get_frame(group, key);
      } catch (Exception ex) {
         System.out.println(ex.getMessage());
         ex.printStackTrace(); }

      return kf;
   }

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException
   {
      kl.initialize(main_thread);
      return kl.get_key_notes(group);
   }

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException
   {
      kl.initialize(main_thread);
      return kl.query(qf);
   }
}

/**
* Filter class used to find archive file names.
*/
class ODBFilter implements FilenameFilter
{
   public boolean accept(File f, String n)
   {
      return n.endsWith(".odb");
   }
}
