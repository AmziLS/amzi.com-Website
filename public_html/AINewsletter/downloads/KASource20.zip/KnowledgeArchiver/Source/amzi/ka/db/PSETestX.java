// PSETest.java

package amzi.ka.db;

import amzi.frames.*;
import amzi.kb.*;

import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

public class PSETest
{
   Integer op;
   Object arg1;
   Object arg2;

/*
   transient static Class cPSETest;
   transient static Class cPSEVariable;
   transient static Class cPSEExpression;

   static
   {
      cPSETest = Class.forName("amzi.ka.db.PSETest");
      cPSEVariable = Class.forName("amzi.ka.db.PSEVariable");
      cPSEExpression = Class.forName("amzi.ka.db.PSEExpression");
   }
*/

   public PSETest(int op, Object a1, Object a2)
   {
      this.op = new Integer(op);
      arg1 = a1;
      arg2 = a2;
   }

   public Test makeTest()
   {
      Test t = new Test(op.intValue());

      if (arg1.getClass() == PSEClasses.cPSETest)
         t.set_arg1( ((PSETest)arg1).makeTest() );
      else if (arg1.getClass() == PSEClasses.cPSEVariable)
         t.set_arg1( ((PSEVariable)arg1).makeVariableKey() );
      else if (arg1.getClass() == PSEClasses.cPSEExpression)
         t.set_arg1( ((PSEExpression)arg1).makeExpression() );
      else
         t.set_arg1(arg1);

      if (arg2.getClass() == PSEClasses.cPSETest)
         t.set_arg2( ((PSETest)arg2).makeTest() );
      else if (arg2.getClass() == PSEClasses.cPSEVariable)
         t.set_arg2( ((PSEVariable)arg2).makeVariableKey() );
      else if (arg2.getClass() == PSEClasses.cPSEExpression)
         t.set_arg2( ((PSEExpression)arg2).makeExpression() );
      else
         t.set_arg2(arg2);

      return t;
   }

   public void print(PrintStream o)
   {
      print("", o);
   }

   public void print(String dent, PrintStream o)
   {
      o.println(dent + toString());
   }

   public String toString()
   {
      return arg1.toString() + " " +
           Test.ops[op.intValue()] + " " + arg2.toString();
   }
}