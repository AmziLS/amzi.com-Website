// GEKOSession_PSE.java

package amzi.ka.net.rmi.server;

import amzi.ka.*;
import amzi.ka.db.*;
import amzi.frames.*;
import java.net.*;
import COM.odi.*;
import COM.odi.util.*;

/**
* Create a main thread for a PSE session.  Actual users
* of an archive will join this thread.
*/
public class GEKOSession_PSE extends Thread
{
   //String archive;
   boolean needed;
   GEKOLibraryI gekos = null;
   KnowledgeFrame archivist = null;

   public GEKOSession_PSE()
   {
      //this.archive = archive;
      needed = true;
      gekos = null;
   }

   public synchronized GEKOLibraryI get_archive() throws KAFrameException
   {
      try
      {
         while (gekos == null)
            wait();
      }
      catch (InterruptedException e)
      {
         throw new KAFrameException(this, KAFrameException.THREAD_INTERRUPT);
      }
      return gekos;
   }

   public synchronized void set_archive(GEKOLibraryI a)
   {
      gekos = a;
      notify();
   }

   public synchronized void set_needed(boolean b) { needed = b; }

   public void run()
   {
      try
      {
         // Open a new library, starting a new OS session with
         // this thread.  Real users will join this thread.
         GEKOLibraryI g = (GEKOLibraryI)new GEKOLibraryI_PSE();
         g.initial_thread();

         // The creator is waiting for the archive to be open.
         set_archive(g);
         setPriority(Thread.MIN_PRIORITY);
         while (needed)
            yield();
         g.close();
      }
      catch (Exception e)
      {
         System.out.println(e.getMessage());
         e.printStackTrace();
      }
   }
}