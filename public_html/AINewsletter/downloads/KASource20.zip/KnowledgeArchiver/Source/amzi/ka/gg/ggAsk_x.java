// ggAsk.java

package amzi.ka.gg;

import amzi.kb.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ggAsk extends JDialog
      implements ItemListener, ActionListener
{
   JFrame parent;
   Variable var;
   ggConsult gg_consult;
   JDialog dispose_also;

   JComboBox m_choice;
   JComboBox m_bool;
   JTextField m_text;
   JButton m_int_button;
   JButton m_float_button;

   public ggAsk(JFrame p, JDialog d, ggConsult c, Variable v)
   {
      // modal dialogs don't work under Windows at this time.
      super(p, "Variable " + v.get_name(), false);
      parent = p;
      var = v;
      gg_consult = c;
      dispose_also = d;
      ui_init();
   }

   public ggAsk(JFrame p, ggConsult c, Variable v)
   {
      super(p, "Variable " + v.get_name(), false);
      parent = p;
      var = v;
      gg_consult = c;
      dispose_also = null;
      ui_init();
   }

   private void ui_init()
   {
      Dimension psz = parent.getSize();
      Point ploc = parent.getLocation();
      Point loc = new Point(ploc.x + psz.width/2 + 20, ploc.y + psz.height/2 - 20);
      Dimension sz = new Dimension(psz.width/4, psz.height/4);
      setSize(sz);
      setLocation(loc);

      JPanel p = new JPanel();
      GridBagLayout gb = new GridBagLayout();
      p.setLayout(gb);

      GridBagConstraints gc = new GridBagConstraints();
      gc.fill = GridBagConstraints.BOTH;
      gc.gridy = 0;
      gc.gridx = 0;
      //gc.insets = new Insets( 5, 10, 5, 10 );

      //JTextField t = new JTextField();
      //t.setLineWrap(true);
      //t.setText("What is the value of " + var.get_name());
      JTextPane t = new JTextPane();
      //JScrollPane st = new JScrollPane(t);
      t.setText("What is the value of " + var.get_name());
      //Document d = t.getDocument();
      //d.insertString(0,
      //   "What is the value of " + var.get_name(), null)
      gb.setConstraints(t, gc);
      p.add(t);

      if (var.get_type() == Variable.V_STRING)
      {
         m_choice = new JComboBox(var.get_menu());
         m_choice.addItemListener(this);
         gc.fill = GridBagConstraints.HORIZONTAL;
         gc.gridy = 1;
         gc.weighty = 1.0;
         gc.anchor = GridBagConstraints.NORTH;
         gb.setConstraints(m_choice, gc);
         p.add(m_choice);
      }
      else if (var.get_type() == Variable.V_BOOLEAN)
      {
         String[] tf = {"true","false"};
         m_bool = new JComboBox(tf);
         m_bool.addItemListener(this);
         gc.fill = GridBagConstraints.HORIZONTAL;
         gc.gridy = 1;
         gc.weighty = 1.0;
         gc.anchor = GridBagConstraints.NORTH;
         gb.setConstraints(m_bool, gc);
         p.add(m_bool);
      }
      else if (var.get_type() == Variable.V_INT)
      {
         m_text = new JTextField();
         gc.fill = GridBagConstraints.HORIZONTAL;
         gc.gridy = 1;
         gc.weighty = 1.0;
         gc.anchor = GridBagConstraints.NORTH;
         gb.setConstraints(m_text, gc);
         p.add(m_text);
         m_int_button = new JButton("OK");
         m_int_button.addActionListener(this);
         gc.gridy = 2;
         gb.setConstraints(m_int_button, gc);
         p.add(m_int_button);
      }
      else if (var.get_type() == Variable.V_FLOAT)
      {
         m_text = new JTextField();
         gc.fill = GridBagConstraints.HORIZONTAL;
         gc.gridy = 1;
         gc.weighty = 1.0;
         gc.anchor = GridBagConstraints.NORTH;
         gb.setConstraints(m_text, gc);
         p.add(m_text);
         m_float_button = new JButton("OK");
         m_float_button.addActionListener(this);
         gc.gridy = 2;
         gb.setConstraints(m_float_button, gc);
         p.add(m_float_button);
      }
      getContentPane().add(p);
      //setVisible(true);
      show();
   }

   /**
   * Implementation of ItemListener.
   */
   public void itemStateChanged(ItemEvent e)
   {
      if (e.getSource() == m_choice)
      {
         if (e.getStateChange() == ItemEvent.SELECTED)
         {
            gg_consult.set_value(var, e.getItem());
            if (dispose_also != null)
               dispose_also.dispose();
            else
               gg_consult.carry_on();
            dispose();
         }
      }
      else if (e.getSource() == m_bool)
      {
         if (e.getStateChange() == ItemEvent.SELECTED)
         {
            gg_consult.set_value( var, Boolean.valueOf((String)e.getItem()) );
            if (dispose_also != null)
               dispose_also.dispose();
            else
               gg_consult.carry_on();
            dispose();
         }
      }
   }

   /**
   * Implementation of ActionListener.
   */
   public void actionPerformed( ActionEvent e )
   {
      Integer Ival;
      Double Dval;

      if (e.getSource() == m_int_button)
      {
         Ival = Integer.valueOf(m_text.getText());
         gg_consult.set_value(var, Ival);
         if (dispose_also != null)
            dispose_also.dispose();
         else
            gg_consult.carry_on();
         dispose();
      }
      else if (e.getSource() == m_float_button)
      {
         Dval = Double.valueOf(m_text.getText());
         gg_consult.set_value(var, Dval);
         if (dispose_also != null)
            dispose_also.dispose();
         else
            gg_consult.carry_on();
         dispose();
      }
   }
}