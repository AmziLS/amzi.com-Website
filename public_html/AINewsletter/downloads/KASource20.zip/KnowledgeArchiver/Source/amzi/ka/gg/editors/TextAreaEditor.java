package amzi.ka.gg.editors;

import amzi.ka.gg.*;
import javax.swing.*;
import javax.swing.event.*;
import amzi.ka.*;
import amzi.frames.*;
import java.awt.Color;
import java.beans.*;
/**
* A simple totally unstructured text editor for editing string data
* in a Gekko slot value (need to abstract this upwards ..)
*/
public class TextAreaEditor extends BrowserEditor implements DocumentListener {
    private JTextPane m_textpane;
    //private JEditorPane m_textpane;
    private JScrollPane m_scroller;
    public TextAreaEditor() {
        m_textpane = new JTextPane();
        //m_textpane = new JEditorPane();
        //m_textpane.setContentType("text/html");
        //m_textpane.setEditable(false);
        m_textpane.getDocument().addDocumentListener(this);
        m_scroller = new JScrollPane(m_textpane);
        setEnabled(true);
    }
    
    public void changedUpdate(DocumentEvent e) {};
    
    // Called if text inserted
    public void insertUpdate(DocumentEvent e) {        
        if (null != m_browser)
            m_browser.setDirty();        
        synchValue();
    }
    
    // Called if text deleted
    public void removeUpdate(DocumentEvent e) {        
        if (null != m_browser)
            m_browser.setDirty();        
        synchValue();
    }

    public JComponent getWidget() {
        return (JComponent) m_textpane;
    }
        
    // Initilize editor from object
    public void setValue(Object val) throws Exception {   
        boolean wasdirty;
        m_val = val;
        if (val instanceof KnowledgeSlot)
            val = ((KnowledgeSlot) val).value();           
        // Avoid dirtying at the start
        wasdirty = m_browser.isDirty();
        if (val.toString().length() != 0)
            m_textpane.setText(val.toString());
        else
            m_textpane.setText("");
        m_textpane.setCaretPosition(0);    // fix disappearing caret ??        
        if (! wasdirty) m_browser.setClean();
    }
       
    /** Any text is always valid */
    public boolean looseFocus() throws Exception {
        synchValue();
        return true;
    }
    
    /** Editing the string in th epane may have reallocated it
    * and the owning slot will, in that case, be pointing at the
    * old slot
    */
    public void synchValue() {
        // Arghh ... I have to check to make sure the
        // destination is a string --- I got hosed
        // writing back the string rep of a subframe
        // back to the subframe ..
        KnowledgeSlot ks;
        
        if (m_val instanceof KnowledgeSlot) {
            ks = (KnowledgeSlot) m_val;
            if (ks.value() instanceof java.lang.String)
                ks.set_value(m_textpane.getText());
        } else if (m_val instanceof String){
            m_val = m_textpane.getText();
        }
    }
    
    // En/Dis able editing
    public void setEnabled(boolean flag) {
        if (flag) {
            m_textpane.requestFocus();            
            m_textpane.setEnabled(true);
            m_textpane.setBackground(Color.white);
        } else {
            m_textpane.setEnabled(false);
            m_textpane.setBackground(Color.lightGray);
            m_textpane.setDisabledTextColor(Color.black);
        }
    }
    
    public void setColor(Color color) {
        m_textpane.setBackground(color);
    }
}