/*
		Session object -- maintains all connectivity related info for
		client-archive connection
*/
package amzi.ka.gg;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Enumeration;
import java.io.*;
import java.beans.*;

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.clientdb.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;
import amzi.kb.*;  //dcm

public class Session {
    
    private GEKOClientI m_lib = null; // The client library for this session   
    private JOptionPane m_connDlg;
    private JPanel m_pane;
    private JTextField m_address, m_user, m_password, m_archive;
    private JButton m_connect, m_cancel;
    private JFrame m_parent;
    private BrowserContainer m_container;
    private String m_archive_name = null;
    private Vector m_group_browser_list = null; // So we can close group browsers on archive close
    private boolean m_connected = false;
    private static boolean m_connecting = false; // Prevent double connections 
    
    /**
    * Create a 'connect dialog'
    */    
    public Session(JFrame parent, BrowserContainer bc, boolean local) { 
        Box b1, b2, b3;
        
        if (m_connecting)
            return;            
        m_connecting = true;
        m_parent = parent;
        m_container = bc;
        m_group_browser_list = new Vector();

        MainFrame.println("Opening session with: " +
                 GEKOClientI.RELEASE);        
        Cursor old_curse = m_parent.getCursor();                  
        parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));        
        // Invoked from menu
        if (local) {
            m_lib = new GEKOClientI_PSE(); 
            try {
                m_lib.connect("");
                m_lib.logon("", "");            
            } catch (Exception e0) {
                ErrorMessage.message(m_parent, ErrorMessage.EM_SERVER_CONNECT, "Local logon");
            }

            m_archive_name = null;
            m_container.openedSession(this);    
            parent.setCursor(old_curse);
            m_connected = true;
            m_connecting = false;
            return;
        }
        Object options[] = {"SessionConnect", "Cancel"};
            
        b1 = new Box(BoxLayout.X_AXIS);
        b2 = new Box(BoxLayout.Y_AXIS);
        b3 = new Box(BoxLayout.X_AXIS);
        
        m_pane = new JPanel();
        m_pane.setBorder(new EmptyBorder(10, 10, 10, 10));
        m_pane.setLayout(new BorderLayout(0, 0));
        m_pane.add("North", b1);
        m_pane.add("Center", b2);
        m_pane.add("South", b3);
        //
        m_address = new JTextField("209.251.13.82:1099      ");
        Dimension size = m_address.getMinimumSize();
        size.width = 10000;
        m_address.setMaximumSize(size);
        b1.add(new JLabel("Server Address  "));
        b1.add(m_address);
        //
        m_user = new JTextField("");
        size = m_user.getMinimumSize();
        size.width = 10000;
        m_user.setMaximumSize(size);
        b2.add(new JLabel("User ID  "));
        b2.add(m_user);
        //
        m_password = new JTextField("");
        size = m_password.getMinimumSize();
        size.width = 10000;
        m_password.setMaximumSize(size);
        b2.add(new JLabel("Password  "));
        b2.add(m_password);
        //
        m_archive = new JTextField("");
        size = m_archive.getMinimumSize();
        size.width = 10000;
        m_archive.setMaximumSize(size);
        b2.add(new JLabel("Archive  "));
        b2.add(m_archive);
      
        m_connDlg = new JOptionPane(m_pane, JOptionPane.QUESTION_MESSAGE,
                                      JOptionPane.OK_CANCEL_OPTION, new ImageIcon("\\ka\\images\\gg.jpg"),
                                      options, options[0]);
        m_connDlg.createDialog(parent, "Connect to Archive").show();
        if (m_connDlg.getValue().equals("SessionConnect")) {
            parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));
            try {     
           //dcm Use personal db version if no internet address
                if (m_address.getText().trim().length() > 0)
                {
                    MainFrame.println("connecting to server address: " +
                            "'" + m_address.getText().trim() + "'");
                    m_lib = (GEKOClientI)new GEKOClientI_RMI();  //dcm14
                }
                else
                {
                    MainFrame.println("connecting to local db");
                    m_lib = new GEKOClientI_PSE();     
                }                
                m_lib.connect(m_address.getText());
                m_lib.logon( m_user.getText(), m_password.getText());
            } catch (Exception e2) {
                ErrorMessage.message(m_parent, ErrorMessage.EM_SERVER_CONNECT, m_address.getText());
                MainFrame.println("Session:'Session Connect':" + e2);
                parent.setCursor(old_curse);                                              
                m_connecting = false;
                return;
            }
            if (m_archive.getText().length() > 0)
                openArchive(m_archive.getText());
            else
                m_archive_name = null;
            m_container.openedSession(this);    
            parent.setCursor(old_curse);
            m_connected = true;
            m_connecting = false;
        }

    }
    
    public void logoff() {
        try {
            closeArchive();
            m_lib.logoff();
        } catch (Exception e) {
            ErrorMessage.message(m_parent, ErrorMessage.EM_SERVER_DISCONNECT);            
        }
    }
    
    public void doGroups() {
        GroupBrowser gb;
        try {
            gb = new GroupBrowser(m_lib, m_container, m_archive_name); 
            m_container.register(gb);
            m_group_browser_list.addElement(gb);
        } catch (Exception e2) {
            MainFrame.println("Exception getgrpups " + e2);
        }
    }
     
    /*
    * Did I connect succesfully
    */
    public boolean connected() {
        return m_connected;
    }

    /** 
    * Close currently connected archive
    */
    public void closeArchive() {
        Enumeration gbrowsers;
        Cursor old_curse = m_parent.getCursor();  
        m_parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));        
        try {
            if (null != m_archive_name && null != m_lib) {
                m_lib.close(m_archive_name);
                m_archive_name = null;
                m_container.closedArchive(this);
                m_container.setSchemaSource(null);
                gbrowsers = m_group_browser_list.elements();
                while (gbrowsers.hasMoreElements()) 
                    m_container.deregister((JInternalFrame) gbrowsers.nextElement());
                m_group_browser_list.removeAllElements();                
            }
        } catch (Exception e) {
            MainFrame.println("Session:closeArchive():" + e);
        }
        m_parent.setCursor(old_curse);
    }
    
    /**
    * Open new archive
    * @param name - archive name
    */
    public void openArchive(String name) {
        Cursor old_curse = m_parent.getCursor();  
        m_parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        
        try {
            if (null != m_archive_name)
                closeArchive();
            m_archive_name = null;
            m_lib.open(name);
            m_archive_name = name;            
            m_container.openedArchive(this, name);
            m_container.setSchemaSource(new SchemaSource(m_lib));
            doGroups();
        } catch (Exception e) {
            ErrorMessage.message(m_parent, ErrorMessage.EM_ARCHIVE_OPEN, name + " " + e.getMessage());
            MainFrame.println("Session:openArchive(): " + e);
        }
        m_parent.setCursor(old_curse);
    }
    
    public void createArchive(String name) {
        try {
            m_lib.create(name, "default");
        } catch (Exception e) {
            ErrorMessage.message(m_parent, ErrorMessage.EM_ARCHIVE_CREATE, name + " " + e.getMessage());          
            MainFrame.println("Session.createArchive():" + e);                                          
        }
    }
    
    /**  List the archives -- give the user the opportunity to open
    * one from the list
    */
    public void listArchives() {
        
        try {
            GGDialog d;
            JScrollPane sp;
            JList list = new JList(m_lib.get_archives());
            
            if (list.getComponentCount() > 0) {
                list.setSelectedIndex(0);
                sp = new JScrollPane(list);            
                d = new GGDialog(GGDialog.OK_CANCEL_DIALOG, "Archives", "Select an archive", 
                                sp, list);
                if (! d.getValue().equals("Cancel")) {
                    openArchive(list.getSelectedValue().toString());
                }
            } else {
                new GGDialog(GGDialog.OK_DIALOG, "Archives", "No archives available", null, null);
            }
        } catch (Exception e) {
            MainFrame.println("Session.listArchives():" + e);
        }        
    }
    
    /**
    * @return name of currently opened archive (or null)
    */
    public String getArchiveName() {
        return m_archive_name;
    }
    
    
    public GEKOClientI getLib() {
        return m_lib;
    }

   /**
   * Register all the gekos in a subdirectory of gekos.
   */
    public void doBatch()
    {
       String[] files = null;
       PrintWriter log = null;
       File dir = null;
       KnowledgeFrame current_geko;

       try {
         if (null == (dir = select_directory()))
            return;
         if (null == (files = dir.list(new GKOXMLFilter())))
            return;
         log = new PrintWriter(new FileOutputStream("log.txt"), true);
       } catch (Exception ex) {
            ErrorMessage.message(m_parent, ErrorMessage.EM_IO_PROBLEM, ex.getMessage());
            MainFrame.println("Session.doBatch():" + ex); 
            return;
       }

      for (int i=0; i<files.length; i++)
      {
         try
         {
            MainFrame.println("Registering: " + files[i].toString());
            log.println("Registering: " + files[i].toString());
            BufferedReader br = new BufferedReader(new FileReader(new File(dir, files[i])));
            String first_line = br.readLine();
            br.close();
            if (first_line.startsWith("<?XML"))
            {
               current_geko = KnowledgeFrame.readXML(new File(dir, files[i]));
            }
            else
            {
               GEKOStreamView v = new GEKOStreamView(GEKOStreamView.IN, new File(dir, files[i]));
               current_geko = v.input();
               v.close();
            }
            register_geko(current_geko, log);
         }
         catch (Exception e)
         {
            log.println("*** Error: " + e.getMessage());
            MainFrame.println("*** Error: " + e.getMessage());
         }
      }

      log.close();
      MainFrame.println("*** DONE ***");
      return;
    }

   /**
   * Does all the work of ensuring that the shared sub-frames of a new
   * GEKO are indeed shared.
   */
   private void register_geko(KnowledgeFrame geko, PrintWriter log) throws FrameException, IOException
   {
      KnowledgeFrame source, technical, knowledge, author, variable, citation, keyword;
      KnowledgeList ivars, cits, kwords;
      int i;
      GEKOClientI gekos = m_lib;

      source = (KnowledgeFrame)geko.get("Source Frame");
      author = (KnowledgeFrame)source.get("Author");
      technical = (KnowledgeFrame)geko.get("Technical Frame");
      knowledge = (KnowledgeFrame)geko.get("Knowledge Frame");

      switch (gekos.check_geko((String)source.get("Title"), geko))
      {
      case GEKOClientI.NEW_OK:
         break;
      case GEKOClientI.NEW_DUP:
         log.println("CANCEL: A GEKO with the same title already exists in the archive: " + geko.summary());
         return;
      case GEKOClientI.OLD_OK:
         log.println("This GEKO has already been uploaded to the archive:" + geko.summary());
         //String answer = prompt("Continue to update existing copy with this version? (y/n)");
         //if (answer.equals("n"))
            return;
         //break;
      case GEKOClientI.OLD_MOD:
         log.println("CANCEL: This GEKO is an old version of an archive GEKO: " + geko.summary());
         return;
      }

      switch (gekos.check_author((String)author.get("Name"), author))
      {
      case GEKOClientI.NEW_OK:
         log.println("Adding new author: " + author.summary());
         //key = gekos.put_frame(author);
         //author = gekos.get_frame("person", key);
         //source.set("Author", author);
         break;
      case GEKOClientI.NEW_DUP:
         MainFrame.println("Using author of same name from archive");
         log.println("Using author of same name from archive: " + author.summary());
         author = simple_query("person", "Name", (String)author.get("Name"));
         source.set("Author", author);
         break;
      case GEKOClientI.OLD_MOD:
         MainFrame.println("Using latest version of this author from archive.");
         log.println("Using latest version of this author from archive: " + author.summary());
         author = gekos.get_frame("person", author.get_key());
         source.set("Author", author);
         break;
      }

      ivars = (KnowledgeList)knowledge.get("Dependent Variables");
      for (i=0; i < ivars.length(); i++)
      {
         KnowledgeSlot s = ivars.slot_at(i);
         variable = (KnowledgeFrame)s.value();
         switch (gekos.check_variable((String)variable.get("Name"), variable))
         {
         case GEKOClientI.NEW_OK:
            MainFrame.println("Adding new dependent variable");
            log.println("Adding new dependent variable: " + variable.summary());
            //key = gekos.put_frame(variable);
            //variable = gekos.get_frame("variable", key);
            //s.set_value(variable);
            break;
         case GEKOClientI.NEW_DUP:
            MainFrame.println("Using variable of same name from archive");
            log.println("Using variable of same name from archive: " + variable.summary());
            variable = simple_query("variable", "Name", (String)variable.get("Name"));
            s.set_value(variable);
            break;
         case GEKOClientI.OLD_MOD:
            MainFrame.println("Using latest version of this variable from archive.");
            log.println("Using latest version of this variable from archive: " + variable.summary());
            variable = gekos.get_frame("variable", variable.get_key());
            s.set_value(variable);
            break;
         }
      }

      ivars = (KnowledgeList)knowledge.get("Independent Variables");
      for (i=0; i < ivars.length(); i++)
      {
         KnowledgeSlot s = ivars.slot_at(i);
         variable = (KnowledgeFrame)s.value();
         switch (gekos.check_variable((String)variable.get("Name"), variable))
         {
         case GEKOClientI.NEW_OK:
            log.println("Adding new independent variable");
            //key = gekos.put_frame(variable);
            //variable = gekos.get_frame("variable", key);
            //s.set_value(variable);
            break;
         case GEKOClientI.NEW_DUP:
            log.println("Using variable of same name from archive: " + variable.summary());
            variable = simple_query("variable", "Name", (String)variable.get("Name"));
            s.set_value(variable);
            break;
         case GEKOClientI.OLD_MOD:
            log.println("Using latest version of this variable from archive: " + variable.summary());
            variable = gekos.get_frame("variable", variable.get_key());
            s.set_value(variable);
            break;
         }
      }

      if (knowledge.slot_exists("Major Controlled Variables"))
      {
         ivars = (KnowledgeList)knowledge.get("Major Controlled Variables");
         for (i=0; i < ivars.length(); i++)
         {
            KnowledgeSlot s = ivars.slot_at(i);
            variable = (KnowledgeFrame)s.value();
            switch (gekos.check_variable((String)variable.get("Name"), variable))
            {
            case GEKOClientI.NEW_OK:
               log.println("Adding new controlled variable: " + variable.summary());
               //key = gekos.put_frame(variable);
               //variable = gekos.get_frame("variable", key);
               //s.set_value(variable);
               break;
            case GEKOClientI.NEW_DUP:
               log.println("Using variable of same name from archive: " + variable.summary());
               variable = simple_query("variable", "Name", (String)variable.get("Name"));
               s.set_value(variable);
               break;
            case GEKOClientI.OLD_MOD:
               log.println("Using latest version of this variable from archive: " + variable.summary());
               variable = gekos.get_frame("variable", variable.get_key());
               s.set_value(variable);
               break;
            }
         }
      }

      cits = (KnowledgeList)source.get("Source Citations");
      for (i=0; i < cits.length(); i++)
      {
         KnowledgeSlot s = cits.slot_at(i);
         citation = (KnowledgeFrame)s.value();
         switch (gekos.check_citation((String)citation.get("Body"), citation))
         {
         case GEKOClientI.NEW_OK:
            log.println("Adding new citation: " + citation.summary());
            //key = gekos.put_frame(citation);
            //citation = gekos.get_frame("citation", key);
            //s.set_value(citation);
            break;
         case GEKOClientI.NEW_DUP:
            log.println("Using citation of same name from archive: " + citation.summary());
            citation = simple_query("citation", "Body", (String)citation.get("Body"));
            s.set_value(citation);
            break;
         case GEKOClientI.OLD_MOD:
            log.println("Using latest version of this citation from archive: " + citation.summary());
            citation = gekos.get_frame("citation", citation.get_key());
            s.set_value(citation);
            break;
         }
      }

      if (source.slot_exists("Support Citations"))
      {
         cits = (KnowledgeList)source.get("Support Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               log.println("Adding new citation: " + citation.summary());
               //key = gekos.put_frame(citation);
               //citation = gekos.get_frame("citation", key);
               //s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               log.println("Using citation of same name from archive: " + citation.summary());
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               log.println("Using latest version of this citation from archive: " + citation.summary());
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }

      kwords = (KnowledgeList)source.get("Keywords");
      for (i=0; i < kwords.length(); i++)
      {
         KnowledgeSlot s = kwords.slot_at(i);
         keyword = (KnowledgeFrame)s.value();
         switch (gekos.check_keyword((String)keyword.get("word"), keyword))
         {
         case GEKOClientI.NEW_OK:
            log.println("Adding new keyword: " + keyword.summary());
            //key = gekos.put_frame(keyword);
            //keyword = gekos.get_frame("keyword", key);
            //s.set_value(keyword);
            break;
         case GEKOClientI.NEW_DUP:
            log.println("Using keyword of same name from archive: " + keyword.summary());
            keyword = simple_query("keyword", "word", (String)keyword.get("word"));
            s.set_value(keyword);
            break;
         case GEKOClientI.OLD_MOD:
            log.println("Using latest version of this keyword from archive: " + keyword.summary());
            keyword = gekos.get_frame("keyword", keyword.get_key());
            s.set_value(keyword);
            break;
         }
      }

      gekos.put_frame(geko);
   }

   /**
   * Find a knowledge frame based on a query in which a single slot is
   * compared against a single value.  Return just the first if there
   * are multiple solutions.
   */
   private KnowledgeFrame simple_query(String group, String slot_name, String value)
         throws FrameException
   {
      // Create a new query frame for the group.
      QueryFrame qf = new QueryFrame(group);

      // Set a query slot pattern match for the simple equals case.
      qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

      // The query returns a vector of key_note_pairs that
      // satisfy the query.  We'll just take the first one
      // or return null.
      Vector answers = m_lib.query(qf);
      if (answers.isEmpty())
         return null;
      
      // Retrieve the desired frame.
      String key = ((KeyNotePair)answers.firstElement()).get_key();
      return m_lib.get_frame(group, key);
   }

   /**
    * Class to filter geko file extensions.
    */
   class GKOXMLFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return (n.endsWith(".xml") || n.endsWith(".gko"));
      }
   }

   private File select_directory()
   {
      File f = null;
      try
      {
         //File path = new File("\\japps\\infer");
         Cursor old_curse = m_parent.getCursor();
         m_parent.setCursor(new Cursor(Cursor.WAIT_CURSOR));
         //JFileChooser fc = new JFileChooser( path );
         JFileChooser fc = new JFileChooser();
         fc.setFileSelectionMode( JFileChooser.DIRECTORIES_ONLY );
         m_parent.setCursor(old_curse);
         if (fc.showOpenDialog(m_parent) == 0)
            f = fc.getSelectedFile();
      }
      catch (Exception ex)
      {
         MainFrame.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
      }

      return f;
   }    
} 