/** 
* A useful menu item creation class
*/
package amzi.ka.gg;

import java.awt.event.ActionListener;

/** Purely a convenience .. */
public class GMenuItem extends javax.swing.JMenuItem {

    public GMenuItem(ActionListener al, String text, String command, String tooltip, char mnemonic) {
        super();

		setText(text);
		setActionCommand(command);
		setAlignmentY(0.5F);
		setAlignmentX(0.5F);
		setToolTipText(tooltip);
		setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
		if ((char) 0 != mnemonic)
		    setMnemonic(mnemonic);
		if (null != al)
		    addActionListener(al);
    }
}