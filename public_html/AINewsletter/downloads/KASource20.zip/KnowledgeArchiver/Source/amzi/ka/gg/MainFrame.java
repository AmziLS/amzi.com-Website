/*
		A basic implementation of the JFrame class.
*/
package amzi.ka.gg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Enumeration;
import java.beans.*;

import java.io.*;
import amzi.ka.*;
import amzi.frames.*;

public class MainFrame extends JFrame 
implements ActionListener, BrowserContainer, PropertyChangeListener
{
    private JDesktopPane m_desk;
    private Session m_session;
    private String m_title = "AMKES KA Client";    
    private String m_client_version = "2.0,026";
    private String m_version = "2.0 beta";
    private String m_release_date = "2\\04\\99";
    private SchemaSource m_schema_source;
    private int m_browser_x_offset = 0, m_browser_y_offset = 0;
    private ggLog m_log = null;
    private PropertyChangeSupport m_property_change;
    private static boolean m_debug = false;
    
	JMenuBar MainFrameMenu;
	JMenu FileMenu;
	JMenuItem FileLogonMI, FileLocalLogonMI, 
	          FileLogoffMI, FileLogMI, FileBatchMI, FileExitMI;
	
	JMenu ObjectMenu, ObjectNewMI, ObjectQueryMI;
	JMenuItem ObjectOpenMI;              
	          

	JMenu ArchiveMenu;
	JMenuItem ArchiveOpenMI, ArchiveCloseMI, 
              ArchiveGroupsMI, ArchiveCreateMI,
              ArchiveConsultMI; 
    
    JMenu HelpMenu;
    JMenuItem HelpAboutMI, HelpContentsMI;
    
	public MainFrame(String args[])
	{
	    try {
	        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	    } catch (Exception e) {
	        System.out.println("Cannot load windows look-and-feel: " + e);
	        System.exit(-1);
	    }
	    
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        
	    setTitle(m_title);
		getContentPane().setLayout(new BorderLayout(0,0));
		setVisible(false);
		
		setSize(new Dimension((int)(screenSize.width * 0.75), (int)(screenSize.height * 0.75)));
		setLocation((int)(screenSize.width * 0.125), (int)(screenSize.height * 0.125));
		setBackground(Color.lightGray);
		MainFrameMenu = new javax.swing.JMenuBar();
        // ---------------------------------------------------
 		FileMenu = new javax.swing.JMenu();
		FileMenu.setText("File");
		FileMenu.setActionCommand("File");
		FileMenu.setAlignmentY(0.5F);
		FileMenu.setAlignmentX(0.5F);
		FileMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);		
        FileMenu.setMnemonic('f');		
		MainFrameMenu.add(FileMenu);
 
 		FileLogonMI = new GMenuItem(this, "Logon", "logon", "Logon to Geko Server", 'l');
        FileMenu.add(FileLogonMI);

 		FileLocalLogonMI = new GMenuItem(this, "Run local", "locallogon", "Logon to personal server", 'r');
		FileMenu.add(FileLocalLogonMI);
  
 		FileLogoffMI = new GMenuItem(this, "Logoff", "logoff", "Logoff from Geko Server", 'o');
		FileMenu.add(FileLogoffMI);
		
 		FileLogMI = new GMenuItem(this, "Enable Logging", "createlog", "Log system messages", 'e');
		FileMenu.add(FileLogMI);
		
		FileBatchMI = new GMenuItem(this, "Batch", "batch", "Batch upload Gekos from a directory", 'b');
// 		FileMenu.add(FileBatchMI);
 
 		FileExitMI = new GMenuItem(this, "Exit", "exit", "Exit Gekko Browsing System", 'x');
        FileMenu.add(FileExitMI);
        // ---------------------------------------------------

		ObjectMenu = new javax.swing.JMenu();
		ObjectMenu.setText("Object");
		ObjectMenu.setActionCommand("Object");
		ObjectMenu.setAlignmentY(0.5F);
		ObjectMenu.setAlignmentX(0.5F);
		ObjectMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        ObjectMenu.setMnemonic('o');
		MainFrameMenu.add(ObjectMenu);
		
		ObjectOpenMI = new GMenuItem(this, "OpenObject", "open", "Load a local frame into a browser", 'o');
		ObjectMenu.add(ObjectOpenMI);

		ObjectNewMI = new JMenu("NewObject");
        ObjectNewMI.setMnemonic('n');
		ObjectMenu.add(ObjectNewMI);
		
		ObjectQueryMI = new JMenu("QueryObject");
        ObjectNewMI.setMnemonic('q');		
		ObjectMenu.add(ObjectQueryMI);
				

        // ---------------------------------------------------
		ArchiveMenu = new javax.swing.JMenu();
		ArchiveMenu.setText("Archive");
		ArchiveMenu.setActionCommand("Archive");
		ArchiveMenu.setAlignmentY(0.5F);
		ArchiveMenu.setAlignmentX(0.5F);
		ArchiveMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        ArchiveMenu.setMnemonic('a');
		MainFrameMenu.add(ArchiveMenu);

		ArchiveOpenMI = new GMenuItem(this, "Open", "archiveopen", "Open a new Archive", 'o');
		ArchiveMenu.add(ArchiveOpenMI);

		ArchiveCloseMI = new GMenuItem(this, "Close", "archiveclose", "Close current archive", 'c');
		ArchiveMenu.add(ArchiveCloseMI);

		ArchiveCreateMI = new GMenuItem(this, "Create", "archivecreate", "Create a new archive", 'r');
		ArchiveMenu.add(ArchiveCreateMI);

		ArchiveGroupsMI = new GMenuItem(this, "Groups", "archivegroups", "Get groups in current archive", 'g');
		ArchiveMenu.add(ArchiveGroupsMI);

		ArchiveConsultMI = new GMenuItem(this, "Consult", "archiveconsult", "Start consultation from current archive", 's');
		ArchiveMenu.add(ArchiveConsultMI);

        // ---------------------------------------------------
		
 		HelpMenu = new javax.swing.JMenu();
		HelpMenu.setText("Help");
		HelpMenu.setActionCommand("Help");
		HelpMenu.setAlignmentY(0.5F);
		HelpMenu.setAlignmentX(0.5F);
		HelpMenu.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);		
        HelpMenu.setMnemonic('h');		
		MainFrameMenu.add(HelpMenu);

        HelpAboutMI = new GMenuItem(this, "About", "helpabout", "Product Info", 'a');
        HelpMenu.add(HelpAboutMI);
        
        HelpContentsMI = new GMenuItem(this, "Contents", "helpcontents", "Contents table for help", 'c');
        HelpMenu.add(HelpContentsMI);
        
        // ---------------------------------------------------

		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);

		
		// Dynamic
		ArchiveOpenMI.setEnabled(false);		
		ArchiveCloseMI.setEnabled(false);
		ArchiveGroupsMI.setEnabled(false);
		ArchiveCreateMI.setEnabled(false);
		ArchiveConsultMI.setEnabled(false);  //dcm		
		FileLogoffMI.setEnabled(false);
		FileBatchMI.setEnabled(false);
        ObjectNewMI.setEnabled(false);        
        ObjectQueryMI.setEnabled(false);		

		JPanel contentPane = (JPanel) getContentPane();
		
		m_desk = new JDesktopPane();
	    m_desk.setDesktopManager(new MDIDesktopManager());   // Use an MDI that works !!
		m_desk.putClientProperty("JDesktopPane.dragMode", "outline"); // Outline drag
		m_desk.setBackground(contentPane.getBackground());
		
		m_schema_source = null;
		contentPane.add("Center", m_desk);
		getRootPane().setJMenuBar(MainFrameMenu);
		init();		
		
		m_property_change = new PropertyChangeSupport(this);
		
		// -- Debug support    if "-debug" param
		for (int i = 0; i < args.length; ++i)
		    if ("-debug".equals(args[i]))
		        m_debug = true;
		        
		println("Debugging on");  // Only appears if debugging
		doLog();
		ErrorMessage.MF = this;
		// ------
	}


    private void init() {

    }
    
	static public void main(String args[])
	{
		(new MainFrame(args)).setVisible(true);
	}

    
    /** 
    * Creates new Gekko entirely from schema and puts it in a browser
    */
    public void addNewGekko() {
        if (null == m_schema_source) {
            ErrorMessage.message(this, ErrorMessage.EM_NO_SCHEMA);
        } else {
            KnowledgeFrame kf;
            try {
                GekkoBrowser gb;
                Schema schema;
                
                schema = new Schema(m_schema_source.getSchema("geko"), m_schema_source);
                kf = schema.newFrame(schema.USE_DEFAULTS);
                gb = new GekkoBrowser();
                gb.init(kf, "", this);
                register(gb);
            } catch (Exception e) {
                MainFrame.println("MainFrame:addNewGekko(<null>): " + e);
            }
        }
        
    }
    
    /** 
    * Creates and adds new Gekko browser containing gekko in file.
    * @File -- the file containing the Gekko
    */
    public void addNewGekko(File file) {
        Browser gb; 
        KnowledgeFrame lg = null;
        String fpath;
        
        fpath = file.getAbsolutePath();
        try {
            lg = new GEKOStreamView(GEKOStreamView.IN, fpath).input();
        } catch (Exception e) {
            // Old format failed - try XML
            try {
                lg = KnowledgeFrame.readXML(new File(fpath));
            } catch (Exception e2) {
                MainFrame.println("Exception:GekkoBrowser(file):" + e.toString());
                return;
            }
        }        
        // Now determine if it is a real gekko or just a frame
        //  assume that this is true if the top level frames are there ..
        if (    lg.slot_exists("Source Frame") &&
                lg.slot_exists("Technical Frame") &&
                lg.slot_exists("Knowledge Frame")
           ) {          
                gb = new GekkoBrowser();
           } else {
                gb = new KnowledgeFrameBrowser();
           } 
        gb.init(lg, fpath, this);  
        register(gb);
    }
    
    /**
    * Create a new browser for the frame from group.
    */
    public Browser addNewBrowser(KnowledgeFrame lg, String group) {
        Browser b = null;
        String browserclass = null;
        
        if ("geko".equals(group)) 
            browserclass = "amzi.ka.gg.GekkoBrowser";            
        else                
            browserclass = "amzi.ka.gg.KnowledgeFrameBrowser";            
                
        try {
            b = (Browser) Class.forName(browserclass).newInstance();
            b.init(lg, "", this);
            register(b);
        } catch (Exception e) {
            MainFrame.println("MainFrame:addNewBrowser(): " + e);
        }
        return b;
    }
    
    // Add the internal frame to the desktop so it can play
    public  void register(JInternalFrame b) {
        Dimension size;
        
        size = getSize();
        if (size.height < m_browser_x_offset + 50 || size.width < m_browser_y_offset + 50) {
            m_browser_x_offset = 0;
            m_browser_y_offset = 0;
            b.setLocation(0, 0);
        } else {
            b.setLocation(m_browser_x_offset, m_browser_y_offset);
        }
        m_browser_x_offset += 20;
        m_browser_y_offset += 20;                        
        m_desk.add(b);

        try {
            b.setSelected(true);
        } catch (Exception e) {
        }
        m_desk.getDesktopManager().activateFrame(b);        
    }

    // Remove frame from desktop -- trivial for now
    public void deregister(JInternalFrame f) {
        if (f == (JInternalFrame) m_log)
            m_log = null;          
        m_desk.getDesktopManager().closeFrame(f);              
    }

    public PropertyChangeSupport getPropertyChange() {
        return m_property_change;
    }
    
    public Browser addNewBrowser(String group) {
        SchemaSource schema_source = getSchemaSource();
        Schema schema;

        try {
            Browser b;
            schema = new Schema(schema_source.getSchema(group), schema_source);
            b = addNewBrowser(schema.newFrame(schema.USE_DEFAULTS), group);
            b.setTitle("New " + group);
            return b;
        } catch (Exception e2) {
            MainFrame.println("MainFrame:addNewBrowsedr(String) " + e2);
            return null;
        }        
    }
        
    
    /** A schema source returns schema info on demand
    * transparently either from the archive or
    * from a local file.
    */
    public void setSchemaSource(SchemaSource s) {
        m_schema_source = s;
    }
    
    public SchemaSource getSchemaSource() {
        return m_schema_source;
    }
    
    /**
    * We have an archive -- fire up archive buttons
    */
    public void openedArchive(Session session, String name) {
    	ArchiveOpenMI.setEnabled(true);
	   	ArchiveCloseMI.setEnabled(true);
	    ArchiveGroupsMI.setEnabled(true);
	    ArchiveCreateMI.setEnabled(true);
	    ArchiveConsultMI.setEnabled(true);  //dcm	    
        ObjectNewMI.setEnabled(true); 
        ObjectQueryMI.setEnabled(true);
        FileBatchMI.setEnabled(true);
        setTitle(m_title + ":" + name);    			    
	    m_session = session;
	    // Add groups to NewObject and QueryObject menus
	    try {
	        if (ObjectNewMI.getItemCount() > 0) // bug in removeAll for menus ??
	        {
	            ObjectNewMI.removeAll();
	            ObjectQueryMI.removeAll();
	        }
	        Vector groups = m_session.getLib().get_groups();
	        Enumeration en = groups.elements();
	        while (en.hasMoreElements()) {
	            String oname =  en.nextElement().toString();
	            ObjectNewMI.add(new GMenuItem(this, oname, "-"+oname, "Make new object", (char) 0));
	            ObjectQueryMI.add(new GMenuItem(this, oname, "+"+oname, "Search for object", (char) 0));       
	        }
	    } catch (Exception ex) {
	        MainFrame.println("Ouch: " + ex);
	    }
    }
    
    /** 
    * Closed currently open archive -- menus accordingly
    */
    public void closedArchive(Session session) {
	   	ArchiveCloseMI.setEnabled(false);
	    ArchiveGroupsMI.setEnabled(false);	
	    ArchiveConsultMI.setEnabled(false);  //dcm		    
        ObjectNewMI.setEnabled(false);      
        ObjectQueryMI.setEnabled(false);              
        FileBatchMI.setEnabled(false);
        setTitle(m_title);    			    
    }
    
    public void openedSession(Session session) {
        ArchiveCreateMI.setEnabled(true);
        ArchiveOpenMI.setEnabled(true);
    }
    
    public Session getSession() {
        return m_session;
    }

    /**
    * cleanup the gekko browser system before exiting
    */
    public void shutdown() {
    }
    
	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == MainFrame.this)
				MainFrame_WindowClosing(event);
		}
	}

	void MainFrame_WindowClosing(java.awt.event.WindowEvent event)
	{
		setVisible(false); // hide the Frame
		dispose();	     // free the system resources
		System.exit(0);    // close the application
	}
	

    // Notify listeners of change to group
    public void notifyGroupChange(String groupname) {
        m_property_change.firePropertyChange("groupchange", null, groupname);
    }
    
    
    public void propertyChange(PropertyChangeEvent evt) {
        String propname = evt.getPropertyName();
        
        if (propname.equals("queryresults")) {
            /* A query was performed or the query was abandoned
            * If we have a query put up a non-modal dialog which
            * fires off browsers given its selection .. eventually
            * this should be replaced by a much more elegant mechanism
            */
            QueryResults results = (QueryResults) evt.getNewValue();
            if (null != results) {
               final String group = results.getGroup();
               ArchivalElementPicker aep = new ArchivalElementPicker(m_session.getLib(), this);
               JPanel panel = new JPanel(new BorderLayout());
               final GroupsEditor ge = new GroupsEditor( m_session.getLib(), this);
               ge.setGroup(group);
               try {
                    ge.populate(results.getResults());
               } catch (Exception e) {};
               JScrollPane p = new JScrollPane(ge.getWidget());
               p.setPreferredSize(new Dimension(180, 120));
               panel.add(p);
               GGDialog option = new GGDialog(GGDialog.OK_CANCEL_DIALOG, 
                                  "Query results: " + group, 
                                  "Select a frame", 
                                  p, ge.getWidget(), false);
               final BrowserContainer bc = this;
               option.getPropertyChange().addPropertyChangeListener(
                    new PropertyChangeListener() {
                        public void propertyChange(PropertyChangeEvent evt) {
                            String evpropname = evt.getPropertyName();
                            if (evpropname.equals("select")) {
                                bc.addNewBrowser(ge.getSelectedFrame(), group);
                            }
                        }
                    });
            }
        } else if (propname.equals("frameput")) {
            // A browser uploaded a frame somewhere ... refire the event
            // to notify any group browsers
            notifyGroupChange(((KnowledgeFrame)evt.getNewValue()).group_name());
        }
    }
    
    
    // So we can control the cursor in browsers --
    public Cursor getCursor() {
        return super.getCursor();
    }
    
    public void setCursor(Cursor c) {
        super.setCursor(c);
    }

    /**
    * Start a consultation session with the archive.
    */
    public void doConsult()
    {
      try
      {
         if (m_session.getLib() != null)
         {
            ggConsult gc = new ggConsult(this, m_session.getLib());
            register(gc);
         }
      }
      catch (Exception ex)
      {
         log_writeln("Exception: " + ex.getMessage());
         MainFrame.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
      }
    }

    /******************************************************
    *  Logging code    
    */
    public void doLog()
    {
        if (null != m_log)
            return;
        try
        {
            m_log = new ggLog(this);
        }
        catch (Exception ex)
        {
            MainFrame.println("Exception creating log: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void log_write(String s)
    {
      if (m_log != null)
         m_log.write(s);
    }

    public void log_writeln(String s)
    {
      if (m_log != null)
         m_log.writeln(s);
    }

    public void show_exception(Exception ex)
    {
      MainFrame.println("Exception: " + ex.getMessage());
      ex.printStackTrace();

      log_writeln("---Exception---");
      log_writeln(ex.getMessage());
      log_writeln("---");

      JOptionPane.showMessageDialog(this,
            "Exception: " + ex.getMessage(),
            "Exception",
            JOptionPane.ERROR_MESSAGE);
    }
    
    // For development debugging
    public static void println(String msg) {
        if (m_debug)
            System.out.println(msg);
    }

    /**************************************************************
    * Help support
    */
    
    public void doHelpAbout() {
        JTextArea msg = new JTextArea(
            " AMKES GEKO Client.  Version " + m_version + "\n\n" +
            "    Release date " + m_release_date + "\n\n" + 
            " This work was supported by the U.S. Army Medical\n" +
            " Research and Materiel Command under Contract No.\n" +
            "    DAMD17-98-D-0022 and DAMD17-93-C-3141\n\n" +
            "  Developed by:\n" +
            "    Amzi! Inc [www.amzi.com] (Dennis & Mary)\n" +
            "    Littleford.Net [www.littleford.net] (Alan)\n\n" +
            "  Contributors:\n" +
            "    Fred Hegge, Frank Sodetz and Sabina Robinson\n\n" +
            "  Program Sponsor:\n" +
            "    Fred Hegge\n");
            
            msg.setEnabled(false);
            msg.setBackground(Color.lightGray);
            msg.setDisabledTextColor(Color.black);
        JOptionPane.showMessageDialog(null, msg, "About", JOptionPane.INFORMATION_MESSAGE,
                         new ImageIcon("\\ka\\images\\gg.jpg"));
    }
    
    public void doHelpContents() {
        new Help( "file://localhost/ka/help/contentshelp.html");
    }
    /**************************************************************
    * Catch events that name the MainFrame as their action listener
    */
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        Cursor old_cursor = getCursor();
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        
        if (cmd.equals("exit")) {
            shutdown();
            System.exit(0);
        } else if (cmd.equals("logon")) {
            m_session = new Session(this, this, false);
            if (m_session.connected()) {
                FileLogonMI.setEnabled(false);
                FileLocalLogonMI.setEnabled(false);
                FileLogoffMI.setEnabled(true);
                if (null == m_session.getArchiveName())
                    m_session.listArchives();
            }
        } else if (cmd.equals("locallogon")) {
            m_session = new Session(this, this, true);
            if (m_session.connected()) {
                FileLogonMI.setEnabled(false);
                FileLocalLogonMI.setEnabled(false);                
                FileLogoffMI.setEnabled(true);
                m_session.listArchives();                   
            }            
        } else if (cmd.equals("logoff")) {
            m_session.logoff();
            FileLogonMI.setEnabled(true);
            FileLocalLogonMI.setEnabled(true);            
            FileLogoffMI.setEnabled(false);
        } else if (cmd.equals("createlog")) {
            doLog();
        } else if (cmd.equals("batch")) {
            m_session.doBatch();
        } else if (cmd.equals("open")) {
            JFileChooser fc = new JFileChooser(".");
            if (0 == fc.showOpenDialog(this)) {
                addNewGekko(fc.getSelectedFile());
            }
        } else if (cmd.equals("new")) {
            addNewGekko();
        } else if (cmd.equals("archiveclose")) {
            m_session.closeArchive();
        } else if (cmd.equals("archiveopen")) {
            m_session.listArchives();            
        } else if (cmd.equals("archivegroups")) {
            m_session.doGroups();
        } else if (cmd.equals("archivecreate")) {
            String resp = JOptionPane.showInputDialog("Enter new archive name");
            if (null != resp) {
                m_session.createArchive(resp);                
                m_session.openArchive(resp);
            }
        //dcm
        } else if (cmd.equals("archiveconsult")) {
            doConsult();
        } else if (cmd.startsWith("-")) {
            addNewBrowser(cmd.substring(1));                       
        } else if (cmd.startsWith("+")) {
            Browser qb = new QBEBrowser(m_session.getLib(), this, cmd.substring(1));    
            register(qb);    
        } else if (cmd.equals("helpabout")) {
            doHelpAbout();
        } else if (cmd.equals("helpcontents")) {
            doHelpContents();
        } else
            MainFrame.println("Unknown action in MainFrame: " + cmd);        
            
        setCursor(old_cursor);            
    }	
    
}
