// GEKOLibraryRI_Server.java

package amzi.ka.net.rmi.server;

import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.db.*;
import amzi.frames.*;
import amzi.kb.*;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.io.*;
import COM.odi.*;
import COM.odi.util.*;

public class GEKOLibraryRI_Server
   extends UnicastRemoteObject
   implements GEKOLibraryRI
{
   GEKOLibraryI gekos;
   GEKOLogonRI_Server ls;
   //KnowledgeFrame me;
   String user_id;

   public GEKOLibraryRI_Server(GEKOLibraryI db, GEKOLogonRI_Server ls, String user_id)
      throws RemoteException, KAFrameException
   {
      super();
//System.out.println("GEKOLibraryRI_Server:constructor " + Thread.currentThread().toString());
      gekos = db;
      this.user_id = user_id;
      this.ls = ls;
   }


   public synchronized Thread initial_thread()
      throws RemoteException, FrameException
   {
//System.out.println("GEKOLibraryRI_Server:initial_thread " + Thread.currentThread().toString());
      return gekos.initial_thread();
   }

   /**
   * Initialize a library server.
   */
   public synchronized void initialize()
      throws RemoteException, FrameException
   {
      ls.report(user_id, " initialize ");
      gekos.initialize();
   }

   /**
   * Initialize a library server.
   */
   public synchronized void initialize(Thread th)
      throws RemoteException, FrameException
   {
//System.out.println("GEKOLibraryRI_Server:initialize(th) " + Thread.currentThread().toString());
      ls.report(user_id, " initialize thread ");
      gekos.initialize(th);
   }

   /**
   * Creates a new Knowledge Library.
   */
   public synchronized void create(String db_name, String schema_file_name, KnowledgeFrame archivist)
      throws RemoteException, FrameException
   {
     ls.report(user_id, " create " + db_name);
     gekos.create(db_name, schema_file_name, archivist);
   }

   public synchronized void create(String db_name)
      throws RemoteException, FrameException
   {
     gekos.create(db_name, null, null);
   }

   public synchronized void create(String db_name, String schema_file_name)
      throws RemoteException, FrameException
   {
     gekos.create(db_name, schema_file_name, null);
   }

   public synchronized void create(String db_name, KnowledgeFrame archivist)
      throws RemoteException, FrameException
   {
     gekos.create(db_name, null, archivist);
   }

   /**
   * Open an existing Knowledge Library.
   */
   public synchronized void open(String db_name)
      throws RemoteException, FrameException
   {
//System.out.println("GEKOLibraryRI_Server:open " + Thread.currentThread().toString());
     ls.report(user_id, " open " + db_name);
     gekos.open(db_name);
   }

   /**
   * Close an open Knowledge Library.
   */
   public synchronized void close()
      throws RemoteException, FrameException
   {
     ls.report(user_id, " close ");
     gekos.close();
   }

   /**
   * Check to see if a geko exists for the given title.
   * @param title The title string.
   * @param geko The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public synchronized int check_geko(String title, KnowledgeFrame geko)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " check_geko " + title);
      return gekos.check_geko(title, geko);
   }

   /**
   * Check to see if an author exists with the given name.
   * @param name The name string.
   * @param author The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public synchronized int check_author(String name, KnowledgeFrame author)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " check_author " + name);
      return gekos.check_author(name, author);
   }


   /**
   * Check to see if a variable exists with the given name.
   * @param name The name string.
   * @param variable The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public synchronized int check_variable(String name, KnowledgeFrame variable)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " check_variable " + name);
      return gekos.check_variable(name, variable);
   }


   /**
   * Check to see if a citation exists with the given body.
   * @param body The body string.
   * @param citation The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public synchronized int check_citation(String body, KnowledgeFrame citation)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " check_citation " + body);
      return gekos.check_citation(body, citation);
   }


   /**
   * Check to see if a keyword exists with the given body.
   * @param item The keyword string.
   * @param keyword The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public synchronized int check_keyword(String item, KnowledgeFrame keyword)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " check_keyword " + item);
      return gekos.check_keyword(item, keyword);
   }

   /**
   * Get all the variables from the archive formatted
   * for inferencing.
   */
   public synchronized Variable[] get_variables()
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_variables");
      return gekos.get_variables();
   }

   /**
   * Get all the links from the archive formatted
   * for inferencing.
   */
   public synchronized Link[] get_links()
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_links");
      return gekos.get_links();
   }

   /**
   * Get all the rules from the gekos in the archive
   * formatted for inferencing.
   */
   public synchronized Rule[] get_rules()
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_rules");
      return gekos.get_rules();
   }

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public synchronized void add_group(String group)
      throws RemoteException, FrameException
   {
     ls.report(user_id, " add_group " + group);
     gekos.add_group(group);
   }


   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public synchronized Vector get_groups()
      throws RemoteException, FrameException
   {
     ls.report(user_id, " get_groups ");
     return gekos.get_groups();
   }


   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public synchronized String put_frame(KnowledgeFrame f)
      throws RemoteException, FrameException
   {
     ls.report(user_id, " put_frame " + f.summary());
     return gekos.put_frame(f);
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public synchronized void remove_frame(KnowledgeFrame f)
      throws RemoteException, FrameException
   {
     ls.report(user_id, " remove_frame " + f.summary());
     gekos.remove_frame(f);
   }


   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public synchronized KnowledgeFrame get_frame(String group, String key, int version)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_frame " + group + " " + key + "version " + version);
      return gekos.get_frame(group, key, version);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public synchronized KnowledgeFrame get_frame(String group, String key)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_frame " + group + " " + key);
      return gekos.get_frame(group, key);
   }


   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   /*
   public synchronized Vector get_key_notes(String group)
      throws RemoteException, FrameException
   {
      ls.report(user_id, " get_key_notes " + group);
      return gekos.get_key_notes(group);
   }
   */
   public synchronized Vector get_key_notes(String group)
      throws RemoteException, FrameException
   {
      Vector v = null;
      try
      {
         ls.report(user_id, " get_key_notes " + group);
         v = gekos.get_key_notes(group);
         //System.out.println("vector of key notes retrieved OK");
         //System.out.println(v.toString());
      }
      catch (Exception ex)
      {
         System.out.println("*****");
         System.out.println(ex.getMessage());
         ex.printStackTrace();
      }
      return v;
   }


   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public synchronized Vector query(QueryFrame qf)
      throws RemoteException, FrameException
   {
     ls.report(user_id, " query ");
     return gekos.query(qf);
   }
}