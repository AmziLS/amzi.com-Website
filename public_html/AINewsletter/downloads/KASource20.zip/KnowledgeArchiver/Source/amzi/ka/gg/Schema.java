package amzi.ka.gg;

import amzi.frames.*;
import java.util.Vector;
import java.io.IOException;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;

/** A schema object */
public class Schema {
    
    public static final boolean NO_DEFAULTS = false;  // do not use defaults when making new frame
    public static final boolean USE_DEFAULTS = true;
    
    KnowledgeFrame m_schema;
    KnowledgeFrame m_proto_frame;
    SchemaSource m_schema_source;
    
    public Schema (KnowledgeFrame schema, SchemaSource source) {
        m_schema = schema;
        m_schema_source = source;
        m_proto_frame = null;
    }
    
    /**
    * Make a new (empty) frame based on the schema
    */
    public KnowledgeFrame newFrame(boolean usedefaults) throws Exception {
        if (null != m_proto_frame)
            return m_proto_frame;
        else {
            m_proto_frame = makeFrame(m_schema, usedefaults);
            return m_proto_frame;
        }            
    }
    
    private KnowledgeFrame makeFrame(KnowledgeFrame schema, boolean usedefaults) throws Exception  {
        String group = (String)schema.get("group");
        KnowledgeFrame new_frame = new KnowledgeFrame(group);
        KnowledgeList formats = (KnowledgeList)schema.get("formats");
        KnowledgeFrame format;
        String slot_name;
        String slot_type;
        KnowledgeFrame sub_frame_schema;
        int i;
        String nulls = "";
        for (i = 0; i < formats.length(); i++)
        {
            format = (KnowledgeFrame)formats.slot_at(i).value();
            slot_type = (String)format.get("type");
            slot_name = (String)format.get("slot");
            if (slot_type.equals("local_frame"))
            {
                sub_frame_schema = (KnowledgeFrame)format.get("schema");
                new_frame.set( slot_name, makeFrame(sub_frame_schema, usedefaults) );
            }
            else if (slot_type.equals("global_frame"))
            {
                sub_frame_schema = m_schema_source.getSchema(format.get("schema").toString());
                new_frame.set( slot_name, makeFrame(sub_frame_schema, usedefaults) );
            }
            else if (slot_type.equals("global_frame_list"))
            {
                sub_frame_schema = m_schema_source.getSchema(format.get("schema").toString());
                new_frame.set( slot_name, makeFrameList(slot_name,sub_frame_schema) );
            }
            else if (slot_type.equals("local_frame_list"))            
            {
                sub_frame_schema = (KnowledgeFrame)format.get("schema");
                new_frame.set( slot_name, makeFrameList(slot_name,sub_frame_schema) );
            }
            else
            {
                if (format.slot_exists("default") && usedefaults)                
                    new_frame.set(slot_name, format.get("default")); 
                else
                    new_frame.set(slot_name, nulls);                
            }
        }
        return new_frame;       
    }
   
   

   private KnowledgeList makeFrameList(String slot_name, KnowledgeFrame schema)
      throws FrameException, IOException, Exception
   {
      KnowledgeList kl = new KnowledgeList();
      
      /* To prevent accidental creation of new Gekos
      * with loads of unfilled-in nodes we don't
      * produce prototype list elements for now
      */
      //f = makeFrame(schema);
      //kl.add_slot(new KnowledgeSlot("item", f));
      return kl;
   }  
}