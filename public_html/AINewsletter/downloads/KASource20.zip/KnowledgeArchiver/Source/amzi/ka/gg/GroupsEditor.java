package amzi.ka.gg;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

import java.util.Vector;

import amzi.frames.*;
import amzi.ka.net.*;

public class GroupsEditor extends BrowserEditor 
implements ListSelectionListener, ActionListener {
    private JList  m_list;
    private JButton m_Bget, m_Bdelete, m_Bnew;
    private String m_selected_group;
    private GEKOClientI m_lib;    
    private Vector m_keynote_pairs;
    private BrowserContainer m_browser_container;
    private Browser m_browser;
    private boolean m_within_browser;
    private JPanel m_bpanel;
    
    public JComponent getWidget() {
        return m_list;
    }
    
    /**
    * We are embedded elsewhere - not in a browser. In this case
    * the query button goes in the enclosing dialog    
    */
    public GroupsEditor(GEKOClientI lib, BrowserContainer bc) {
        super();
        init(lib, bc);         
        m_within_browser = false;
        m_browser = null;
    }
    
    /** 
    * We are created explicitly within the Groups browser -- so we
    * need the button panel
    */
    public GroupsEditor(Browser browser, GEKOClientI lib, BrowserContainer bc) {
        super();
        init(lib, bc);        
        
        m_browser = browser;        
        m_bpanel = new JPanel();

        m_Bget = new JButton("Get");
        m_Bget.setEnabled(false);
        m_Bget.addActionListener(this);
        m_Bget.setActionCommand("get");
        m_Bget.setToolTipText("Get selected frame from archive");
        
        m_Bdelete = new JButton("Delete");
        m_Bdelete.setEnabled(true);
        m_Bdelete.setToolTipText("Delete selected frame from archive");
        m_Bdelete.setActionCommand("delete");
        m_Bdelete.addActionListener(this);
        
        m_Bnew = new JButton("New");
        m_Bnew.setActionCommand("new");
        m_Bnew.addActionListener(this);
        m_Bnew.setToolTipText("Create new frame in group");
        m_Bnew.setEnabled(false);
         
        m_bpanel.add(m_Bget);
        m_bpanel.add(m_Bdelete);
        m_bpanel.add(m_Bnew);
        // Add it to the right panel, _not_ "this" which the
        // default browser action has already put in a scroller in
        // right panel's "Center"
        browser.getRightPanel().add("South", m_bpanel);       
        m_within_browser = true;
        // Double clicks work same as "Get" button
        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                 if (e.getClickCount() == 2) {
                     actionPerformed(new ActionEvent(this, 0, "get"));
                }
            }
        };
        m_list.addMouseListener(mouseListener);        
        
    }

    private void init(GEKOClientI lib, BrowserContainer bc) {
        m_lib = lib;
        m_browser_container = bc;
        m_list = new JList(new DefaultListModel());
        m_list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        m_list.addListSelectionListener(this);
        add(m_list);
    }
    
    public void setGroup(String group) {
        m_selected_group = group;
    }
    
    /** value is just the interface library. The second level path tells us which
    * group we have choosen
    */
    public void setValue(Object path) throws Exception {        
        m_selected_group = path.toString(); 
        populate();
    }
    
    public void populate(Vector kp) {  
        DefaultListModel lm = (DefaultListModel) m_list.getModel();
        lm.clear();
        m_keynote_pairs = kp;
        for (int i = 0; i < m_keynote_pairs.size(); ++i)
            lm.addElement(((KeyNotePair)m_keynote_pairs.elementAt(i)).summary());        
            
    }
    
    public void populate() throws Exception  {
        populate(m_lib.get_key_notes(m_selected_group));
        if (m_Bnew != null)
            m_Bnew.setEnabled(true);                               
    }
    
    /** 
    * We need to clean up the button panel
    */
    public boolean looseFocus() throws Exception {
        m_browser.getRightPanel().remove(m_bpanel);
        return true;
    }    
    
    
    // Handle list selection -- just en/disable get & new buttons for now
    public void valueChanged( ListSelectionEvent e) {
        if (m_within_browser) {
            if (null != m_list.getSelectedValue()) {
                m_Bget.setEnabled(true);
            } else {
                m_Bget.setEnabled(false);
            }
        }
    }
    
    /**
    * Returns the selected frame
    */
    public KnowledgeFrame getSelectedFrame() {
        try {
            return m_lib.get_frame(m_selected_group, 
                    ((KeyNotePair)m_keynote_pairs.elementAt(m_list.getSelectedIndex())).get_key());
        } catch (Exception e) {
            return null;
        }        
    }
    
    public String getSelectedName() {
        return ((KeyNotePair)m_keynote_pairs.elementAt(m_list.getSelectedIndex())).summary();
    }
    
    // Handle button presses
    public void actionPerformed(ActionEvent e) {
        Cursor old_curse = m_browser_container.getCursor();
        m_browser_container.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        
        if (e.getActionCommand().equals("get")) {
            m_browser_container.addNewBrowser(getSelectedFrame(), m_selected_group);
                    
        } else if (e.getActionCommand().equals("new")) {
            m_browser_container.addNewBrowser(m_selected_group);            
        } else if (e.getActionCommand().equals("delete")) {
           try {
                KnowledgeFrame kf = getSelectedFrame();
                m_lib.remove_frame(kf);
                m_browser_container.notifyGroupChange(kf.group_name());
           } catch (FrameException ex) {}            
            // ErrorMessage.show("Delete not implemented yet");
        }
        m_browser_container.setCursor(old_curse);
    }    
}