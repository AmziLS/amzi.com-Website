package amzi.ka.gg;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

/** Migrate Browser Event Functionality from the Frame to this pane. This
* means we can embed just this pane in a dialog box (e.g. in ArchivalQueryPicker).
* Eventually I think that this _should_ be the browser - and you can
* add to an internal frame if you want ... later, gator
*/

public class BrowserMainPane extends JPanel implements TreeSelectionListener {
    private Browser m_b;
    
    public BrowserMainPane(Browser b) {
        m_b = b;
    }
    
    public void valueChanged(TreeSelectionEvent e) {
        m_b.valueChanged(e);
    }
}