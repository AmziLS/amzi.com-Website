package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.beans.*;
import java.text.*;
import java.util.Date;

import amzi.ka.*;
import amzi.frames.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;

public class QBEBrowser extends KnowledgeFrameBrowser implements ActionListener {
    KnowledgeFrame m_frame = null;
    private GEKOClientI m_lib; // The client library for this session
    private String m_group_name;
    private JButton m_bQuery;
    JTextField m_qdate, m_qversion;
    // Am I embdedded in a dialog ?  
    
    public QBEBrowser(GEKOClientI lib, BrowserContainer bc, String groupname, 
                      boolean embedded) {
        super(embedded);
        SchemaSource schema_source = bc.getSchemaSource();
        Schema schema;
    
        m_lib = lib;        
        m_group_name = groupname;
        m_browser_container = bc;
        m_embedded = embedded;
        
        try {
            schema = new Schema(schema_source.getSchema(groupname), schema_source);
            init(schema.newFrame(Schema.NO_DEFAULTS), "", bc);
        } catch (Exception e) {
            MainFrame.println("QBEBrowser:'new frame': " + e);
        }
    }
    
    public QBEBrowser(GEKOClientI lib, BrowserContainer bc, String groupname) {
        SchemaSource schema_source = bc.getSchemaSource();
        Schema schema;
    
        m_lib = lib;        
        m_group_name = groupname;
        m_browser_container = bc;
        
        try {
            schema = new Schema(schema_source.getSchema(groupname), schema_source);
            init(schema.newFrame(Schema.NO_DEFAULTS), "", bc);
        } catch (Exception e) {
            MainFrame.println("QBEBrowser:'new frame': " + e);
        }
    }

    public void init(KnowledgeFrame f, String filename, BrowserContainer bc) {
        super.init(f, filename, bc);    
        if (! m_embedded) {
            JPanel bpanel;
            bpanel = new JPanel(new FlowLayout()); 
            m_bQuery = new JButton("Submit Query");
            m_bQuery.addActionListener(this);
            m_bQuery.setActionCommand("query");
            m_bQuery.setToolTipText("Submit a query to select from the group");
            bpanel.add(m_bQuery);
            m_left_panel.add("South", bpanel);
            setTitle("Query for frames in group: " + m_group_name);               
        }
        // Add the date/version query panel to the right panel
        JPanel qpanel;
        JLabel ldate, lversion;
        qpanel = new JPanel(new GridLayout(2, 2));
        m_qdate = new JTextField(20);
        m_qversion = new JTextField(20);
        ldate = new JLabel("Date constraint:");
        lversion = new JLabel("Version constraint:");
        qpanel.add(ldate);
        qpanel.add(m_qdate);
        qpanel.add(lversion);
        qpanel.add(m_qversion);
        m_right_panel.add("South", qpanel);          
        m_fileUploadItem.setEnabled(false);
        m_fileSaveItem.setEnabled(false);
        m_fileSaveAsItem.setEnabled(false);
    }
    
    public Object getBrowsedObjectForDisplay() {
        Object obj = null;
        try {
            obj = getBrowsedObject();
            if (null == obj) {
                setInsertableNode(false);
                setEditableNode(false);
                setDeleteableNode(false);
                m_current_editor.setEnabled(false);
                return "";
            } else if (obj instanceof KnowledgeSlot) {
                setInsertableNode(false);
                setEditableNode(false);
                setDeleteableNode(false);
                m_current_editor.setEnabled(true);
                return obj;                
            } else if (obj instanceof KnowledgeFrame) {
                setInsertableNode(false);
                setEditableNode(false);
                setDeleteableNode(false);                
                m_current_editor.setEnabled(false);
                return "";
            } else if (obj instanceof KnowledgeList) {
                setInsertableNode(false);
                setNewNode(true);
                setEditableNode(false);
                setDeleteableNode(false);                
                m_current_editor.setEnabled(false);
                return "";
            } else {
                m_current_editor.setEnabled(true);
                setInsertableNode(false);
                setEditableNode(false);
                return obj;
            }   
        } catch (Exception e) {
            MainFrame.println("QBEBrowser:getBrowsedObjectForDisplay():" + e + " :" + obj);
            return null;
        }
    }

    public BrowserEditor getBrowserEditor(Object node) {
        QBEEditor ed;
        
        ed = new QBEEditor();
        ed.setBrowser(this);        
        return ed;
    }    
    
    /**
    * Override the corresponding KnowledgeFrameBrowser functionality.
    * In this case we just want to drop a new element straight into the tree
    * so we can build a query in it ...
    */    
    public void insertSelectedElement()
    {
        Object val;
        KnowledgeFrame kf;
        String groupname = "";
        
        try {
            val = getBrowsedObject(); 
            if (val instanceof KnowledgeFrame) {
                kf = (KnowledgeFrame) val;
                groupname = kf.group_name();
            } else if (val instanceof KnowledgeList) {
                DefaultMutableTreeNode listnode;               
                listnode = (DefaultMutableTreeNode) m_tree.getSelectionPath().getLastPathComponent();
                groupname = ((GekkoTreeNode) listnode.getUserObject()).getTreeNodeSchema().getSchemaName();                
            }  
            SchemaSource schema_source = m_browser_container.getSchemaSource();
            Schema schema;
            try {
                schema = new Schema(schema_source.getSchema(groupname), schema_source);
            } catch (Exception e0) {
                throw e0;
            }            
            // Now make the new frame and slip it in the target
            updateTarget(schema.newFrame(Schema.NO_DEFAULTS), val);
        } catch (Exception e) {
            MainFrame.println("QBEBrowser:insertSelectedElement(): " + e);
        }        
    }
    
    /**
    * Generate and submit the query via property change
    * then hide our window
    */
    public void doQuery() {
        Vector results;
        QueryFrame qf;
        
        qf = generateQuery();
        try {
            results = m_lib.query(qf);
            setVisible(false);
            m_property_change.firePropertyChange("queryresults", null, 
                                                     new QueryResults(results, m_group_name));
        } catch (Exception e) {
            ErrorMessage.message(this, ErrorMessage.EM_QUERY_ERROR);
            MainFrame.println("QBEBrowser:doQuery() " + e.toString());
        }
    }
    
    /// This query stuff should really be a separate adapter class. For the
    /// moment we have some nasty architectural deficiencies (m_tfm showing through
    /// for example) which requires these be methods here ...
    /**
    * PathQuery contains info needed to generate the QueryFrame for one frame
    */
    class PathQuery {
        TreePath m_tp;
        String   m_query;
        
        public PathQuery(TreePath tp, String query) {
            m_tp = tp;
            m_query = query;
        }
        
        public TreePath getPath() {
            return m_tp;
        }
        
        public String getQuery() {
            return m_query;
        }
    }
    
    /**
    * Set the query frame to the query specified by the tree. The algorithm
    * (for the moment) is as follows:
    * Enumerate the tree - for each leaf node with non-empty contents (i.e. a query)
    *   Get the path back to the root.
    *   Generate a query for this path
    * Then AND the queries together   
    */
    public QueryFrame generateQuery() {
        Vector paths = new Vector();
        DefaultMutableTreeNode node;
        Enumeration enum;
        GekkoTreeNode gtn;
        Object val;
        String qstring;
        
        node = (DefaultMutableTreeNode) m_tree.getModel().getRoot();
        enum = node.depthFirstEnumeration();
        while (enum.hasMoreElements()) {
            node = (DefaultMutableTreeNode) enum.nextElement();
            if (node.isLeaf()) {
                gtn = (GekkoTreeNode)node.getUserObject();
                val = m_tfm.getMappedObject(gtn);
                if (val instanceof KnowledgeSlot) {
                    qstring = ((KnowledgeSlot)val).value().toString().trim();
                    if (qstring.length() > 0) {
                       paths.addElement(new PathQuery(new TreePath(node.getPath()), qstring));
                    }
                }                  
            }
        }
        return pathQuery(paths);
    }
    
    // Build an implicit "AND" by generating queries for all
    // slots specified in the paths. Then add date and version
    // constraints if any to the newly generated query
    private QueryFrame pathQuery(Vector paths) {
        Enumeration pathenum = paths.elements();
        TreePath path;
        QueryFrame currentqf = null;
        Vector qv = new Vector();
        QuerySlot qs;
        String s = null;
        
        while (pathenum.hasMoreElements()) {
            path = ((PathQuery)pathenum.nextElement()).getPath();
            currentqf = new QueryFrame(m_group_name);
            makeQuery(1, currentqf, path);
            qv.addElement(currentqf);
        }  
        
        currentqf = new QueryFrame(m_group_name);
        for (int i = 0; i < qv.size(); ++i) {
            qs = ((QueryFrame)qv.elementAt(i)).slot_at(0);
            currentqf.set(qs.name, qs.query_op);    
        }
        // Now see if we have a date or version constraint
        try {
            dateQuery(currentqf, s = m_qdate.getText().trim());
            versionQuery(currentqf, s = m_qversion.getText().trim());
        } catch (java.text.ParseException e) {
            ErrorMessage.message(this, ErrorMessage.EM_QUERY_FORM_ERROR, e + " : " + s);
        }
        return currentqf;
    }
    
    /** 
    * Parse the squery and produce the appropriate Query ..
    * For now all queries are assumed to be equality
    */
    private void makeQuery(int index, QueryFrame parentq, TreePath path) {
        QueryFrame q = null;
        Object val, parentval;
        DefaultMutableTreeNode dtn;
        
        dtn = (DefaultMutableTreeNode) path.getPathComponent(index);
        val = m_tfm.getMappedObject((GekkoTreeNode)dtn.getUserObject()); 
        
        if (val instanceof KnowledgeSlot) {
            KnowledgeSlot ks = (KnowledgeSlot)val;
            parentq.set(ks.name(), slotQuery((String)ks.value()));
        } else if (val instanceof KnowledgeFrame) {    
            ++index;
            q = new QueryFrame(((KnowledgeFrame)val).group_name());
            makeQuery(index, q, path);
            parentq.set(dtn.getUserObject().toString(), new QueryOp(QueryOp.MATCH_FRAME, q));
        } else if (val instanceof KnowledgeList) {  
            index += 2;  // skip the fake "item:x" label
            q = new QueryFrame(((GekkoTreeNode) dtn.getUserObject()).getTreeNodeSchema().getSchemaName());
            makeQuery(index, q, path);
            parentq.set(dtn.getUserObject().toString(), new QueryOp(QueryOp.CONTAINS_FRAME, q));
        } else {
            MainFrame.println("QBEBrowser: makeQuery() bad val class: " + val.getClass().toString());
        }
    }
    
    /** 
    * Converts the query string to approriate QueryOp(s). For now
    * a very simple syntax:
    *  "@prefix-op rest-of-string" 
    *  "string-not-starting-with '@'"
    *
    * prefix ops supported are
    *     equals  (same as no prefix op)
    *     contains
    * Eventually should get much fancier (e.g. prefix @or)
    */
    private QueryOp slotQuery(String squery) {    
        squery = squery.trim();
        if (! squery.startsWith("@")) {
            return new QueryOp(QueryOp.EQUALS, squery);
        } else {
            int start = squery.indexOf(" ");
            String rest = squery.substring(start).trim();
            String cmd = squery.substring(1, start).toLowerCase();

            if (cmd.equals("equals"))
                return new QueryOp(QueryOp.EQUALS, rest);
            else if (cmd.equals("contains"))
                return new QueryOp(QueryOp.CONTAINS_STRING, rest);
            else if (cmd.equals("gt")) 
                return new QueryOp(QueryOp.GREATER_THAN, new Long(rest));
            else if (cmd.equals("lt")) 
                return new QueryOp(QueryOp.LESS_THAN, new Long(rest));
            else if (cmd.equals("ends")) 
                return new QueryOp(QueryOp.ENDS_WITH, rest);
            else if (cmd.equals("starts"))
                return new QueryOp(QueryOp.STARTS_WITH, rest);
            else {
                ErrorMessage.message(this, ErrorMessage.EM_QUERY_FORM_ERROR, "@" + cmd);
                return null;
            }
            
        }
    }
    
    private void dateQuery(QueryFrame qf, String squery) throws java.text.ParseException {
        DateFormat df = new SimpleDateFormat("mm/dd/yy");
        if (0 == squery.length())
            return;
        if (! squery.startsWith("@")) {
            qf.set_system("update date", new QueryOp(QueryOp.EQUALS, new Long(df.parse(squery).getTime())));
        } else {
            int start = squery.indexOf(" ");
            String rest = squery.substring(start).trim();
            String cmd = squery.substring(1, start).toLowerCase();
            Long ms = new Long(df.parse(rest).getTime());
            if (cmd.equals("equals"))
                qf.set_system("update date", new QueryOp(QueryOp.EQUALS, ms));
            else if (cmd.equals("gt")) 
                qf.set_system("update date", new QueryOp(QueryOp.GREATER_THAN, ms));
            else if (cmd.equals("lt")) 
                qf.set_system("update date", new QueryOp(QueryOp.LESS_THAN, ms));
            else {
                ErrorMessage.message(this, ErrorMessage.EM_QUERY_FORM_ERROR, "@" + cmd);
            }            
        }        
    }
    
    private void versionQuery(QueryFrame qf, String squery) {
        if (0 == squery.length())
            return;
        if (! squery.startsWith("@")) {
            qf.set_system("version", new QueryOp(QueryOp.EQUALS, new Long(squery)));
        } else {
            int start = squery.indexOf(" ");
            String rest = squery.substring(start).trim();
            String cmd = squery.substring(1, start).toLowerCase();
            Long ver = new Long(rest);
            if (cmd.equals("equals"))
                qf.set_system("version", new QueryOp(QueryOp.EQUALS, ver));
            else if (cmd.equals("gt")) 
                qf.set_system("version", new QueryOp(QueryOp.GREATER_THAN, ver));
            else if (cmd.equals("lt")) 
                qf.set_system("version", new QueryOp(QueryOp.LESS_THAN, ver));
            else {
                ErrorMessage.message(this, ErrorMessage.EM_QUERY_FORM_ERROR, "@" + cmd);
            }            
        }        
        
    }

    //// ... End of stuff that should be elsewhere ...        
    
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        try { m_current_editor.looseFocus();} catch (Exception ex) {}
        
        if (cmd.equals("newelement")) {
            insertSelectedElement();
        } else if (cmd.equals("query")) {
            doQuery();
        } else
            super.actionPerformed(e);    
    }    
}
