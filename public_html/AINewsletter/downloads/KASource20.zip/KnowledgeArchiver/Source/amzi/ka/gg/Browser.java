/*
		A basic implementation of the JInternalFrame class.
*/
package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.beans.*;
import java.util.Enumeration;

import amzi.ka.*;
import amzi.frames.*;
import amzi.ka.gg.editors.*;

/** A browser maintains a split pane with a tree on the left and an editing 
* pane on the right. As selections are made in the tree a context sensitive
* editing pane appears in the right pane with appropriate contents
*/
public abstract class Browser extends JInternalFrame {
    
    // The underlying tree
    protected JTree m_tree;
    protected DefaultMutableTreeNode m_root;
    // And the panel to hold the tree and editor
    protected JPanel m_left_panel, m_right_panel;
    // BrowserPane for embedding purposes
    protected BrowserMainPane m_main_pane;
    // ANs is the right side of a split
    protected JSplitPane m_splitter;
    // Currently displayed editor
    protected BrowserEditor m_current_editor;
    // Do we have an Ineternal frame or are we in somehting else
    protected boolean m_embedded;
    
    protected BrowserContainer m_browser_container;
    
    protected JScrollPane m_current_scroller;
    
    protected Object m_target_object;
    
    protected Browser m_target_browser;

    protected DefaultMutableTreeNode m_last_edited_node;
    
    // Provides us with event mechanism for value changes */
    protected PropertyChangeSupport m_property_change;
    // Modified bit
    protected boolean m_dirty;
    // --------------------------------------------------------------------------------------------
    /** Constructor -- stand-alone in the desktop
    */
	public Browser()
	{
		super("Browser", true, true, true, true);
		m_embedded = false;
    }
    
    // Embeded in a parent (usually a dialog)
    public Browser (boolean embedded) {
		super();
		m_embedded = true;
    }

    /** 
    * All subclasses should implement this method and
    * call their superclass's init
    */
    public void init(KnowledgeFrame g, String file, BrowserContainer bc) {
        m_dirty = false;
        m_browser_container = bc;
		m_target_object  = null;
		m_target_browser = null;
		m_last_edited_node = null;
		m_main_pane = new BrowserMainPane(this);
		m_main_pane.setLayout(new BorderLayout());
		setContentPane(m_main_pane);
		setForeground(new Color(0));
		setBackground(new Color(-3355444));
		m_tree = new JTree(m_root = new DefaultMutableTreeNode(new GekkoTreeNode("root")));
		// m_tree.setRootVisible(false); // Root is hidden by default
		m_tree.expandRow(0); // But we show next level stuff
		m_tree.addTreeSelectionListener(m_main_pane);
	    m_current_editor = null;	
	    // Set the right panel up -- any scrolling here is handled
	    // by the editor component added to it
		m_right_panel = new JPanel(new BorderLayout());
		
		m_left_panel = new JPanel(new BorderLayout());
		m_left_panel.add("Center", new JScrollPane(m_tree));
		// Now build the split .. the tree is put in a scrollpane
		// with default (as needed) scrollbars
		m_splitter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, false, m_left_panel, m_right_panel);
		// m_splitter.setAlignmentY(0.5F);
		// m_splitter.setAlignmentX(0.5F);
		m_main_pane.add(m_splitter);
		m_splitter.setBackground(new Color(12632256));
		m_property_change = new PropertyChangeSupport(this);        
		if (! m_embedded) {
		    setSize(new Dimension(405,305));		
		    m_splitter.setDividerLocation(190);
		    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); // let listener do it		    
		}
		// Add property change support so container can be notified by us
		m_property_change.addPropertyChangeListener(bc);      
    }

    /**
    * Clean up and closes the browser. Checks to see if if
    * frame is modified
    */
    public void close() {
        
        if (isDirty()) {
            int result = JOptionPane.showConfirmDialog(
                    null, 
                    "The frame has been modified and not saved/uploaded. Do you really want to quit?",
                    "Warning",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane. WARNING_MESSAGE);

            if (JOptionPane.NO_OPTION == result) {
                return;
            }
        }
        setClean();
        m_browser_container.deregister(this);
    }

    // Overiding here lets us catch a close from the system menu/close
    // control -- I never could get internalFrameEventListener to work ...
    public void setClosed(boolean doit) {
        if (doit)
            close();
    }
    
    /** Generally overridden -- saves the browsed frame */
    public void save() {
    }
  
    /** Generally overwridden -- saves browsed framed in 
    * specified filename
    */
    public void save(String filename) {
    }
    /** 
    * Returns the underlying browsed object (Gekko, etc) but
    * may cause side-effects in browser (en/disabling menus etc). 
    */
    public abstract Object getBrowsedObjectForDisplay();

    /** 
    * Returns the browsed tree node 
    */
    public DefaultMutableTreeNode getBrowsedTreeNode() {
        try {
            return ((DefaultMutableTreeNode) m_tree.getLastSelectedPathComponent());
        } catch (Exception e) {
            return null;
        }
    }


    // Return active session
    public Session getSession() {
        return m_browser_container.getSession();
    }
    
    // My container (MainFrame)
    public BrowserContainer getBrowserContainer() {
        return m_browser_container;
    }

    // This is the default - usually overwritten
    public BrowserEditor getBrowserEditor(Object node) {
        return new TextAreaEditor();
    }
    
    // Modified bit handling
    public void setDirty() {
        m_dirty = true;
    }
    
    public void setClean() {
        m_dirty = false;
    }
    
    public boolean isDirty() {
        return m_dirty;
    }
    // End of modified bit handling
    
    
    /** The TreeSelection listener. We choose the correct editor based
    * on the path, display it, pass the underlying object to it.
    */
    public void valueChanged(TreeSelectionEvent e) {
        TreePath paths[], path;
        BrowserEditor neweditor;
        
        paths = e.getPaths();
        
        path = e.getOldLeadSelectionPath();
        
        try {
            if (null != m_last_edited_node) {
                ((DefaultTreeModel)m_tree.getModel()).nodeChanged(m_last_edited_node);
            }
        } catch (Exception ex) {
            MainFrame.println("Browser:valueChanged()-1:" + ex);
        }
      
        try {       
            for (int i = 0; i < paths.length; ++i) {
                path = paths[i];
                if (e.isAddedPath(path)) { 
                    neweditor = getBrowserEditor(path.getLastPathComponent());
                    m_last_edited_node = (DefaultMutableTreeNode) getBrowsedTreeNode();
                    if (null != m_current_editor) {
                        if (! m_current_editor.looseFocus()) // Veto the switch
                            return;
                        prepare();  // Let browser clean up
                        m_current_editor.getWidget().setVisible(false);
                        m_right_panel.remove(m_current_scroller);
                    }                   
                    m_right_panel.add("Center", m_current_scroller = new JScrollPane((Component) neweditor.getWidget()));
                    m_current_editor = neweditor;
                    neweditor.setValue(getBrowsedObjectForDisplay());  
                    prepare(((DefaultMutableTreeNode)getBrowsedTreeNode()).getUserObject());
                    m_right_panel.validate();
                }
            }
        } catch (Exception ex) {
                MainFrame.println("Browser:valueChanged()-2:" + ex);
        }    
    }    
    
    /** 
    * Usually subclassed 
    * @param obj -- the object in the tree that is the selection.
    * Allows the browser to prepare for display (e.g. set up verify panel
    * if it needs to)
    */
    public void prepare(Object obj) {
    }
    
    /**
    * Usually subclassed -- called before browser changes focussed
    * object -- gives browser chance to do anly last minute
    * clean up (e.g. getting rid of verify panel)
    */
    public void prepare() {
    }
    
    public void setColor(Color color) {
        getContentPane().setBackground(color);
    }
    
    public JPanel getRightPanel() {
        return m_right_panel;
    }
    
    public JPanel getLeftPanel() {
        return m_left_panel;
    }

    public JPanel getMainPanel() {
        return m_main_pane;
    }
    
    public void setTarget(Browser b, Object val) {
        m_target_object = val;
        m_target_browser = b;
    }   
    
    // This is usally subclassed. A node editor was told to 
    // update val with its frame after uploading
    public void updateTarget(KnowledgeFrame frame, Object val) throws Exception {
    }
    
    public PropertyChangeSupport getPropertyChangeSupport() {
        return m_property_change;
    }    
    
    public void selectNode(String nodename) {
        Enumeration enum;
        DefaultMutableTreeNode node = null;
        boolean found = false;
        TreePath path;
        
        enum = m_root.depthFirstEnumeration();
        while (enum.hasMoreElements()) {
            node = (DefaultMutableTreeNode)enum.nextElement();
            if (nodename.equals(node.getUserObject().toString())) {
                found = true;
                break;
            }
        }
        if (! found) {
            System.err.println("Node " + nodename + " not found");
            return;
        }
        
        path = new TreePath(node.getPath());
        m_tree.setSelectionPath(path);
        
    }
}


