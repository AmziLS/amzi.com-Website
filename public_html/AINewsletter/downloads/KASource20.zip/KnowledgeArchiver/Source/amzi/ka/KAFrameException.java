package amzi.ka;

import amzi.frames.*;

/**
 * Exception class for Knowledge Archive exceptions.
 *
 * @author  Amzi! inc.
 */

public class KAFrameException extends FrameException
{
   static class ErrorMsg
   {
      public int number;
      public int type;
      public String msg;

      public ErrorMsg(int n, int t, String m)
      {
         number = n;
         type = t;
         msg = m;
      }
   }

   // Types of errors
   public final static int UNKNOWN  = 0;
   public final static int ABORT    = 1;
   public final static int FATAL    = 2;
   public final static int INTERNAL = 3;
   public final static int ERROR    = 4;

   // I/O Errors 100-199
   public final static int IO_ERROR                  =  100;
   public final static int DATE_PARSE                =  101;
   public final static int EXCEPTION                 =  102;

   // Socket Errors 200-299
   public final static int SOCKET_CONNECT            =  200;
   public final static int CLIENT_SHUTDOWN           =  201;
   public final static int SEND_GEKO                 =  202;
   public final static int PROTOCOL                  =  203;
   public final static int BAD_COMMAND               =  204;
   public final static int SOCKET_IO                 =  205;
   public final static int OPTIONAL_DATA             =  206;
   public final static int SOCKET_DISCONNECT         =  207;
   public final static int NO_CONNECTION             =  208;
   public final static int REMOTE_EXCEPTION          =  209;
   public final static int MALFORMED_URL_EXCEPTION   =  210;
   public final static int NOT_BOUND_EXCEPTION       =  211;

   // Java Errors 300-399
   public final static int NO_CLASS                  =  300;
   public final static int THREAD_INTERRUPT          =  301;

   // Errors reading/writing GEKO text files 400-499
   public final static int TEXT_BAD_SLOT             =  400;
   public final static int TEXT_MISSING_DELIMITER    =  401;
   public final static int TEXT_UNEXPECTED_SEMICOLON =  402;
   public final static int TEXT_PARSE_ERROR          =  403;
   public final static int TEXT_BAD_FIRST_LEVEL_SLOT =  404;
   public final static int TEXT_VALUE_EXPECTED       =  405;
   public final static int BAD_KEYWORD_LIST          =  406;

   // Errors using Object Store database 500-599
   public final static int OS_ERROR                  =  500;
   public final static int OS_NOT_INITIALIZED        =  501;
   public final static int OS_MISSING_DATABASE       =  502;
   public final static int OS_OPEN_TRANSACTION       =  503;

   // KA format errors 600-699
   public final static int BAD_ROLE                  =  601;
   public final static int BAD_MATCH_OPERATOR        =  602;
   public final static int PERSON_NOT_AUTHOR         =  603;
   public final static int NO_SUCH_VARIABLE          =  604;
   public final static int BAD_LINK_DECLARATION      =  605;
   public final static int KB_EXCEPTION              =  606;
   public final static int BAD_LINK_TYPE             =  607;
   public final static int BAD_STRING_ASSIGNMENT     =  608;

   // Frame Errors 700-799
   public final static int FRAME_ERROR               =  700;
   public final static int DUPLICATE_FRAME           =  701;

   // Use Errors 800-899
   public final static int NO_LOGON                  =  800;
   public final static int NO_OPEN_ARCHIVE           =  801;

   protected boolean dump_exceptions = false;

   private static ErrorMsg[] msgs =
   {
      /*100*/ new ErrorMsg(IO_ERROR, ERROR,
         "IO Exception: "),
      /*101*/ new ErrorMsg(DATE_PARSE, ERROR,
         "Error parsing date string: "),
      /*102*/ new ErrorMsg(EXCEPTION, ERROR,
         ""),

      /*200*/ new ErrorMsg(SOCKET_CONNECT, ERROR,
         "Error establishing socket connection"),
      /*201*/ new ErrorMsg(CLIENT_SHUTDOWN, ERROR,
         "Error shutting down client"),
      /*202*/ new ErrorMsg(SEND_GEKO, ERROR,
         "Error sending a geko"),
      /*203*/ new ErrorMsg(PROTOCOL, ERROR,
         "Protocol error communicating with server"),
      /*204*/ new ErrorMsg(BAD_COMMAND, ERROR,
         "Bad command input"),
      /*205*/ new ErrorMsg(SOCKET_IO, ERROR,
         "Socket IO error: "),
      /*206*/ new ErrorMsg(OPTIONAL_DATA, ERROR,
         "Optional data exception"),
      /*207*/ new ErrorMsg(SOCKET_DISCONNECT, ERROR,
         "Error disconnecting from server: "),
      /*208*/ new ErrorMsg(NO_CONNECTION, ERROR,
         "You must connect to the server before logging on."),
      /*209*/ new ErrorMsg(REMOTE_EXCEPTION, ERROR,
         "A remote exception occurred: "),
      /*210*/ new ErrorMsg(MALFORMED_URL_EXCEPTION, ERROR,
         "A malformed URL exception occurred: "),
      /*211*/ new ErrorMsg(NOT_BOUND_EXCEPTION, ERROR,
         "A not bound exception occurred: "),

      /*300*/ new ErrorMsg(NO_CLASS, ERROR,
         "Class not found exception"),
      /*301*/ new ErrorMsg(THREAD_INTERRUPT, ERROR,
         "Interrupted thread in server."),

      /*400*/ new ErrorMsg(TEXT_BAD_SLOT, ERROR,
         "An unknown slot was encountered reading a GEKO file: "),
      /*401*/ new ErrorMsg(TEXT_MISSING_DELIMITER, ERROR,
         "A slot in a GEKO file was missing its delimiter: "),
      /*402*/ new ErrorMsg(TEXT_UNEXPECTED_SEMICOLON, ERROR,
         "While expecting a slot name, a semicolon was encountered: "),
      /*403*/ new ErrorMsg(TEXT_PARSE_ERROR, ERROR,
         "State of confusion reached while parsing GEKO file: "),
      /*404*/ new ErrorMsg(TEXT_BAD_FIRST_LEVEL_SLOT, ERROR,
         "An unexpected top level slot or frame in GEKO file: "),
      /*405*/ new ErrorMsg(TEXT_VALUE_EXPECTED, ERROR,
         "A text value was expected, but not found in GEKO file: "),
      /*406*/ new ErrorMsg(BAD_KEYWORD_LIST, ERROR,
         "An input keyword list was not formatted correctly: "),

      /*500*/ new ErrorMsg(OS_ERROR, ERROR,
         "Object Store error: "),
      /*501*/ new ErrorMsg(OS_NOT_INITIALIZED, ERROR,
         "Unable to initialize Object Store"),
      /*502*/ new ErrorMsg(OS_MISSING_DATABASE, ERROR,
         "Missing Object Store database: "),
      /*503*/ new ErrorMsg(OS_OPEN_TRANSACTION, ERROR,
         "Attempt to start an Object Store transaction when one is already in progress"),

      /*601*/ new ErrorMsg(BAD_ROLE, ERROR,
         "An invalid person role was encountered."),
      /*602*/ new ErrorMsg(BAD_MATCH_OPERATOR, ERROR,
         "An invalid match operation was encountered."),
      /*603*/ new ErrorMsg(PERSON_NOT_AUTHOR, ERROR,
         "An attempt was made to access author information on a non-author person: "),
      /*604*/ new ErrorMsg(NO_SUCH_VARIABLE, ERROR,
         "Attempt to reference an undefined variable: "),
      /*605*/ new ErrorMsg(BAD_LINK_DECLARATION, ERROR,
         "The declaration in a 'link' frame is ill-formed: "),
      /*606*/ new ErrorMsg(KB_EXCEPTION, ERROR,
         "Syntax or other error: "),
      /*607*/ new ErrorMsg(BAD_LINK_TYPE, ERROR,
         "Bad link type: "),
      /*608*/ new ErrorMsg(BAD_STRING_ASSIGNMENT, ERROR,
         "Attempt to match a non-string variable with a string constant: "),

      /*700*/ new ErrorMsg(FRAME_ERROR, ERROR,
         "Frame Library error: "),
      /*701*/ new ErrorMsg(DUPLICATE_FRAME, ERROR,
         "Attempt to upload a duplicate: "),

      /*800*/ new ErrorMsg(NO_LOGON, ERROR,
         "Attempt to perform archive operation before logging on."),
      /*801*/ new ErrorMsg(NO_OPEN_ARCHIVE, ERROR,
         "You must have an open archive to perform this function."),

      new ErrorMsg(UNKNOWN, UNKNOWN,
         "Unknown Knowledge Archiver Error")
   };

   protected String prefix = null;
   protected String msg = "";
   protected int error_number = 0;

   public KAFrameException()
   {
      msg = "";
      prefix = "";
      error_number = 0;
      server_info();
   }
   
   /**
    * Constructor for exception with just a preformatted message.
    *
    * @param   i  the identifier of the message
    */
   public KAFrameException(int i)
   {
      msg = findMsg(i);
      prefix = "";
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with a custom message.
    *
    * @param   m  the message to be used
    */
   public KAFrameException(String m)
   {
      msg = msg;
      prefix = "";
      error_number = 0;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted message
    * and a customized message prefix.
    *
    * @param   c  the message prefix
    * @param   i  the message identifier
    */
   public KAFrameException(String c, int i)
   {
      msg = findMsg(i);
      prefix = c;
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    */
   public KAFrameException(Object o, int i)
   {
      msg = findMsg(i);
      prefix = o.getClass().getName();
      error_number = i;
      server_info();
   }

   /**
    * Constructor for exception with a custom
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   m  the custom message
    */
   public KAFrameException(Object o, String m)
   {
      msg = m;
      prefix = o.getClass().getName();
      error_number = 0;
      server_info();
   }

   /**
    * Constructor for exception with a preformatted
    * message, a prefix generated from the class
    * name of the thrower, and additional information.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    * @param   a  additional information
    */
   public KAFrameException(Object o, int i, String a)
   {
      msg = findMsg(i) + a;
      prefix = o.getClass().getName();
      error_number = i;
      server_info();
   }

   protected String findMsg(int error_number)
   {
      // Just walk down the array looking, as this only
      // happens occasionally, its not such a
      // big deal.
      int i;
      for (i=0; i<msgs.length-1; i++)  // last message is default
      {
         if (msgs[i].number == error_number)
            break;
      }
      return msgs[i].msg;
   }

   public int get_error_number() { return error_number; }

   public String getMsg()
   {
      return getMessage();
   }

   public String getMessage()
   {
      switch (error_number)
      {
      case EXCEPTION:
      case KB_EXCEPTION:
      case FRAME_ERROR:
         return msg;
      default:
         return "Error #KA" + error_number + ": " + msg;
      }
   }

   /**
   * Provide information on the exception for the server.
   */
   protected void server_info()
   {
      if (dump_exceptions)
      {
         System.out.println();
         System.out.println("***** Creating KAFrameException *****");
         System.out.println("  prefix = " + prefix);
         System.out.println("  msg = " + msg);
         System.out.println("Stack Trace:");
         Thread.currentThread().dumpStack();
         System.out.println("***** Exception created *****");
         System.out.println();
      }
   }

}
