package amzi.ka.gg.editors;

import amzi.ka.gg.*;
import javax.swing.*;
import amzi.ka.*;
import amzi.frames.*;
import java.awt.*;
import java.beans.*;
import java.util.Vector;
/**
* Editor which gives a choice only
*/
public class ChoiceEditor extends BrowserEditor {
    private ChoiceComboBox m_combo;
    private Vector m_vchoices;
    
    public ChoiceEditor(String choices) {
        JLabel msg = new JLabel("Select one from the following: ");
        JPanel p = new JPanel();
        m_vchoices = new Vector();
        
        int lastpos = 0, pos = 0;
        while (true) {
            if (-1 == (pos = choices.indexOf(';', lastpos))) {
                if (choices.substring(lastpos).trim().length() > 0)
                    m_vchoices.addElement(choices.substring(lastpos).trim());
                break;
            }
            m_vchoices.addElement(choices.substring(lastpos, pos));
            lastpos = pos + 1;
        }
        m_combo = new ChoiceComboBox(this, m_vchoices);
        m_combo.setEnabled(true);
        m_combo.setEditable(false);
        p.add(m_combo);
        setLayout(new BorderLayout());
        add("North", msg);
        add("Center", p);
        invalidate();
        setEnabled(true);
    }
    
    // Initilize editor from object
    public void setValue(Object val) throws Exception {   
        boolean wasdirty;
        m_val = val;
        if (val instanceof KnowledgeSlot)
            val = ((KnowledgeSlot) val).value();           
        // Avoid dirtying at the start
        wasdirty = m_browser.isDirty();
        // find current selection and populate combo box edit field
        // with it .. indexOf doesn't work (blank space added ??)
        for (int i = 0; i < m_vchoices.size(); ++i)
            if (m_vchoices.elementAt(i).toString().trim().equals(val.toString().trim())) {
                m_combo.setSelectedIndex(i);
                break;
            }
        if (! wasdirty) m_browser.setClean();
    }
           
    public void synchValue() {
        KnowledgeSlot ks;
        Object val;
        
        val = m_vchoices.elementAt(m_combo.getSelectedIndex());        
        if (m_val instanceof KnowledgeSlot) {
            ks = (KnowledgeSlot) m_val;
            if (ks.value() instanceof java.lang.String)
                ks.set_value(val);
        } else if (m_val instanceof String){
            m_val = val;
        }
        m_browser.setDirty();
    }    
}

class ChoiceComboBox extends JComboBox {    
    
    private ChoiceEditor m_ce;
    public ChoiceComboBox(ChoiceEditor ce, Vector choices) {
        super(choices);
        m_ce = ce;        
    }    
    
    protected void selectedItemChanged() {
        m_ce.synchValue();
    }    
}