// PSEExpression.java

package amzi.ka.db;

import amzi.kb.*;

import java.util.*;
import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

public class PSEExpression
{
   Object[] terms;

   /**
   * The stack is in inverted order from the parser,
   * so save it reversing as we go.
   */
   public PSEExpression(Stack s)
   {
      int size = s.size();

      terms = new Object[size];

      for (int i=0; i < size; i++)
         terms[size-i-1] = s.elementAt(i);
   }

   public Expression makeExpression()
   {
      Object[] t2 = new Object[terms.length];
      Object o;

      for (int i=0; i<terms.length; i++)
      {
         if (terms[i].getClass() == PSEClasses.cPSEVariable)
            o = ((PSEVariable)terms[i]).makeVariableKey();
         else
            o = terms[i];
         t2[i] = o;
      }

      return new Expression(t2);
   }

   public void print(PrintStream o)
   {
      print("", o);
   }

   public void print(String dent, PrintStream o)
   {
      o.println(dent + toString());
   }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();

      Stack eval = new Stack();
      Integer Iop;
      Number arg1, arg2;

      for (int i=0; i<terms.length; i++)
         eval.push(terms[i]);

      while (! eval.empty())
      {
         Iop = (Integer)eval.pop();
         switch (Iop.intValue())
         {
         case Expression.INT:
         case Expression.DOUBLE:
         case Expression.VARIABLE:
            sb.append(eval.pop().toString() + " ");
            break;
         default:
            sb.append(Expression.ops[Iop.intValue()] + " ");
            break;
         }
      }
      
      return sb.toString();
   }
}
