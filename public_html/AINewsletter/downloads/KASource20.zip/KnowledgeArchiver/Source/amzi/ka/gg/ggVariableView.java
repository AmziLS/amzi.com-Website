//ggVariableView.java

package amzi.ka.gg;

import amzi.kb.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ggVariableView extends JDialog
      implements ActionListener
{
   JFrame parent;
   Variable var;
   ggConsult gg_consult;

   JButton m_set;
   JButton m_goal;
   JButton m_cancel;

   public ggVariableView(JFrame p, ggConsult c, Variable v)
   {
      super(p, "Variable " + v.get_name(), false);
      //MainFrame.println("Creating VV for " + v.get_name());
      parent = p;
      var = v;
      gg_consult = c;
      ui_init();
   }

   private void ui_init()
   {
      Dimension psz = parent.getSize();
      Point ploc = parent.getLocation();
      Point loc = new Point(ploc.x + psz.width/2, ploc.y + psz.height/2);
      Dimension sz = new Dimension(psz.width/3, psz.height/3);
      setSize(sz);
      setLocation(loc);

      JPanel p = new JPanel();
      p.setLayout(new BorderLayout());
      p.add(data(), "Center");
      p.add(buttons(), "South");

      m_cancel = new JButton("Cancel");
      m_cancel.addActionListener(this);

      getContentPane().add(p);
      setVisible(true);
      show();
   }

   private JPanel data()
   {
      JPanel p = new JPanel();
      GridBagLayout gb = new GridBagLayout();
      p.setLayout(gb);

      GridBagConstraints gc = new GridBagConstraints();
      gc.fill = GridBagConstraints.HORIZONTAL;
      gc.gridy = 0;
      gc.gridx = GridBagConstraints.RELATIVE;
      gc.insets = new Insets( 5, 10, 5, 10 );

      JLabel l1 = new JLabel("Name:");
      gc.gridwidth = 1;
      gc.anchor = GridBagConstraints.WEST;
      gc.weightx = 0.2;
      gb.setConstraints(l1, gc);
      p.add(l1);

      JTextField t1 = new JTextField();
      gc.gridwidth = GridBagConstraints.REMAINDER;
      gc.anchor = GridBagConstraints.EAST;
      gc.weightx = 0.8;
      gb.setConstraints(t1, gc);
      t1.setText(var.get_name());
      p.add(t1);

      JLabel l2 = new JLabel("Choices:");
      gc.gridwidth = 1;
      gc.anchor = GridBagConstraints.WEST;
      gc.weightx = 0.2;
      gc.gridy = 1;
      gb.setConstraints(l2, gc);
      p.add(l2);

      JTextField t2 = new JTextField();
      gc.gridwidth = GridBagConstraints.REMAINDER;
      gc.anchor = GridBagConstraints.EAST;
      gc.weightx = 0.8;
      gb.setConstraints(t2, gc);
      t2.setText(var.get_menu().toString());
      p.add(t2);

      p.setBorder( new BevelBorder(BevelBorder.RAISED) );
      return p;
   }

   private JPanel buttons()
   {
      JPanel p = new JPanel();
      p.setLayout( new FlowLayout() );

      m_set = new JButton("Set Value");
      m_set.addActionListener(this);
      m_set.setActionCommand("set");
      p.add(m_set);

      m_goal = new JButton("Make Goal");
      m_goal.addActionListener(this);
      m_goal.setActionCommand("goal");
      p.add(m_goal);

      m_cancel = new JButton("Cancel");
      m_cancel.addActionListener(this);
      m_cancel.setActionCommand("cancel");
      p.add(m_cancel);

      p.setBorder( new BevelBorder(BevelBorder.RAISED) );
      return p;
   }

   /**
   * Implementation of ActionListener.
   */
   public void actionPerformed( ActionEvent e )
   {
      //MainFrame.println("action = " + e.getActionCommand());

      if (e.getActionCommand().equals("cancel"))
         dispose();
      else if (e.getActionCommand().equals("goal"))
      {
         gg_consult.set_goal(var);
         dispose();
      }
      else if (e.getActionCommand().equals("set"))
      {
         //Thread.dumpStack();
         ggAsk a = new ggAsk(parent, this, gg_consult, var);
      }
   }
}