// GEKOClientI_RMI.java

package amzi.ka.net.rmi.client;

import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.frames.*;
import amzi.kb.*;

import java.net.*;
import java.io.*;
import java.util.*;
import java.rmi.*;
import java.rmi.server.RMISocketFactory;
import sun.rmi.transport.proxy.RMIHttpToPortSocketFactory;

/**
* Implements the GEKOClientI interface using remote
* objects on the server.
* @author Amzi! inc.
*/
public class GEKOClientI_RMI implements GEKOClientI
{
   KnowledgeFrame me = null;
   String archive = null;
   GEKOLogonRI logon_ri = null;
   GEKOLibraryRI gekos_ri = null;
   String user_id = null;

   public GEKOClientI_RMI()
   {
   }

   /**
   * Connect to the server
   */
   public void connect(String addr) throws FrameException
   {
      String host;
      String port;
      int i = addr.indexOf(':');

      if (i >= 0)
      {
         host = addr.substring(0, i);
         port = addr.substring(i+1);
      }
      else
      {
         host = addr;
         port = "1099";
      }
      connect(host, port);
   }

   /**
   * Connect to the server
   */
   public void connect(String host, String port) throws FrameException
   {
      connect(host, port, null, null);
   }

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port,
         String proxy_host, String proxy_port) throws FrameException
   {
      if ( proxy_host != null && ! proxy_host.equals("") )
      {
         System.getProperties().put( "http.proxySet", "true" );
         System.getProperties().put( "http.proxyHost", proxy_host );
         System.getProperties().put( "http.proxyPort", proxy_port );
      }

      try
      {
         if (System.getProperties().getProperty("http.proxyHost") != null)
            RMISocketFactory.setSocketFactory(new RMIHttpToPortSocketFactory());
         System.setSecurityManager(new RMISecurityManager());
         logon_ri = (GEKOLogonRI)Naming.lookup("rmi://" + host + ":" + port + "/KA");
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
      catch (MalformedURLException e)
      {
         throw new KAFrameException(this, KAFrameException.MALFORMED_URL_EXCEPTION, e.getMessage());
      }
      catch (NotBoundException e)
      {
         throw new KAFrameException(this, KAFrameException.NOT_BOUND_EXCEPTION, e.getMessage());
      }
      catch (IOException e)
      {
         throw new KAFrameException(this, KAFrameException.IO_ERROR, e.getMessage());
      }
   }

   /**
   * Allow a user to log onto the server.
   */
   public boolean logon(String user_id, String password) throws FrameException
   {
      this.user_id = user_id;
      boolean tf = false;

      if (logon_ri == null)
         throw new KAFrameException(this, KAFrameException.NO_CONNECTION);

      try
      {
         tf = logon_ri.logon(user_id, password);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }

      return tf;
   }

   public void logoff() throws FrameException
   {
      try
      {
         logon_ri.logoff(user_id);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   public void close(String archive) throws FrameException
   {
      try
      {
         logon_ri.close(user_id, archive);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get an array of available archive names.
   */
   public Vector get_archives() throws FrameException
   {
      try
      {
         return logon_ri.get_archives();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Check to see if a geko exists for the given title.
   * @param title The title string.
   * @param geko The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_geko(String title, KnowledgeFrame geko) throws FrameException
   {
      try
      {
         return gekos_ri.check_geko(title, geko);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }


  /**
  * Check to see if an author exists with the given name.
  * @param name The name string.
  * @param author The frame to compare against.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_author(String name, KnowledgeFrame author) throws FrameException
   {
      try
      {
         return gekos_ri.check_author(name, author);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }


  /**
  * Check to see if a variable exists with the given name.
  * @param name The name string.
  * @param variable The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_variable(String name, KnowledgeFrame variable) throws FrameException
   {
      try
      {
         return gekos_ri.check_variable(name, variable);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }


  /**
  * Check to see if a citation exists with the given body.
  * @param body The body string.
  * @param citation The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_citation(String body, KnowledgeFrame citation) throws FrameException
   {
      try
      {
         return gekos_ri.check_citation(body, citation);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }


   /**
   * Check to see if a keyword exists with the given body.
   * @param item The keyword string.
   * @param keyword The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_keyword(String item, KnowledgeFrame keyword) throws FrameException
   {
      try
      {
         return gekos_ri.check_keyword(item, keyword);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get all the variables from the archive formatted
   * for inferencing.
   */
   public Variable[] get_variables() throws FrameException
   {
      try
      {
         return gekos_ri.get_variables();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get all the links from the archive formatted
   * for inferencing.
   */
   public Link[] get_links() throws FrameException
   {
      try
      {
         return gekos_ri.get_links();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get all the rules from the gekos in the archive
   * formatted for inferencing.
   */
   public Rule[] get_rules() throws FrameException
   {
      try
      {
         return gekos_ri.get_rules();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   // The KnowledgeLibrary interface

   /**
   * Creates a new Knowledge Library.
   */
   public void initialize() throws FrameException
   {
      try
      {
         gekos_ri.initialize();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Creates a new Knowledge Library.
   */
   public void initialize(Thread th) throws FrameException
   {
      try
      {
         gekos_ri.initialize(th);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Creates a new open Knowledge Library.
   */
   public void create(String db_name) throws FrameException
   {
      try
      {
         if (user_id == null)
            throw new KAFrameException(this, KAFrameException.NO_LOGON);
         gekos_ri = logon_ri.create(user_id, db_name, null, null);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Creates a new open Knowledge Library.
   */
   public void create(String db_name, String schema_file_name) throws FrameException
   {
      try
      {
         if (user_id == null)
            throw new KAFrameException(this, KAFrameException.NO_LOGON);
         gekos_ri = logon_ri.create(user_id, db_name, schema_file_name, null);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Create a new closed Knowledge Library with the first user
   * being the archivist.
   */
   public void create(String db_name, String schema_file_name, KnowledgeFrame archivist) throws FrameException
   {
      try
      {
         if (user_id == null)
            throw new KAFrameException(this, KAFrameException.NO_LOGON);
         gekos_ri = logon_ri.create(user_id, db_name, schema_file_name, archivist);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException
   {
      try
      {
         if (user_id == null)
            throw new KAFrameException(this, KAFrameException.NO_LOGON);
         gekos_ri = logon_ri.open(user_id, db_name);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Close an open Knowledge Library.
   */
   /*
   public void close() throws FrameException
   {
      try
      {
         logon_ri.logoff(user_id, archive);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }
   */

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException
   {
      try
      {
         gekos_ri.add_group(group);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException
   {
      try
      {
         return gekos_ri.get_groups();
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException
   {
      try
      {
         return gekos_ri.put_frame(f);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException
   {
      try
      {
         gekos_ri.remove_frame(f);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key, int version) throws FrameException
   {
      try
      {
         return gekos_ri.get_frame(group, key, version);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException
   {
      try
      {
         return gekos_ri.get_frame(group, key);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException
   {
      try
      {
         return gekos_ri.get_key_notes(group);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException
   {
      try
      {
         return gekos_ri.query(qf);
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
   }
}
