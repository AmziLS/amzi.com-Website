// KnowledgeBuilder.java

package amzi.ka.db;

import amzi.frames.*;
import amzi.frames.pse.*;
import amzi.ka.*;
import amzi.kb.*;

import java.io.*;
import java.util.*;

/**
* KnowledgeBuilder is a utility class that provides
* the services that reside in the stand-alone
* amzi.kb.KnowledgeBase.  That is, it is a place for
* code to be built and variables to be registered but
* in the context of objects suitable for storing in
* KA using PSE.
*/
public class KnowledgeBuilder
{
   //public static final int KB_KIND_OF = 1;
   //public static final int KB_EQUIVALENT_TO = 2;

   public static final int KB_STATE_INDEPENDENT = 3;
   public static final int KB_STATE_MODEL_SYSTEM = 4;
   public static final int KB_STATE_CONTROLLED = 5;

   public static final int KB_MODE_TO_ARCHIVE = 6;
   public static final int KB_MODE_FROM_ARCHIVE = 7;

   GEKOLibraryI gekos;
   String geko_title;
   KnowledgeFrame kf;   // The "Knowledge Frame" slot of the geko.

   Vector rules;
   Vector dependent_variables;
   Vector independent_variables;
   Vector model_system_variables;
   Vector controlled_variables;
   Vector declared_variables;
   Test model_system = null;
   Test controls = null;

   Hashtable variables;
   int to_from_mode;

   int condition_state;

   static GEKOKBParser rp = null;
   
   public KnowledgeBuilder(KnowledgeFrame geko, GEKOLibraryI gekos)
         throws KBException, FrameException
   {
      this.gekos = gekos;
      kf = (KnowledgeFrame)geko.get("Knowledge Frame");
      geko_title = (String)((KnowledgeFrame)geko.get("Source Frame")).get("Title");
      rules = new Vector();
      dependent_variables = new Vector();
      independent_variables = new Vector();
      model_system_variables = new Vector();
      controlled_variables = new Vector();
      declared_variables = new Vector();
      condition_state = KB_STATE_INDEPENDENT;
      variables = new Hashtable();
      to_from_mode = KB_MODE_TO_ARCHIVE;
   }

   public void set_to_from_mode(int m)
   {
      to_from_mode = m;
   }

   public void set_condition_state(int s)
   {
      condition_state = s;
   }

	public KnowledgeFrame parse_kb() throws KBException
	{
      String source_code;
      String slot = "";
      try
      {
         //System.out.println("*** starting to read GEKO code ***");

         // Read the 'code' slot first.
         source_code = (String)kf.get("Code");
         slot = "Code";
//System.out.println("parsing code: " + source_code);

         if (rp == null)
            rp = new GEKOKBParser(
               new StringReader(source_code));
         else
            rp.ReInit(new StringReader(source_code));
         GEKOKBParser.initialize(this);

         rp.read_code();

         // Next get the preconditions slots
         source_code = (String)kf.get("Controls");
         slot = "Controls";
//System.out.println("parsing controls: " + source_code);
         if (source_code != null && source_code.length() > 1)
         {
            rp.ReInit(new StringReader(source_code));
            controls = rp.PreCondition();
         }

         source_code = (String)kf.get("Model System");
         slot = "Model System";
//System.out.println("parsing model system: " + source_code);
         if (source_code != null && source_code.length() > 1)
         {
            rp.ReInit(new StringReader(source_code));
            model_system = rp.PreCondition();
         }

         source_code = (String)kf.get("Declared Relations");
         slot = "Declared Relations";
//System.out.println("parsing relations: " + source_code);
         if (source_code != null && source_code.length() > 1)
         {
            rp.ReInit(new StringReader(source_code));
            rp.read_declarations();
         }

         //this.print(System.out);
         //System.out.println("*** end of GEKO code reading ***");
         fix_kf();
      }
      /*
      catch (KBException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw ex;
      }
      catch (ParseException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.PARSE_EXCEPTION, ex.getMessage());
      }
      */
      catch (Exception ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.EXCEPTION, slot + " " + ex.getMessage());
      }
      catch (Error ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.EXCEPTION, slot + " " + ex.getMessage());
      }

      return kf;  // not really necessary, but makes it clear what's happening
	}

	public Code parse_archive_geko() throws KBException, FrameException
	{
      String source_code;
      String slot = "";  // used in error reporting
      KnowledgeList klvars;
      try
      {
         System.out.println("*** starting to read archive GEKO code ***");

         // First get the variables from the GEKO into the local variables
         // hashtable.

         slot = "Dependent Variables";
         klvars = (KnowledgeList)kf.get("Dependent Variables");
         get_vars(klvars);
         slot = "Independent Variables";
         klvars = (KnowledgeList)kf.get("Independent Variables");
         get_vars(klvars);
         slot = "Model System Variables";
         klvars = (KnowledgeList)kf.get("Model System Variables");
         get_vars(klvars);
         slot = "Controlled Variables";
         klvars = (KnowledgeList)kf.get("Controlled Variables");
         get_vars(klvars);
         slot = "Declared Variables";
         klvars = (KnowledgeList)kf.get("Declared Variables");
         get_vars(klvars);

         // Read the 'code' slot next.
         source_code = (String)kf.get("Code");
         slot = "Code";

         if (rp == null)
            rp = new GEKOKBParser(
               new StringReader(source_code));
         else
            rp.ReInit(new StringReader(source_code));
         GEKOKBParser.initialize(this);

         rp.read_code();

         // Next get the preconditions slots
         source_code = (String)kf.get("Controls");
         slot = "Controls";
         if (source_code != null && source_code.length() > 1)
         {
            rp.ReInit(new StringReader(source_code));
            controls = rp.PreCondition();
         }

         source_code = (String)kf.get("Model System");
         slot = "Model System";
         if (source_code != null && source_code.length() > 1)
         {
            rp.ReInit(new StringReader(source_code));
            model_system = rp.PreCondition();
         }

         this.print(System.out);
         System.out.println("*** end of GEKO code reading ***");
      }
      /*catch (KBException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw ex;
      }
      catch (ParseException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.PARSE_EXCEPTION, slot + ": " + ex.getMessage());
      }
      */
      catch (Exception ex)
      {
         //System.out.println(ex.getMessage());
         //ex.printStackTrace();
         throw new KBException(this, KBException.EXCEPTION, ex.getMessage()
               + " in slot " + slot + " of GEKO " + geko_title);
      }
      catch (Error ex)
      {
         throw new KBException(this, KBException.EXCEPTION, slot + ex.getMessage()
               + " in slot " + slot + " of GEKO " + geko_title);
      }

      for (int i=0; i<rules.size(); i++)
      {
         if (model_system != null)
            ((Rule)rules.elementAt(i)).add_precondition(model_system);
         if (controls != null)
            ((Rule)rules.elementAt(i)).add_precondition(controls);
      }

      return new Code(rules);  // not really necessary, but makes it clear what's happening
	}

   /**
   * Get the variables and their local names from the list
   * of local variable frames.
   */
   private void get_vars(KnowledgeList kl) throws FrameException
   {
      KnowledgeFrame kflv;
      String local_name;
      String vkey;

      for (int i=0; i<kl.length(); i++)
      {
         kflv = (KnowledgeFrame)((KnowledgeSlot)kl.slot_at(i)).value();
         local_name = (String)kflv.get("Local Name");
         vkey = ((KnowledgeFrame)kflv.get("Archive Variable")).get_key();
         variables.put(local_name, new VariableKey(vkey));
      }
   }

   private boolean check_dup_variable(Vector vars, VariableKey v)
   {
      VariableKey va;
      String key = v.get_key();

      for (int i=0; i<vars.size(); i++)
      {
         va = (VariableKey)vars.elementAt(i);
         if (va.get_key().equals(key))
            return true;
      }

      return false;
   }

   public void add_declaration(int type, String vname_1, String vname_2)
         throws FrameException
   {
      VariableKey v1 = check_variable(vname_1);
      if (! check_dup_variable(declared_variables, v1))
         declared_variables.addElement(v1);

      VariableKey v2 = check_variable(vname_2);
      if (! check_dup_variable(declared_variables, v2))
         declared_variables.addElement(v2);

      if (link_exists(type, vname_1, vname_2))
         return;

      KnowledgeFrame kl = new KnowledgeFrame("link");
      kl.set("Declaration",
         vname_1 +
         " " + Link.TYPE_NAMES[type] + " " +
         vname_2);
      String key = gekos.put_frame(kl);
      // The variables will be added as part of the put,
      // lets get them back for our own uses.
      kl = gekos.get_frame("link", key);
      
   }

   private boolean link_exists(int type, String vn1, String vn2)
         throws FrameException
   {
      QueryFrame qf = new QueryFrame("link");

      qf.set("Type", new QueryOp(QueryOp.EQUALS, Link.TYPE_NAMES[type]));

      QueryFrame qv1 = new QueryFrame("variable");
      qv1.set("Name", new QueryOp(QueryOp.EQUALS, vn1));
      qf.set("Variable 1", new QueryOp(QueryOp.MATCH_FRAME, qv1));

      QueryFrame qv2 = new QueryFrame("variable");
      qv2.set("Name", new QueryOp(QueryOp.EQUALS, vn2));
      qf.set("Variable 2", new QueryOp(QueryOp.MATCH_FRAME, qv2));

      Vector answers = gekos.query(qf);
      if (answers.isEmpty())
         return false;
      else
         return true;
   }
      
   /**
   * Set up the knowledge frame with the compiled forms of rules etc.
   */
   private void fix_kf() throws FrameException
   {
      //Code c = new Code(rules, dependent_variable, model_system, controls);
      //kf.set("Compiled Code", c);
      KnowledgeFrame kv, klv;
      int i;

      //kv = kl.get_frame("variable", dependent_variable.get_key());
      //kf.set("Dependent Variable", kv);

      // Clear out the old lists so we can add the new
      kf.set("Dependent Variables", new KnowledgeList());
      kf.set("Independent Variables", new KnowledgeList());
      kf.set("Model System Variables", new KnowledgeList());
      kf.set("Controlled Variables", new KnowledgeList());
      kf.set("Declared Variables", new KnowledgeList());
      

      for (i=0; i<dependent_variables.size(); i++)
      {
         kv = gekos.get_frame("variable",
               ((VariableKey)dependent_variables.elementAt(i)).get_key());
         klv = new KnowledgeFrame("local_variable");
         klv.set("Local Name", kv.get("Name"));
         klv.set("Archive Variable", kv);
         kf.add_list_item("Dependent Variables", klv);
      }

      for (i=0; i<independent_variables.size(); i++)
      {
         kv = gekos.get_frame("variable",
               ((VariableKey)independent_variables.elementAt(i)).get_key());
         klv = new KnowledgeFrame("local_variable");
         klv.set("Local Name", kv.get("Name"));
         klv.set("Archive Variable", kv);
         kf.add_list_item("Independent Variables", klv);
      }

      for (i=0; i<model_system_variables.size(); i++)
      {
         kv = gekos.get_frame("variable",
               ((VariableKey)model_system_variables.elementAt(i)).get_key());
         klv = new KnowledgeFrame("local_variable");
         klv.set("Local Name", kv.get("Name"));
         klv.set("Archive Variable", kv);
         kf.add_list_item("Model System Variables", klv);
      }

      for (i=0; i<controlled_variables.size(); i++)
      {
         kv = gekos.get_frame("variable",
               ((VariableKey)controlled_variables.elementAt(i)).get_key());
         klv = new KnowledgeFrame("local_variable");
         klv.set("Local Name", kv.get("Name"));
         klv.set("Archive Variable", kv);
         kf.add_list_item("Controlled Variables", klv);
      }

      for (i=0; i<declared_variables.size(); i++)
      {
         kv = gekos.get_frame("variable",
               ((VariableKey)declared_variables.elementAt(i)).get_key());
         klv = new KnowledgeFrame("local_variable");
         klv.set("Local Name", kv.get("Name"));
         klv.set("Archive Variable", kv);
         kf.add_list_item("Declared Variables", klv);
      }

      System.out.println("Knowledge Frame:");
      System.out.println(kf.toFullString());
      System.out.println("---");
   }

   /**
   * Find a knowledge frame based on a query in which a single slot is
   * compared against a single value.  Return just the first if there
   * are multiple solutions.
   */
   private String simple_key_query(String group, String slot_name, String value)
         throws FrameException
   {
      // Create a new query frame for the group.
      QueryFrame qf = new QueryFrame(group);

      // Set a query slot pattern match for the simple equals case.
      qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

      // The query returns a vector of key_note_pairs that
      // satisfy the query.  We'll just take the first one
      // or return null.
      Vector answers = gekos.query(qf);
      if (answers.isEmpty())
         return null;
      
      // Retrieve the desired frame.
      String key = ((KeyNotePair)answers.firstElement()).get_key();
      return key;
   }

/*
   public VariableKey set_dependent_variable(String v_name)
      throws KAFrameException, FrameException
   {
      dependent_variable = check_variable(v_name);

      return dependent_variable;
   }
*/

   public VariableKey add_dependent_variable(String v_name)
      throws KAFrameException, FrameException
   {
      VariableKey v = check_variable(v_name);
      if (to_from_mode == KB_MODE_FROM_ARCHIVE)
         return v;

      if (! check_dup_variable(dependent_variables, v))
         dependent_variables.addElement(v);

      return v;
   }

   public VariableKey add_variable(String v_name)
      throws KAFrameException, FrameException
   {
      VariableKey v = check_variable(v_name);
      if (to_from_mode == KB_MODE_FROM_ARCHIVE)
         return v;

      switch (condition_state)
      {
      case KB_STATE_INDEPENDENT:
         return add_independent_variable(v);
      case KB_STATE_MODEL_SYSTEM:
         return add_model_system_variable(v);
      case KB_STATE_CONTROLLED:
         return add_controlled_variable(v);
      default:
         return null;
      }
   }

   private VariableKey add_independent_variable(VariableKey v)
      throws KAFrameException, FrameException
   {
      if (! check_dup_variable(independent_variables, v))
         independent_variables.addElement(v);

      return v;
   }

   private VariableKey add_model_system_variable(VariableKey v)
      throws KAFrameException, FrameException
   {
      if (! check_dup_variable(model_system_variables, v))
         model_system_variables.addElement(v);

      return v;
   }

   private VariableKey add_controlled_variable(VariableKey v)
      throws KAFrameException, FrameException
   {
      if (! check_dup_variable(controlled_variables, v))
         controlled_variables.addElement(v);

      return v;
   }

   private VariableKey check_variable(String v_name)
      throws KAFrameException, FrameException
   {
      VariableKey vk;

      if (variables.containsKey(v_name))
         vk = (VariableKey)variables.get(v_name);
      else
      {
         String v_key = simple_key_query("variable", "Name", v_name);
         if (v_key == null)
            throw new KAFrameException(this, KAFrameException.NO_SUCH_VARIABLE, v_name);
         vk = new VariableKey(v_key);
         variables.put(v_name, vk);
      }

      return vk;
   }

   public void add_variable_choice(VariableKey v, Object choice)
      throws KAFrameException, FrameException
   {
      if (to_from_mode == KB_MODE_FROM_ARCHIVE)
         return;

      //System.out.println("Adding variable choice: " +
      //      v.toString() + " -- " + choice.toString());
      if (choice == null)
         return;

      if (choice.getClass() != KAClasses.cString)
         return;

      KnowledgeFrame kfv = (KnowledgeFrame)gekos.get_frame("variable", v.get_key());
      String type = (String)kfv.get("Type");

      if (! type.equals("string"))
         throw new KAFrameException(this, KAFrameException.BAD_STRING_ASSIGNMENT,
               (String)kfv.get("Name") + " & \"" + choice.toString() + "\"");

      Object o = kfv.get("Choices");
      Vector choices;
      if (o != null && o.getClass() == KAClasses.cVector)
         choices = (Vector)o;
      else
         choices = new Vector();
      if (! choices.contains(choice))
      {
         choices.addElement(choice);
         //System.out.println("Choice added: " + choice.toString());
      }
      kfv.set("Choices", choices);
      gekos.put_frame(kfv);
   }

   public void add_rule(Rule r)
   {
      rules.addElement(r);
   }

   public void print(PrintStream o)
   {
      o.println("Printing rules from knowledge builder:");
      Rule r;
      Enumeration e = rules.elements();
      while (e.hasMoreElements())
      {
         r = (Rule)e.nextElement();
         r.print(o);
         o.println();
      }
   }
}