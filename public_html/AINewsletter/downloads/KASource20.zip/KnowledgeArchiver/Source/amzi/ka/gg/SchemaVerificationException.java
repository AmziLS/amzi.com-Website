package amzi.ka.gg;

public class SchemaVerificationException extends Exception {
    
    public SchemaVerificationException(String msg) {
        super(msg);
    }   
}

