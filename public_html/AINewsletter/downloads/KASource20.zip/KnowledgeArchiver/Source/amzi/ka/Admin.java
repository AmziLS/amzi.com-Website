// Admin.java

package amzi.ka;

import amzi.frames.*;
import amzi.ka.clientdb.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.client.*;
import amzi.kb.*;

import java.util.*;
import java.io.*;

public class Admin
{
   static KHIParser khip = null;

   GEKOClientI gekos;
   BufferedReader din;

   // Used in edit mode
   KnowledgeFrame current_geko;
   KnowledgeFrame current_person;
   KnowledgeFrame current_citation;
   KnowledgeFrame current_keyword;
   KnowledgeFrame current_variable;

   public static void main(String[] args) throws Exception
   {
      Admin app = new Admin();
      app.go();
   }

   public Admin() throws Exception
   {
      din = new BufferedReader(new InputStreamReader(System.in));
   }

   public void go() throws Exception
   {
      System.out.println("AMKES Administration Utility");
      System.out.println("");

      String command = "help";

      while (! command.equals("exit"))
      {
         try
         {
            if (command.equals("error")) ;    // do nothing after an error
            // System
            else if (command.equals("help"))      display_help();
            else if (command.equals("logon"))     logon();
            else if (command.equals("logoff"))    logoff();
            else if (command.equals("local"))     local();
            else if (command.equals("create"))    new_library();
            else if (command.equals("import"))    inport();
            else if (command.equals("export"))    export();
            else
               display_help();

            System.out.print("\nKA> ");
            command = din.readLine();
         }
         catch (KAFrameException e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (FrameException e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (IOException e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (Exception e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
         catch (Error e)
         {
            System.out.println(e.getMessage());
            e.printStackTrace();
            command = "error";
         }
      }
      System.out.println("quitting");
      return;
   }

   private void display_help()
   {
      System.out.println("The KA Administration application");
      System.out.println("is a command line interface");
      System.out.println("to a Knowledge Archive.");
      System.out.println();
      System.out.println("You can enter the following commands:");
      System.out.println("  help     - shows this information");
      System.out.println("  local    - run with local archives");
      System.out.println("  logon    - logon to server");
      System.out.println("  logoff   - logoff server");
      System.out.println("  create   - create archive");
      System.out.println("  import   - import text gekos from a directory");
      System.out.println("  export   - export text gekos from an archive");
      System.out.println("  exit     - exits the Knowledge Archiver");
   }


   class GKOFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return n.endsWith(".gko");
      }
   }

   class XMLFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return n.endsWith(".xml");
      }
   }

   class GKOXMLFilter implements FilenameFilter
   {
      public boolean accept(File f, String n)
      {
         return (n.endsWith(".xml") || n.endsWith(".gko"));
      }
   }

   private void local() throws FrameException, IOException
   {
      gekos = new GEKOClientI_PSE();
   }

   private void logon() throws FrameException, IOException
   {
      gekos = new GEKOClientI_RMI();
      String default_addr = "209.251.13.83";
      String port = "1099";
      String addr = prompt("Server address (" + default_addr + ")");
      if (addr.equals(""))
         addr = default_addr;
      if (addr.equals("local"))
         addr = "";
      System.out.println("Connecting to server...");
      gekos.connect(addr, port);
      boolean tf = gekos.logon(
            prompt("User ID: "),
            prompt("Password: ") );
      if (tf)
         System.out.println("Logon successfull");
      else
         System.out.println("Logon failed");
   }

   private void logoff() throws FrameException
   {
      gekos.logoff();
   }

   private void inport() throws FrameException, IOException
   {
      String ans = prompt("New Archive? (y/n)");
      if (ans.equals("y"))
         new_library();
      else
         open_library();

      //gekos.create( "navy", "infer02" );
      //gekos.open("navy");

      String dir = prompt("Enter full path name for gekos directory: ");
      //String dir = "/knowledgearchiver/gekos/frank/";
      edit_batch(dir);
   }

   private void export() throws FrameException, IOException
   {
      KeyNotePair kn;
      KnowledgeFrame g;
      String file_name;
      File file_out;
      PrintWriter out;
      open_library();

      String dir = prompt("Enter full path name for export directory: ");

      Vector v = gekos.get_key_notes("geko");
      for (int i=0; i<v.size(); i++)
      {
         kn = (KeyNotePair)v.elementAt(i);
         System.out.println(kn.get_key() + ": " + kn.summary());
         g = gekos.get_frame("geko", kn.get_key());
         file_name = kn.get_key() + ".xml";

         out = new PrintWriter(new FileWriter(dir + file_name));
         out.print(g.toXMLString());
         out.flush();
         out.close();
      }
   }

   private void new_library() throws FrameException, IOException
   {
      String name = prompt("New Library Name: ");
      String schema = prompt("Schema: ");
      gekos.create( name, schema );
      gekos.open(name);
   }
   
   private void open_library() throws FrameException, IOException
   {
      Vector archives = gekos.get_archives();
      gekos.open(string_list_select(archives));
   }
   

   /**
   * Register all the gekos in a subdirectory of gekos.
   */
   private void edit_batch(String dir) throws IOException
   {
      int i;
      String[] files = (new File(dir)).list(new GKOXMLFilter());

      // sort the files by name
      Vector vf = new Vector();
      for (i=0; i<files.length; i++)
         vf.addElement(files[i]);
      Sorter s = new Sorter();
      s.sort(vf);
      for (i=0; i<files.length; i++)
         files[i] = (String)vf.elementAt(i);

      PrintWriter log = new PrintWriter(new FileOutputStream(
            "/KArchives/batchlog.txt"),
            true);
      for (i=0; i<files.length; i++)
      {
         try
         {
            System.out.println();
            System.out.println();
            System.out.println("Registering: " + files[i].toString()
                  + "  " + (i+1) + " of " + files.length);
            log.println("Registering: " + files[i].toString());

            BufferedReader br = new BufferedReader(new FileReader(dir + files[i]));

            
            String first_line = br.readLine();
            br.close();
            if (first_line.startsWith("<?XML"))
            {
               current_geko = KnowledgeFrame.readXML(new File(dir + files[i]));
               register_xml_geko(current_geko, log);
            }
            else
            {
               GEKOStreamView v = new GEKOStreamView(GEKOStreamView.IN, new File(dir + files[i]));
               current_geko = v.input();
               v.close();
               register_khi_geko(current_geko, log);
            }
         }
         catch (Exception e)
         {
            log.println("*** Error: " + e.getMessage());
            System.out.println("*** Error: " + e.getMessage());
            //e.printStackTrace();
         }
         catch (Throwable t)
         {
            log.println("*** Throw: " + t.getMessage());
            System.out.println("*** Throw: " + t.getMessage());
            //t.printStackTrace();
         }
      }
      log.close();
      return;
   }

   /**
   * Does all the work of ensuring that the shared sub-frames of a new
   * GEKO are indeed shared.
   */
   private void register_khi_geko(KnowledgeFrame geko, PrintWriter log)
         throws FrameException, IOException, Exception
   {
      KnowledgeFrame source, technical, knowledge, author, variable, citation, keyword;
      KnowledgeList ivars, cits, kwords;
      String key;
      int i;

      source = (KnowledgeFrame)geko.get("Source Frame");
      author = (KnowledgeFrame)source.get("Author");
      technical = (KnowledgeFrame)geko.get("Technical Frame");
      knowledge = (KnowledgeFrame)geko.get("Knowledge Frame");

      switch (gekos.check_geko((String)source.get("Title"), geko))
      {
      case GEKOClientI.NEW_OK:
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("CANCEL: A GEKO with the same title already exists in the archive");
         log.println("CANCEL: A GEKO with the same title already exists in the archive: " + geko.summary());
         return;
      case GEKOClientI.OLD_OK:
         System.out.println("This GEKO has already been uploaded to the archive.");
         log.println("This GEKO has already been uploaded to the archive:" + geko.summary());
         //String answer = prompt("Continue to update existing copy with this version? (y/n)");
         //if (answer.equals("n"))
            return;
         //break;
      case GEKOClientI.OLD_MOD:
         System.out.println("CANCEL: This GEKO is an old version of an archive GEKO");
         log.println("CANCEL: This GEKO is an old version of an archive GEKO: " + geko.summary());
         return;
      }

      switch (gekos.check_author((String)author.get("Name"), author))
      {
      case GEKOClientI.NEW_OK:
         System.out.println("Adding new author");
         log.println("Adding new author: " + author.summary());
         key = gekos.put_frame(author);
         author = gekos.get_frame("person", key);
         source.set("Author", author);
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("Using author of same name from archive");
         log.println("Using author of same name from archive: " + author.summary());
         author = simple_query("person", "Name", (String)author.get("Name"));
         source.set("Author", author);
         break;
      case GEKOClientI.OLD_MOD:
         System.out.println("Using latest version of this author from archive.");
         log.println("Using latest version of this author from archive: " + author.summary());
         author = gekos.get_frame("person", author.get_key());
         source.set("Author", author);
         break;
      }

      ivars = (KnowledgeList)knowledge.get("Dependent Variables");
      for (i=0; i < ivars.length(); i++)
      {
         KnowledgeSlot s = ivars.slot_at(i);
         variable = (KnowledgeFrame)s.value();
         switch (gekos.check_variable((String)variable.get("Name"), variable))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new dependent variable");
            log.println("Adding new dependent variable: " + variable.summary());
            key = put_variable(variable);
            variable = gekos.get_frame("variable", key);
            s.set_value(variable);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using variable of same name from archive");
            log.println("Using variable of same name from archive: " + variable.summary());
            variable = simple_query("variable", "Name", (String)variable.get("Name"));
            s.set_value(variable);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this variable from archive.");
            log.println("Using latest version of this variable from archive: " + variable.summary());
            variable = gekos.get_frame("variable", variable.get_key());
            s.set_value(variable);
            break;
         }
      }

      ivars = (KnowledgeList)knowledge.get("Independent Variables");
      for (i=0; i < ivars.length(); i++)
      {
         KnowledgeSlot s = ivars.slot_at(i);
         variable = (KnowledgeFrame)s.value();
         switch (gekos.check_variable((String)variable.get("Name"), variable))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new independent variable: " + variable.summary());
            log.println("Adding new independent variable");
            key = put_variable(variable);
            variable = gekos.get_frame("variable", key);
            s.set_value(variable);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using variable of same name from archive");
            log.println("Using variable of same name from archive: " + variable.summary());
            variable = simple_query("variable", "Name", (String)variable.get("Name"));
            s.set_value(variable);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this variable from archive.");
            log.println("Using latest version of this variable from archive: " + variable.summary());
            variable = gekos.get_frame("variable", variable.get_key());
            s.set_value(variable);
            break;
         }
      }

      if (knowledge.slot_exists("Major Controlled Variables"))
      {
         ivars = (KnowledgeList)knowledge.get("Major Controlled Variables");
         for (i=0; i < ivars.length(); i++)
         {
            KnowledgeSlot s = ivars.slot_at(i);
            variable = (KnowledgeFrame)s.value();
            switch (gekos.check_variable((String)variable.get("Name"), variable))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new controlled variable");
               log.println("Adding new controlled variable: " + variable.summary());
               key = put_variable(variable);
               variable = gekos.get_frame("variable", key);
               s.set_value(variable);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using variable of same name from archive");
               log.println("Using variable of same name from archive: " + variable.summary());
               variable = simple_query("variable", "Name", (String)variable.get("Name"));
               s.set_value(variable);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this variable from archive.");
               log.println("Using latest version of this variable from archive: " + variable.summary());
               variable = gekos.get_frame("variable", variable.get_key());
               s.set_value(variable);
               break;
            }
         }
      }

      if (source.slot_exists("Source Citations"))
      {
         cits = (KnowledgeList)source.get("Source Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new citation");
               log.println("Adding new citation: " + citation.summary());
               key = gekos.put_frame(citation);
               citation = gekos.get_frame("citation", key);
               s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using citation of same name from archive");
               log.println("Using citation of same name from archive: " + citation.summary());
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this citation from archive.");
               log.println("Using latest version of this citation from archive: " + citation.summary());
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }
      else
         knowledge.set("Source Citations", new KnowledgeList());


      if (source.slot_exists("Support Citations"))
      {
         cits = (KnowledgeList)source.get("Support Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new citation");
               log.println("Adding new citation: " + citation.summary());
               key = gekos.put_frame(citation);
               citation = gekos.get_frame("citation", key);
               s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using citation of same name from archive");
               log.println("Using citation of same name from archive: " + citation.summary());
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this citation from archive.");
               log.println("Using latest version of this citation from archive: " + citation.summary());
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }
      else
         knowledge.set("Support Citations", new KnowledgeList());

      kwords = (KnowledgeList)source.get("Keywords");
      for (i=0; i < kwords.length(); i++)
      {
         KnowledgeSlot s = kwords.slot_at(i);
         keyword = (KnowledgeFrame)s.value();
         switch (gekos.check_keyword((String)keyword.get("word"), keyword))
         {
         case GEKOClientI.NEW_OK:
            System.out.println("Adding new keyword");
            log.println("Adding new keyword: " + keyword.summary());
            key = gekos.put_frame(keyword);
            keyword = gekos.get_frame("keyword", key);
            s.set_value(keyword);
            break;
         case GEKOClientI.NEW_DUP:
            System.out.println("Using keyword of same name from archive");
            log.println("Using keyword of same name from archive: " + keyword.summary());
            keyword = simple_query("keyword", "word", (String)keyword.get("word"));
            s.set_value(keyword);
            break;
         case GEKOClientI.OLD_MOD:
            System.out.println("Using latest version of this keyword from archive.");
            log.println("Using latest version of this keyword from archive: " + keyword.summary());
            keyword = gekos.get_frame("keyword", keyword.get_key());
            s.set_value(keyword);
            break;
         }
      }

System.out.println("*done with all the other shared frames*");
      knowledge.set("Type", "khi");
      knowledge.set("Dependent Variables", new KnowledgeList());
      knowledge.set("Independent Variables", new KnowledgeList());
      knowledge.set("Model System Variables", new KnowledgeList());
      knowledge.set("Controlled Variables", new KnowledgeList());
      knowledge.set("Declared Variables", new KnowledgeList());

      if (! knowledge.slot_exists("Controls"))
         knowledge.set("Controls", "");
      if (! knowledge.slot_exists("Model System"))
         knowledge.set("Model System", "");
      if (! knowledge.slot_exists("Declared Relations"))
         knowledge.set("Declared Relations", "");

      if (! technical.slot_exists("Peer Review(s)"))
         technical.set("Peer Review(s)", new KnowledgeList());
      if (! technical.slot_exists("Usage Log"))
         technical.set("Usage Log", new KnowledgeList());
      if (! source.slot_exists("Source Citations"))
         source.set("Source Citations", new KnowledgeList());
      if (! source.slot_exists("Support Citations"))
         source.set("Support Citations", new KnowledgeList());

      String c = (String)knowledge.get("Code");

      // GEKOStreamView now creates both this mcv slot and simply
      // controls, which is a comment.
      knowledge.remove("Major Controlled Variables");

System.out.println("*old code looks like:*");
System.out.println(c);
      if (khip == null)
         khip = new KHIParser(
            new StringReader(c));
      else
         khip.ReInit(new StringReader(c));

      c = khip.read_code();
      knowledge.set("Code", c);
System.out.println("*new code looks like:");
System.out.println(c);
System.out.println("* *");

      gekos.put_frame(geko);
   }

   /**
   * Does all the work of ensuring that the shared sub-frames of a new
   * GEKO are indeed shared.
   */
   private void register_xml_geko(KnowledgeFrame geko, PrintWriter log)
         throws FrameException, IOException, Exception
   {
      KnowledgeFrame source, technical, knowledge, author, variable, citation, keyword;
      KnowledgeFrame local_variable;
      KnowledgeList ivars, cits, kwords;
      String key;
      int i;

      source = (KnowledgeFrame)geko.get("Source Frame");
      author = (KnowledgeFrame)source.get("Author");
      technical = (KnowledgeFrame)geko.get("Technical Frame");
      knowledge = (KnowledgeFrame)geko.get("Knowledge Frame");

      switch (gekos.check_geko((String)source.get("Title"), geko))
      {
      case GEKOClientI.NEW_OK:
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("CANCEL: A GEKO with the same title already exists in the archive");
         log.println("CANCEL: A GEKO with the same title already exists in the archive: " + geko.summary());
         return;
      case GEKOClientI.OLD_OK:
         System.out.println("This GEKO has already been uploaded to the archive.");
         log.println("This GEKO has already been uploaded to the archive:" + geko.summary());
         //String answer = prompt("Continue to update existing copy with this version? (y/n)");
         //if (answer.equals("n"))
            return;
         //break;
      case GEKOClientI.OLD_MOD:
         System.out.println("CANCEL: This GEKO is an old version of an archive GEKO");
         log.println("CANCEL: This GEKO is an old version of an archive GEKO: " + geko.summary());
         return;
      }

      switch (gekos.check_author((String)author.get("Name"), author))
      {
      case GEKOClientI.NEW_OK:
         System.out.println("Adding new author");
         log.println("Adding new author: " + author.summary());
         key = gekos.put_frame(author);
         author = gekos.get_frame("person", key);
         source.set("Author", author);
         break;
      case GEKOClientI.NEW_DUP:
         System.out.println("Using author of same name from archive");
         log.println("Using author of same name from archive: " + author.summary());
         author = simple_query("person", "Name", (String)author.get("Name"));
         source.set("Author", author);
         break;
      case GEKOClientI.OLD_MOD:
         System.out.println("Using latest version of this author from archive.");
         log.println("Using latest version of this author from archive: " + author.summary());
         author = gekos.get_frame("person", author.get_key());
         source.set("Author", author);
         break;
      }

      String[] var_slots =
      {
         "Dependent Variables",
         "Independent Variables",
         "Model System Variables",
         "Controlled Variables",
         "Declared Variables"
      };

      int j;
      for (j=0; j<var_slots.length; j++)
      {
         if (knowledge.slot_exists(var_slots[j]))
         {
            ivars = (KnowledgeList)knowledge.get(var_slots[j]);
            for (i=0; i < ivars.length(); i++)
            {
               KnowledgeSlot s = ivars.slot_at(i);
               local_variable = (KnowledgeFrame)s.value();
               variable = (KnowledgeFrame)local_variable.get("Archive Variable");
               switch (gekos.check_variable((String)variable.get("Name"), variable))
               {
               case GEKOClientI.NEW_OK:
                  System.out.println("Adding new variable");
                  log.println("Adding new variable: " + variable.summary());
                  key = put_variable(variable);
                  variable = gekos.get_frame("variable", key);
                  s.set_value(variable);
                  break;
               case GEKOClientI.NEW_DUP:
                  System.out.println("Using variable of same name from archive");
                  log.println("Using variable of same name from archive: " + variable.summary());
                  variable = simple_query("variable", "Name", (String)variable.get("Name"));
                  s.set_value(variable);
                  break;
               case GEKOClientI.OLD_MOD:
                  System.out.println("Using latest version of this variable from archive.");
                  log.println("Using latest version of this variable from archive: " + variable.summary());
                  variable = gekos.get_frame("variable", variable.get_key());
                  s.set_value(variable);
                  break;
               }
            }
         }
      }

      if (source.slot_exists("Source Citations"))
      {
         cits = (KnowledgeList)source.get("Source Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new citation");
               log.println("Adding new citation: " + citation.summary());
               key = gekos.put_frame(citation);
               citation = gekos.get_frame("citation", key);
               s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using citation of same name from archive");
               log.println("Using citation of same name from archive: " + citation.summary());
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this citation from archive.");
               log.println("Using latest version of this citation from archive: " + citation.summary());
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }
      else
         knowledge.set("Source Citations", new KnowledgeList());


      if (source.slot_exists("Support Citations"))
      {
         cits = (KnowledgeList)source.get("Support Citations");
         for (i=0; i < cits.length(); i++)
         {
            KnowledgeSlot s = cits.slot_at(i);
            citation = (KnowledgeFrame)s.value();
            switch (gekos.check_citation((String)citation.get("Body"), citation))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new citation");
               log.println("Adding new citation: " + citation.summary());
               key = gekos.put_frame(citation);
               citation = gekos.get_frame("citation", key);
               s.set_value(citation);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using citation of same name from archive");
               log.println("Using citation of same name from archive: " + citation.summary());
               citation = simple_query("citation", "Body", (String)citation.get("Body"));
               s.set_value(citation);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this citation from archive.");
               log.println("Using latest version of this citation from archive: " + citation.summary());
               citation = gekos.get_frame("citation", citation.get_key());
               s.set_value(citation);
               break;
            }
         }
      }
      else
         knowledge.set("Support Citations", new KnowledgeList());

      if (source.slot_exists("Keywords"))
      {
         kwords = (KnowledgeList)source.get("Keywords");
         for (i=0; i < kwords.length(); i++)
         {
            KnowledgeSlot s = kwords.slot_at(i);
            keyword = (KnowledgeFrame)s.value();
            switch (gekos.check_keyword((String)keyword.get("word"), keyword))
            {
            case GEKOClientI.NEW_OK:
               System.out.println("Adding new keyword");
               log.println("Adding new keyword: " + keyword.summary());
               key = gekos.put_frame(keyword);
               keyword = gekos.get_frame("keyword", key);
               s.set_value(keyword);
               break;
            case GEKOClientI.NEW_DUP:
               System.out.println("Using keyword of same name from archive");
               log.println("Using keyword of same name from archive: " + keyword.summary());
               keyword = simple_query("keyword", "word", (String)keyword.get("word"));
               s.set_value(keyword);
               break;
            case GEKOClientI.OLD_MOD:
               System.out.println("Using latest version of this keyword from archive.");
               log.println("Using latest version of this keyword from archive: " + keyword.summary());
               keyword = gekos.get_frame("keyword", keyword.get_key());
               s.set_value(keyword);
               break;
            }
         }
      }

      knowledge.set("Dependent Variables", new KnowledgeList());
      knowledge.set("Independent Variables", new KnowledgeList());
      knowledge.set("Model System Variables", new KnowledgeList());
      knowledge.set("Controlled Variables", new KnowledgeList());
      knowledge.set("Declared Variables", new KnowledgeList());

      if (! technical.slot_exists("Peer Review(s)"))
         technical.set("Peer Review(s)", new KnowledgeList());
      if (! technical.slot_exists("Usage Log"))
         technical.set("Usage Log", new KnowledgeList());
      if (! source.slot_exists("Source Citations"))
         source.set("Source Citations", new KnowledgeList());
      if (! source.slot_exists("Support Citations"))
         source.set("Support Citations", new KnowledgeList());
      if (! source.slot_exists("Keywords"))
         source.set("Keywords", new KnowledgeList());
      if (! knowledge.slot_exists("Declared Relations"))
         knowledge.set("Declared Relations", "");
      if (! knowledge.slot_exists("Model System"))
         knowledge.set("Model System", "");
      if (! knowledge.slot_exists("Controls"))
         knowledge.set("Controls", "");

      gekos.put_frame(geko);
   }

   private String put_variable(KnowledgeFrame variable) throws FrameException
   {
      String key;
      String type = (String)variable.get("Type");

      if (type.equalsIgnoreCase("string"))
         variable.set("Type", "string");
      else if (type.equalsIgnoreCase("boolean"))
         variable.set("Type", "boolean");
      else if (type.equalsIgnoreCase("number"))
         variable.set("Type", "float");
      variable.set("Single Valued", "true");

      variable.set("Menu", "");
      variable.set("Choices", "");

      if (!variable.slot_exists("Description"))
         variable.set("Description", "");

      key = gekos.put_frame(variable);
      return key;
   }

   /* --------- */
   /* Utilities
   /* --------- */

   // Present a numbered list of the notes in a vector of key note pairs,
   // return the key associated with the user selected note.
   private String list_select(Vector list) throws IOException
   {
      int i=1;

      Enumeration e = list.elements();
      while (e.hasMoreElements())
         System.out.println(i++ + ": " + ((KeyNotePair)e.nextElement()).summary());
      System.out.print("\nList Item Number (0 for none)> ");
      i = Integer.parseInt(din.readLine());
      if (i == 0)
         return null;
      else
         return ((KeyNotePair)list.elementAt(i-1)).get_key();
   }

   // Present a numbered list of the strings for the
   // user to select from.
   private String string_list_select(Vector list) throws IOException
   {
      int i=1;

      Enumeration e = list.elements();
      while (e.hasMoreElements())
         System.out.println(i++ + ": " + (String)e.nextElement());
      System.out.print("\nList Item Number (0 for none)> ");
      i = Integer.parseInt(din.readLine());
      if (i == 0)
         return null;
      else
         return (String)list.elementAt(i-1);
   }

   private String prompt(String p) throws IOException
   {
      return prompt(p, 0);
   }

   private String prompt(String p, int dent) throws IOException
   {
      for (int j=0; j<dent; j++) System.out.print(" ");
      System.out.print(p);
      return din.readLine();
   }

   /**
   * Find a knowledge frame based on a query in which a single slot is
   * compared against a single value.  Return just the first if there
   * are multiple solutions.
   */
   private KnowledgeFrame simple_query(String group, String slot_name, String value)
         throws FrameException
   {
      // Create a new query frame for the group.
      QueryFrame qf = new QueryFrame(group);

      // Set a query slot pattern match for the simple equals case.
      qf.set(slot_name, new QueryOp(QueryOp.EQUALS, value));

      // The query returns a vector of key_note_pairs that
      // satisfy the query.  We'll just take the first one
      // or return null.
      Vector answers = gekos.query(qf);
      if (answers.isEmpty())
         return null;
      
      // Retrieve the desired frame.
      String key = ((KeyNotePair)answers.firstElement()).get_key();
      return gekos.get_frame(group, key);
   }
}