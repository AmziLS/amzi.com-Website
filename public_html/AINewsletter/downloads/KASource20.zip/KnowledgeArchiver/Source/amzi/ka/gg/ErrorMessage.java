package amzi.ka.gg;

import javax.swing.*;
import java.awt.*;


public class ErrorMessage {
    public static final int EM_NO_SCHEMA = 0;    
    public static final int EM_OBJECT_CREATION_PROBLEM = 1;
    public static final int EM_SERVER_CONNECT = 2;
    public static final int EM_SERVER_DISCONNECT = 3;
    public static final int EM_ARCHIVE_OPEN = 4;
    public static final int EM_ARCHIVE_CREATE = 5;
    public static final int EM_VERIFY_LOGIN = 6;
    public static final int EM_NOT_LIST_ITEM = 7;
    public static final int EM_BAD_ITEM = 8;
    public static final int EM_UPLOAD_ERROR = 9;
    public static final int EM_IO_PROBLEM = 10;
    public static final int EM_QUERY_ERROR = 11;
    public static final int EM_QUERY_SIZE_ERROR = 12;
    public static final int EM_QUERY_FORM_ERROR = 13;
    public static final int EM_VERIFY_ERROR = 14;
    public static final int EM_UPLOAD_COMPILE_ERROR = 15;
    public static final int EM_SLOT_SELECTION_ERROR = 16;
    public static final int EM_BAD_HYPERLINK_ERROR = 17;
    
    private static String msgs[] = 
    {
    "No Schema source defined: either log in to an archive or open a local Schema file",
    "Problem creating object",
    "Cannot connect to server ",
    "Cannot disconnect from server",
    "Cannot open archive ",
    "Cannot create archive ",
    "Cannot verify Geko - you are not logged in",
    "A list item must be selected",
    "Selected item must a knowledge list or a knowledge frame from an archived group",
    "Problem uploading frame",
    "File system problem ",
    "Problem with query ",
    "Queries can have at most one constraint in the current version",
    "Bad query: ",
    "GEKO didn't verify, upload cancelled.",
    "GEKO upload/compile error: ",
    "You must have a slot selected",
    "Cannot find hyperlink target"
    };

    public static MainFrame MF=null;  //dcm2

    public static void message(Component parent, int msgid, Object info)                           
    {     
        if (null != MF) {
           MF.log_writeln("---Error Message---");
           MF.log_writeln( "[" + msgid + "] " + msgs[msgid] + 
                   ((null == info) ? ""  : (String)info) );
           MF.log_writeln("---");
        }
        
        JOptionPane.showMessageDialog(parent, "[" + msgid + "] " + msgs[msgid] + 
                   ((null == info) ? ""  : (String)info), "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public static void message(Component parent, int msgid)
    {
        message(parent, msgid, null);
    }
    //dcm2
    public static void show(String text)
    {
       if (MF != null)
       {
          MF.log_writeln("---Message---");
          MF.log_writeln(text);
          MF.log_writeln("---");
       }

       JOptionPane.showMessageDialog(
          MF, text, "Warning", JOptionPane.WARNING_MESSAGE);            
    }    
}