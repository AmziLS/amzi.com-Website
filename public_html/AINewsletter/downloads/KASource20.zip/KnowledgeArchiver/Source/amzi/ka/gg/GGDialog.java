package amzi.ka.gg;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class GGDialog implements ActionListener {
    
    public final static int OK_DIALOG = 1;
    public final static int OK_CANCEL_DIALOG = 2;
    public final static int OK_CANCEL_SELECT_DIALOG = 3;
    public final static int OK_CANCEL_QUERY_DIALOG = 4;
    
    private String m_value = null;    
    private JDialog m_dialog = null;
    private JFrame m_frame = null;
    private int m_dialogtype;
    private PropertyChangeSupport m_property_change;
    private boolean m_autoclose;
    private JComponent m_selection;
    
    public GGDialog(int dialogtype, String title, String msg, JComponent pane, 
                        JComponent selection) 
    {
        this(dialogtype, title, msg, pane, selection, true);
    }
    
    public GGDialog(int dialogtype, String title, String msg, JComponent pane, 
                        JComponent selection, boolean autoclose) {
        Container c;
        JPanel buttonpanel;
        JFrame frame;
        JButton b;
        boolean modal;  
        final boolean ac = autoclose;
        modal = autoclose;
        m_autoclose = autoclose;
        
        m_property_change = new PropertyChangeSupport(this);
        m_selection = selection;    
        m_dialog = new JDialog(m_frame = new JFrame(), title, modal);
        c = m_dialog.getContentPane();
        c.setLayout(new BorderLayout(5, 0));
        
        buttonpanel = new JPanel(new FlowLayout());
        buttonpanel.add(b = new JButton("OK"));
        b.addActionListener(this);
        m_dialogtype = dialogtype;
        if (dialogtype == OK_CANCEL_DIALOG) {
            buttonpanel.add( b = new JButton("Cancel"));   
            b.addActionListener(this);            
        } else if (dialogtype == OK_CANCEL_SELECT_DIALOG) {
            buttonpanel.add(b = new JButton("Cancel"));        
            b.addActionListener(this);               
            buttonpanel.add(b = new JButton("Select"));               
            b.addActionListener(this);               
        } else if (dialogtype == OK_CANCEL_QUERY_DIALOG) {
            buttonpanel.add(b = new JButton("Cancel"));        
            b.addActionListener(this);               
            buttonpanel.add(b = new JButton("Query"));               
            b.addActionListener(this);               
        } 
        c.add("South", buttonpanel);
        if (null != pane) {
            c.add("Center", pane);
        } 
        if (null != msg) {
            c.add("North", new JLabel(msg));
        }

        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    if (m_dialogtype == OK_DIALOG || m_dialogtype == OK_CANCEL_DIALOG) {
                        m_value = "OK";
                    } else if (m_dialogtype == OK_CANCEL_SELECT_DIALOG) {
                        m_value = "Select";
                    } else if (m_dialogtype == OK_CANCEL_QUERY_DIALOG) {
                        m_value = "Select";
                    } else
                        m_value = null;
                    if (ac)
                        close();
                    else
                        m_property_change.firePropertyChange("select", null, m_selection);
                }
            }
        };
        if (null != selection)        
            selection.addMouseListener(mouseListener);
        m_dialog.pack();
        m_dialog.setLocationRelativeTo(m_frame);
        m_dialog.setVisible(true);
    }
    
    public void setValue(String val) {
        m_value = val;
    }
    
    public String getValue() {
        return m_value;
    }
  
    private void close() {
        m_dialog.setVisible(false);
        m_dialog.dispose();  
    }
    
    public PropertyChangeSupport getPropertyChange() {
        return m_property_change;
    }
    
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        m_value = cmd;
        if (m_autoclose || ("Cancel".equals(cmd)))
            close();
        else
            m_property_change.firePropertyChange("select", null, m_selection);        
    }
    
}