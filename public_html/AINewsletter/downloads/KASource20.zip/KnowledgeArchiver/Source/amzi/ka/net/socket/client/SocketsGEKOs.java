// RemoteGEKOs.java

package amzi.ka;

import amzi.frames.*;
import amzi.ka.*;
import java.net.*;
import java.io.*;
import java.util.*;

// This file had changes made to connect and logon, but is
// the same as it was, if we ever want to go back to sockets
// for the implementation.
public class RemoteGEKOs implements GEKOLibrary
{
   private Socket sock;
   private ObjectInputStream in;
   private ObjectOutputStream out;

   public RemoteGEKOs()
   {
   }

   public void logon(KnowledgeFrame f) throws FrameException
   {
      if (li == null)
         throw new KAFrameException(this, KAFrameException.NO_CONNECTION);
      gi = li.logon(f);
   }

  /**
  * Check to see if a geko exists for the given title.
  * @param title The title string.
  * @param geko The frame to compare against.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_geko(String title, KnowledgeFrame geko) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = title;
      args[1] = geko;
      return ((Integer)send_reply_message(KAMessage.CHECK_GEKO, args)).intValue();
   }


  /**
  * Check to see if an author exists with the given name.
  * @param name The name string.
  * @param author The frame to compare against.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_author(String name, KnowledgeFrame author) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = name;
      args[1] = author;
      return ((Integer)send_reply_message(KAMessage.CHECK_AUTHOR, args)).intValue();
   }


  /**
  * Check to see if a variable exists with the given name.
  * @param name The name string.
  * @param variable The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_variable(String name, KnowledgeFrame variable) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = name;
      args[1] = variable;
      return ((Integer)send_reply_message(KAMessage.CHECK_VARIABLE, args)).intValue();
   }


  /**
  * Check to see if a citation exists with the given body.
  * @param body The body string.
  * @param citation The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_citation(String body, KnowledgeFrame citation) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = body;
      args[1] = citation;
      return ((Integer)send_reply_message(KAMessage.CHECK_CITATION, args)).intValue();
   }


  /**
  * Check to see if a keyword exists with the given body.
  * @param item The keyword string.
  * @param keyword The frame to compare.
  * @return new_OK, new_DUP, old_OK or old_MOD.
  */
  public int check_keyword(String item, KnowledgeFrame keyword) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = item;
      args[1] = keyword;
      return ((Integer)send_reply_message(KAMessage.CHECK_KEYWORD, args)).intValue();
   }


   // The KnowledgeLibrary interface

   /**
   * Creates a new Knowledge Library.
   */
   public void initialize() throws FrameException
   {
      send_no_reply_message(KAMessage.INITIALIZE);
   }

   /**
   * Connect to the server
   */
   public void connect(String addr) throws FrameException
   {
      String host;
      String port;
      int i = addr.indexOf(':');

      if (i >= 0)
      {
         host = addr.substring(0, i);
         port = addr.substring(i+1);
      }
      else
      {
         host = addr;
         port = "1099";
      }
      connect(host, port);
   }

   /**
   * Connect to the server
   */
   public void connect(String host, String port) throws FrameException
   {
      connect(host, port, null, null);
   }

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port, String proxy_host, String proxy_port) throws FrameException
   {
      if ( proxy_host != null )
      {
         System.getProperties().put( "http.proxySet", "true" );
         System.getProperties().put( "http.proxyHost", proxy_host );
         System.getProperties().put( "http.proxyPort", proxy_port );
      }

      try
      {
         System.setSecurityManager(new RMISecurityManager());
         li = (LogonI)Naming.lookup("rmi://" + host + ":" + port + "/KA");
      }
      catch (RemoteException e)
      {
         throw new KAFrameException(this, KAFrameException.REMOTE_EXCEPTION, e.getMessage());
      }
      catch (MalformedURLException e)
      {
         throw new KAFrameException(this, KAFrameException.MALFORMED_URL_EXCEPTION, e.getMessage());
      }
      catch (NotBoundException e)
      {
         throw new KAFrameException(this, KAFrameException.NOT_BOUND_EXCEPTION, e.getMessage());
      }
   }

   /**
   * Creates a new Knowledge Library.
   */
   public void create(String db_name) throws FrameException
   {
      send_no_reply_message(KAMessage.CREATE, db_name);
   }

   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException
   {
      send_no_reply_message(KAMessage.OPEN, db_name);
   }

   /**
   * Close an open Knowledge Library.
   */
   public void close() throws FrameException
   {
      send_no_reply_message(KAMessage.CLOSE);
   }

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException
   {
      send_no_reply_message(KAMessage.ADD_GROUP, group);
   }

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException
   {
      return (Vector)send_reply_message(KAMessage.GET_GROUPS);
   }

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException
   {
      return (String)send_reply_message(KAMessage.PUT_FRAME, f);
   }

   /**
   * Remove a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException
   {
      return send_reply_message(KAMessage.REMOVE_FRAME, f);
   }

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException
   {
      Object[] args = new Object[2];
      args[0] = group;
      args[1] = key;
      return (KnowledgeFrame)send_reply_message(KAMessage.GET_FRAME, args);
   }

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException
   {
      return (Vector)send_reply_message(KAMessage.GET_KEY_NOTES, group);
   }

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException
   {
      return (Vector)send_reply_message(KAMessage.QUERY, qf);
   }


   // Utility functions
   // -----------------

   private void send_no_reply_message(int message_id) throws FrameException
   {
      send_no_reply_message(message_id, null);
   }

   private void send_no_reply_message(int message_id, Object argument) throws FrameException
   {
      try
      {
         out.reset();
         out.writeObject(new KAMessage(message_id, argument));
         KAMessage received = (KAMessage)in.readObject();
         switch (received.get_message_id())
         {
         case KAMessage.ERROR:
            throw (FrameException)received.get_argument();
         case KAMessage.OK:
            return;
         default:
           throw new KAFrameException(this, KAFrameException.PROTOCOL);
         }
      }
      catch (IOException e)
      {
         throw new KAFrameException(this, KAFrameException.SOCKET_IO, e.toString());
      }
      catch (ClassNotFoundException e)
      {
         throw new KAFrameException(this, KAFrameException.NO_CLASS, e.toString());
      }
   }

   private Object send_reply_message(int message_id) throws FrameException
   {
      return send_reply_message(message_id, null);
   }

   private Object send_reply_message(int message_id, Object argument) throws FrameException
   {
      try
      {
         // A learning experience, the ObjectOutputStream remembers old objects
         // and reuses them, so if you modify an object and resend it, the old
         // copy gets sent instead unless you 'reset()' the stream first.
         out.reset();
         out.writeObject(new KAMessage(message_id, argument));
         KAMessage received = (KAMessage)in.readObject();
         switch (received.get_message_id())
         {
         case KAMessage.ERROR:
            throw (FrameException)received.get_argument();
         case KAMessage.OK:
            return received.get_argument();
         default:
           throw new KAFrameException(this, KAFrameException.PROTOCOL);
         }
      }
      catch (IOException e)
      {
         throw new KAFrameException(this, KAFrameException.SOCKET_IO, e.toString());
      }
      catch (ClassNotFoundException e)
      {
         throw new KAFrameException(this, KAFrameException.NO_CLASS, e.toString());
      }
   }
}
