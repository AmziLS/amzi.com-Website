/**
 * KAThread
 *
 * @author  Amzi! inc.
 */

package amzi.ka.server;

import amzi.frames.*;
import amzi.ka.*;
import java.io.*;
import java.net.*;
import java.util.*;
import COM.odi.*;
import COM.odi.util.*;

class KAThread extends Thread
{
   Socket sock = null;
   ObjectInputStream in = null;
   ObjectOutputStream out = null;
   GEKOLibrary gekos;
   Thread main_thread;

   public KAThread(Socket s, GEKOLibrary gl, Thread calling_thread) throws FrameException
   {
      sock = s;
      gekos = gl;
      main_thread = calling_thread;
   }

   public void run()
   {
      Object obj;
      KAMessage message;
      KAMessage ok_message = new KAMessage(KAMessage.OK);
      Vector v;
      String id;
      Object[] args;
      KnowledgeFrame kf;
      int i;

      if (! ObjectStore.initialize(main_thread))
      {
         System.out.println("OS initialize returns false");
         return;
      }

      try
      {
         out = new ObjectOutputStream(sock.getOutputStream());
         in = new ObjectInputStream(sock.getInputStream());

         System.out.println("KAThread running");

         while (null != (message = (KAMessage)in.readObject()))
         {
            System.out.println(message.get_message_id());
            try
            {
               switch (message.get_message_id())
               {
               // GEKOLibrary extension functions
               case KAMessage.LOGON:
                  gekos.logon((KnowledgeFrame)message.get_argument());
                  out.writeObject(ok_message);
                  break;
               case KAMessage.CHECK_GEKO:
                  args = (Object[])message.get_argument();
                  i = gekos.check_geko((String)args[0], (KnowledgeFrame)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, new Integer(i)));
                  break;
               case KAMessage.CHECK_AUTHOR:
                  args = (Object[])message.get_argument();
                  i = gekos.check_author((String)args[0], (KnowledgeFrame)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, new Integer(i)));
                  break;
               case KAMessage.CHECK_VARIABLE:
                  args = (Object[])message.get_argument();
                  i = gekos.check_variable((String)args[0], (KnowledgeFrame)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, new Integer(i)));
                  break;
               case KAMessage.CHECK_CITATION:
                  args = (Object[])message.get_argument();
                  i = gekos.check_citation((String)args[0], (KnowledgeFrame)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, new Integer(i)));
                  break;
               case KAMessage.CHECK_KEYWORD:
                  args = (Object[])message.get_argument();
                  i = gekos.check_keyword((String)args[0], (KnowledgeFrame)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, new Integer(i)));
                  break;

               // KnowledgeLibrary functions

               case KAMessage.INITIALIZE:
                  gekos.initialize();
                  out.writeObject(ok_message);
                  break;
               case KAMessage.CREATE:
                  gekos.create((String)message.get_argument());
                  out.writeObject(ok_message);
                  break;
               case KAMessage.OPEN:
                  gekos.open((String)message.get_argument());
                  out.writeObject(ok_message);
                  break;
               case KAMessage.CLOSE:
                  gekos.close();
                  out.writeObject(ok_message);
                  break;

               case KAMessage.ADD_GROUP:
                  gekos.add_group((String)message.get_argument());
                  out.writeObject(ok_message);
                  break;
               case KAMessage.GET_GROUPS:
                  v = gekos.get_groups();
                  out.writeObject(new KAMessage(KAMessage.OK, v));
                  break;

               case KAMessage.PUT_FRAME:
                  id = gekos.put_frame((KnowledgeFrame)message.get_argument());
                  out.writeObject(new KAMessage(KAMessage.OK, id));
                  break;
               case KAMessage.GET_FRAME:
                  args = (Object[])message.get_argument();
                  kf = gekos.get_frame((String)args[0], (String)args[1]);
                  out.writeObject(new KAMessage(KAMessage.OK, kf));
                  break;

               case KAMessage.GET_KEY_NOTES:
                  v = gekos.get_key_notes((String)message.get_argument());
                  out.writeObject(new KAMessage(KAMessage.OK, v));
                  break;
               case KAMessage.QUERY:
                  v = gekos.query((QueryFrame)message.get_argument());
                  out.writeObject(new KAMessage(KAMessage.OK, v));
                  break;
               default:
                  throw new KAFrameException(this, KAFrameException.BAD_COMMAND);
               }
            }
            catch (FrameException e)
            {
               out.writeObject(new KAMessage(KAMessage.ERROR, e));
            }
         }
      }
      catch(IOException e)
      {
         System.out.println("arghh " + e.getMessage());
         System.out.println("KAThread IO Error" + e.getMessage());
      }
      catch (ClassNotFoundException e)
      {
         System.out.println("arghh " + e.getMessage());
         System.out.println("KAThread: ClassNotFoundException");
      }
      finally
      {
         try
         {
            if (out != null)
               out.close();
            if (in != null)
               in.close();
            if (sock != null)
               sock.close();
         }
         catch (IOException e)
         {
            System.out.println("arghh " + e.getMessage());
            System.out.println("KAThread: IO Error closing down");
         }

         System.out.println("Client gone");
         System.out.print("KAServer>");
      }
   }
}