package amzi.ka.gg;

import amzi.frames.*;
import javax.swing.*;
import java.awt.*;
import java.beans.*;


public interface BrowserContainer extends PropertyChangeListener {
    public Browser addNewBrowser(KnowledgeFrame lg, String group);   
    public Browser addNewBrowser(String group); 
    public void register(JInternalFrame f);
    public void deregister(JInternalFrame f);
    public void openedArchive(Session session, String name);
    public void closedArchive(Session session);
    public void openedSession(Session session);
    public Session getSession();
    public void setSchemaSource(SchemaSource s);
    public SchemaSource getSchemaSource();
    public PropertyChangeSupport getPropertyChange();
    public void notifyGroupChange(String groupname);    
    public Cursor getCursor();
    public void setCursor(Cursor c);
}