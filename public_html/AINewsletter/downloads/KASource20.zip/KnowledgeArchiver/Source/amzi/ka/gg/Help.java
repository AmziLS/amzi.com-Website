package amzi.ka.gg;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.Vector;

/** 
* A poor man's browser. Follow links by clicking. Return by hitting
* backspace or the B key or the back button. Thats all folks.
*/
public class Help implements HyperlinkListener, KeyListener, ActionListener {
    private JEditorPane m_ep;
    private Vector m_links = new Vector();
    private URL m_current_url;
    private JScrollPane m_sp;
    private Browser m_b;  // The calling browser or null if not from a browser
    
    public Help(String url) {
        this(null, url);
    }
    
    public Help(Browser b, String url) {
        JFrame f;
        JPanel buttonp = new JPanel(new FlowLayout());
        JButton b_back = new JButton("Back");
        b_back.setActionCommand("back");
        b_back.addActionListener(this);
        b_back.setToolTipText("Go back to previous page");
        buttonp.add(b_back);
        m_b = b;
        try {
            m_ep = new JEditorPane();
            m_ep.setEditable(false);
            m_ep.setBackground(Color.lightGray);
            f = new JFrame("Help");
            m_sp = new JScrollPane(m_ep);
            m_sp.setPreferredSize(new Dimension(450, 500));
            m_sp.getViewport().setView(m_ep);
            f.getContentPane().setLayout(new BorderLayout());
            f.getContentPane().add("Center", m_sp);
            f.getContentPane().add("North", buttonp);
            f.pack();
            f.setVisible(true);
            m_ep.addHyperlinkListener(this);
            m_ep.addKeyListener(this);
            m_current_url = null;
            push(new URL(url), null);
        } catch (Exception e) {
            MainFrame.println("Cannot open help file: " + e);
        }
    }

    // We support our snazzy anchor ref. If it is of the form
    // a~b then a is th econvention in-document anchore and b is the
    // name of a tree node in our current browser. We select the node,
    // and drop the ~b before pushing the page ..
    public void hyperlinkUpdate(HyperlinkEvent e) {
        URL url;
        String ref, file, nodename = null;
        int pos;
        
        url = e.getURL();        
        if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {         
            try {
                ref = url.getRef();
                if ((null != ref) && (-1 != (pos = ref.indexOf('~')))) { // Our home-brew link setRef
                // Everything after the ~ is a node name
                    if (null != m_b)
                        m_b.selectNode(nodename = ref.substring(pos + 1));
                    ref = ref.substring(0, pos).trim();
                    file = url.getFile();
                    if (ref.length() > 0)
                        file = file + "#" + ref;                        
                    push (url = new URL(url.getProtocol(), url.getHost(), file), nodename);
                } else {
                    push(e.getURL(), nodename);
                }
            } catch (Exception ex) {
                MainFrame.println("Hyperlink Activiation: " + ex);
            }
        }
    }
    
    private void push(URL url, String nodename) {      
        try {
            Rectangle oldr = m_sp.getViewport().getViewRect();
            m_ep.setPage(url);    
            if (m_current_url != null)
                m_links.addElement(new HLink(m_current_url, oldr, nodename));              
            m_current_url = url;
        } catch (Exception e) {
            ErrorMessage.message(null, ErrorMessage.EM_BAD_HYPERLINK_ERROR, e);
        }
    }
    
    private void pop() {
        if (! m_links.isEmpty()) {
            HLink l = (HLink) m_links.lastElement();
            try {
                m_ep.setPage(l.getURL());
                if (null != l.getNodeName())
                    m_b.selectNode(l.getNodeName());
                //m_sp.getViewport().scrollRectToVisible(l.getPos());
                m_sp.getViewport().setViewPosition(l.getPos().getLocation());
                m_links.removeElementAt(m_links.lastIndexOf(l));                
                m_current_url = l.getURL();
            } catch (Exception e) {
                MainFrame.println("Help:pop() " + e);
            }
        }
    }
    
    public void keyPressed(KeyEvent e) {
    }
    
    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
        char c;        
        c = e.getKeyChar();        
        if (c == 'b' || c == '\b') {
            pop();
        }
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("back")) {
            pop();
        }
    }
    
}

// Al we need to get back. For now I just use the URL, the
// idea is also to keep the offset into the document ..
class HLink {
    private URL m_url;
    private Rectangle m_pos;
    private String m_nodename;
    
    public HLink(URL url, Rectangle pos, String nodename) {
        m_url = url;
        m_pos = pos;
        m_nodename = nodename;
    }
    
    public URL getURL() {
        return m_url;
    }
    
    public Rectangle getPos() {
        return m_pos;
    }       
    
    public String getNodeName() {
        return m_nodename;
    }
}