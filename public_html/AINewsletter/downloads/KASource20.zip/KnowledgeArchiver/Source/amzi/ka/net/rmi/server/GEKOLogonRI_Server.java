// GEKOLogonRI_Server.java

package amzi.ka.net.rmi.server;

import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.db.*;
import amzi.frames.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.net.*;
import java.io.*;
import java.text.*;

/**
* Services logon and logoff requests,
* setting up user threads as they come
* in.
*/
public class GEKOLogonRI_Server
   extends UnicastRemoteObject
   implements GEKOLogonRI
{
   String version = "KAServer 2.0 beta";
   //GEKOLibraryI gekos;
   PrintWriter log;
   Vector logged_on_users;
   Hashtable open_libraries;
   UserTable users;
   BufferedReader din;
   String ka_dir = "/KArchives/";
   //Thread odi_thread;

   static DateFormat df;

   static
   {
      // Format the datetime like: 3/19/98 12:32:14 PM
      df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.US);
      df.setTimeZone(TimeZone.getDefault());
   }

   public static void main(String args[])
   {
      System.out.println("Starting KAServer");
//System.out.println("GEKOLogonRI_Server:main " + Thread.currentThread().toString());
      Process rmiregistry = null;
      System.setSecurityManager(new RMISecurityManager());
      System.out.println("RMI Security Manager Set");
      try
      {
         rmiregistry = Runtime.getRuntime().exec("rmiregistry");
         System.out.println("RMI registry running");
         GEKOLogonRI_Server ls = new GEKOLogonRI_Server();
         System.out.println("New GEKOLogonRI_Server created");
         //ls.setLog(System.out);
         Naming.bind("KA", ls);
         System.out.println("KA bound");
         ls.go();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      finally
      {
         try
         {
            Naming.unbind("KA");
            rmiregistry.destroy();
            System.exit(0);
         }
         catch (Exception e)
         {
            e.printStackTrace();
         }
      }
   }

   public GEKOLogonRI_Server() throws RemoteException, IOException, FrameException
   {
//System.out.println("GEKOLogonRI_Server:consturctor " + Thread.currentThread().toString());
      log = new PrintWriter(
         new FileWriter( new File(ka_dir, "log.txt") ),
         true);
      logged_on_users = new Vector();
      open_libraries = new Hashtable();
      din = new BufferedReader( new InputStreamReader(System.in) );
      users = new UserTable( new File(ka_dir, "users.obj") );
   }

   public void go() throws IOException, FrameException
   {
//System.out.println("GEKOLogonRI_Server:go " + Thread.currentThread().toString());
      //gekos = (GEKOLibraryI)new GEKOLibraryI_PSE();
      //gekos.initialize();
      //odi_thread = Thread.currentThread();
      //odi_thread = gekos.initial_thread();
      //gekos.open("KA01");

      System.out.println("KA Server version " + version);
      String command = "help";
      while (! command.equals("exit"))
      {
         if (command.equals("help"))
            System.out.println("commands are version, users, open libraries, available libraries, exit");
         else if (command.equals("version"))
         {
            System.out.println("Version " + version);
         }
         else if (command.equals("users"))
         {
            Enumeration e = logged_on_users.elements();
            while (e.hasMoreElements())
               System.out.println("  " + (String)e.nextElement());
         }
         else if (command.equals("open libraries"))
         {
            Enumeration e = open_libraries.elements();
            Enumeration eu;
            OpenLibrary ol;
            while (e.hasMoreElements())
            {
               ol = (OpenLibrary)e.nextElement();
               System.out.println("  " + ol.name);
               eu = ol.users.elements();
               while (eu.hasMoreElements())
                  System.out.println("    " + (String)eu.nextElement());
            }
         }
         else if (command.equals("available libraries"))
         {
            Vector v = GEKOLibraryI_PSE.libraries();
            Enumeration e = v.elements();
            while (e.hasMoreElements())
               System.out.println("  " + (String)e.nextElement());
         }
         else
            System.out.println("commands are users, open libraries, available libraries, exit");

         System.out.print("command> ");
         command = din.readLine();
      }

      // Close all the libraries
      Enumeration e = open_libraries.elements();
      while (e.hasMoreElements())
         ((OpenLibrary)e.nextElement()).library.close();

      log.close();
   }

   /**
   * Allow a remote user to logon to the server.
   */
   public synchronized boolean logon(String user_id, String password) throws RemoteException, FrameException
   {
      try
      {
         report("system", "logon " + user_id + " " + password);
         if (users.check_user(user_id, password))
         {
            logged_on_users.addElement(user_id);
            System.out.println(user_id + " " + password + " logged on");
            return true;
         }
         else
            return false;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new FrameException("Odd exception: " + e.getMessage());
      }
   }

   /**
   * Allow a remote user to logon to a particular library.  If the library
   * isn't open already, it is opened.
   * @param person The person logging on.
   * @param library The name of the library.
   */
   /*
   public synchronized GEKOLibraryRI logon(KnowledgeFrame person, String library_name) throws RemoteException, FrameException
   {
//System.out.println("GEKOLogonRI_Server:logon " + Thread.currentThread().toString());
      try
      {
         report("system", "logon " + library_name + " " + person.summary());
         OpenLibrary open_library;
         GEKOLibraryI gekos = null;
         GEKOSession_PSE main_thread;
         if (open_libraries.containsKey(library_name))
         {
            open_library = (OpenLibrary)open_libraries.get(library_name);
            gekos = open_library.library;
         }
         else
         {
            main_thread = new GEKOSession_PSE();
            main_thread.start();
            gekos = main_thread.get_archive();
            open_library = new OpenLibrary(
                     library_name,
                     gekos,
                     main_thread );
            open_libraries.put(library_name, open_library);
         }
         open_library.add_user(person.summary());
         logged_on_users.addElement(person.summary());
         GEKOLibraryRI gri = new GEKOLibraryRI_Server(gekos, this, person.summary());
         gri.initialize(open_library.main_thread);
         return gri;
      }
      catch (RemoteException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (FrameException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new FrameException("Odd exception: " + e.getMessage());
      }
   }
   */

   /**
   * Get a vector of available archive names.
   */
   public synchronized Vector get_archives() throws RemoteException, FrameException
   {
      report("system", "get_archives");
      return GEKOLibraryI_PSE.libraries();
   }

   /**
   * Allow a remote user to logon to a particular library.  If the library
   * isn't open already, it is opened.
   * @param person The person logging on.
   * @param library The name of the library.
   */
   public synchronized GEKOLibraryRI open(String user_id, String library_name)
         throws RemoteException, FrameException
   {
      try
      {
         report("system", "create_archive " + user_id + " " + library_name);
         OpenLibrary open_library;
         GEKOLibraryI gekos = null;
         GEKOSession_PSE main_thread;

         if (open_libraries.containsKey(library_name))
         {
            open_library = (OpenLibrary)open_libraries.get(library_name);
            gekos = open_library.library;
         }
         else
         {
            main_thread = new GEKOSession_PSE();
            main_thread.start();
            gekos = main_thread.get_archive();
            gekos.open(library_name);
            open_library = new OpenLibrary(
                     library_name,
                     gekos,
                     main_thread );
            open_libraries.put(library_name, open_library);
         }

         open_library.add_user(user_id);
         GEKOLibraryRI gri = new GEKOLibraryRI_Server(gekos, this, user_id);
         gri.initialize(open_library.main_thread);
         return gri;
      }
      catch (RemoteException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (FrameException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new FrameException("Odd exception: " + e.getMessage());
      }
   }

   /**
   * Allow a remote user to logon to a particular library.  If the library
   * isn't open already, it is opened.
   * @param person The person logging on.
   * @param library The name of the library.
   */
   public synchronized GEKOLibraryRI create(String user_id, String library_name,
         String schema_file_name, KnowledgeFrame archivist) throws RemoteException, FrameException
   {
      try
      {
         report("system", "create_archive " + user_id + " " + library_name);
         OpenLibrary open_library;
         GEKOLibraryI gekos = null;
         GEKOSession_PSE main_thread;

         main_thread = new GEKOSession_PSE();
         main_thread.start();
         gekos = main_thread.get_archive();
         gekos.create(library_name, schema_file_name, archivist);
         open_library = new OpenLibrary(
                  library_name,
                  gekos,
                  main_thread );
         open_libraries.put(library_name, open_library);

         open_library.add_user(user_id);
         GEKOLibraryRI gri = new GEKOLibraryRI_Server(gekos, this, user_id);
         gri.initialize(open_library.main_thread);
         return gri;
      }
      catch (RemoteException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (FrameException e)
      {
         e.printStackTrace();
         throw e;
      }
      catch (Exception e)
      {
         e.printStackTrace();
         throw new FrameException("Odd exception: " + e.getMessage());
      }
   }

   /*
   public synchronized void logoff(KnowledgeFrame person, String library_name) throws RemoteException, FrameException
   {
      report("system", "logoff " + person.summary());
      //logged_on_users.remove(person.summary());
      OpenLibrary ol = (OpenLibrary)open_libraries.get(library_name);
      ol.remove_user(person.summary());
      if (! ol.in_use())
      {
         ol.main_thread.set_needed(false);
         open_libraries.remove(library_name);
      }
   }
   */

   public synchronized void logoff(String user_id, String library_name) throws RemoteException, FrameException
   {
      report("system", "logoff " + user_id);

      for (int i=0; i<logged_on_users.size(); i++)
      {
         if (logged_on_users.elementAt(i).equals(user_id))
         {
            logged_on_users.removeElementAt(i);
            break;
         }

      }
      OpenLibrary ol = (OpenLibrary)open_libraries.get(library_name);
      ol.remove_user(user_id);
      if (! ol.in_use())
      {
         ol.main_thread.set_needed(false);
         open_libraries.remove(library_name);
      }
   }

   public synchronized void logoff(String user_id) throws RemoteException, FrameException
   {
      report("system", "logoff " + user_id);
      for (int i=0; i<logged_on_users.size(); i++)
      {
         if (logged_on_users.elementAt(i).equals(user_id))
         {
            logged_on_users.removeElementAt(i);
            break;
         }

      }
   }

   public synchronized void close(String user_id, String library_name) throws RemoteException, FrameException
   {
      report("system", "close " + user_id + " " + library_name);
      //logged_on_users.remove(person.summary());
      OpenLibrary ol = (OpenLibrary)open_libraries.get(library_name);
      ol.remove_user(user_id);
      if (! ol.in_use())
      {
         ol.main_thread.set_needed(false);
         open_libraries.remove(library_name);
      }
   }

   public synchronized void report(String user, String info) throws RemoteException
   {
      //log.println(user + ": " + info);
      System.out.println(df.format(new Date()) +
            user +
            "(" + Thread.currentThread().toString() + ")" +
            ": " + info);
   }
}


class OpenLibrary
{
   String name;
   GEKOLibraryI library;
   GEKOSession_PSE main_thread;
   Vector users;

   OpenLibrary(String name, GEKOLibraryI library, GEKOSession_PSE t)
   {
      this.name = name;
      this.library = library;
      main_thread = t;
      users = new Vector();
   }

   void add_user(String summary)
   {
      users.addElement(summary);
   }

   void remove_user(String summary)
   {
      users.removeElement(summary);
   }

   boolean in_use()
   {
      if (users.isEmpty())
         return false;
      else
         return true;
   }
}
