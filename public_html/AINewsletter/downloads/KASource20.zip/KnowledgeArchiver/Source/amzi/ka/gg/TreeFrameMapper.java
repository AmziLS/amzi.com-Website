package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Hashtable;
import java.util.Enumeration;

import amzi.ka.*;
import amzi.frames.*;

/** Hides the messyness of mapping between the frame structure and the
* JTree browser -- and it IS messy
*/
public class TreeFrameMapper {
    
    private JTree m_tree;
    private KnowledgeFrame m_frame;
    // Enables FrameObject -> TreeNode object mapping for verification
    // I know this approach sucks but it turns out JTree is really designed
    // for interactivity only -- so I found out to my cost 
    private Hashtable m_object_pairs;
    private SchemaSource m_schema_source;
    
    public static final String  ITEM_PREFIX = "item:";
    
    public TreeFrameMapper(JTree tree, KnowledgeFrame frame, SchemaSource source) {
        m_tree = tree;
        m_frame = frame;
        m_schema_source = source;
        m_object_pairs = new Hashtable();
        init();
    }
    
    public void init() 
    {
        DefaultMutableTreeNode root;
        
        root = (DefaultMutableTreeNode) m_tree.getModel().getRoot();
        root.removeAllChildren();
        m_object_pairs.clear();
    
        try {
            buildTree(root, m_frame);
        } catch (Exception e) {
            MainFrame.println("TreeFrameMapper():" + e);
        }
    }

    
    /**
    * Builds a tree representing frame under node root. Uses schema if it can. This
    * is the method used by the browsers to build the browser tree and to edit
    * it.
    */
    public void buildTree(DefaultMutableTreeNode root, KnowledgeFrame frame) 
    throws Exception
    {
        KnowledgeFrame schema;
        
        if (null == m_schema_source)
            buildTreeFromFrame(root, new KnowledgeSlot("", frame));
        else if (null == (schema = m_schema_source.getSchema(frame.group_name())))
            buildTreeFromFrame(root, new KnowledgeSlot("", frame));
        else
            buildTreeFromSchema(root, frame, schema);        
    }
    
    /** 
    * Reads through the frame building the JTree of the root node. Introduces
    * "list" nodes in the tree for lists in the frame. ALso build the hash table so we can 
    * get from a point in the Frame to the corresponding TreeNode. Note however that
    * this is a little subtle. We really want to hash on values, since that
    * is what we get back from RMI gekko accessing stuff _but_ this fails us if the
    * slot value is a leaf (e.g. a string)... why ? Glad I asked. If we edit the leaf in
    * a Gekko browser then the new edits get put back into the frame .. BUT IT IS A DIFFERENT
    * STRING .. and now my hash is pointing to the wrong thing and I can never find it again.
    */
    final private void buildTreeFromFrame(DefaultMutableTreeNode tn, KnowledgeSlot ks) 
    throws Exception 
    {
        DefaultMutableTreeNode newnode;
        KnowledgeSlot newslot;
        GekkoTreeNode gtn;
        
        if (ks.is_frame()) {
            KnowledgeFrame kf = (KnowledgeFrame) ks.value();

            for (int i = 0; i < kf.size(); ++i) {
                newslot = kf.slot_at(i);
                tn.add( newnode = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(newslot.name()))); 
                gtn.setParent(newnode);
                if (newslot.is_frame() || newslot.is_list()) // see comment above (grr)
                    m_object_pairs.put(gtn, newslot.value());
                else
                    m_object_pairs.put(gtn, newslot);
                buildTreeFromFrame(newnode, newslot);
            }            
        } else if (ks.is_list()) {
            KnowledgeList kl = (KnowledgeList) ks.value();
            for (int i = 0; i < kl.length(); ++i) {
                newslot = (KnowledgeSlot) kl.slot_at(i);
                tn.add( newnode = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(ITEM_PREFIX + i))); 
                gtn.setParent(newnode);
                if (newslot.is_frame() || newslot.is_list())
                    m_object_pairs.put(gtn, newslot.value());
                else
                    m_object_pairs.put(gtn, newslot);
                buildTreeFromFrame(newnode, newslot);                                
            }
        } else {
            // Else its a leaf and we are done
        }
    }    

    /** Builds the subtree under the specified treenode for the specified frame. However
    * unlike buildTreeFromFrame it walks the specified Schema to build the tree nodes,
    * populating the values with values from the frame that match.
    */
    final private void buildTreeFromSchema(DefaultMutableTreeNode tn, KnowledgeFrame kf, KnowledgeFrame schema) 
    throws SchemaVerificationException, Exception {

        KnowledgeList formats;
        KnowledgeFrame format;
        String name;
        Object obj;   
        int len;
        
        formats = (KnowledgeList)schema.get("formats");
        len = formats.length();
        for (int i = 0; i < len; i++)
        {
            format = (KnowledgeFrame)formats.slot_at(i).value();
            name = (String) format.get("slot");
            if (kf.slot_exists(name))
                obj = kf.slot_at(kf.slot_number(name));
            else { // slot is in schema but not in frame
                kf.set(name, new Schema(schema, m_schema_source).newFrame(Schema.USE_DEFAULTS).get(name));
                obj = kf.slot_at(kf.slot_number(name));
            }
            buildTreeFromFormat(tn, obj, format);            
        }
     }

    /** 
    * We are building a frame. Walks the schema and the frame in parallel.
    * The assertion is on entry
    * the schema describes the contents of the slot. Failure to do so is treated
    * as an error in the current version (what is wanted is a full bore delta'ing
    * argument that decides the frame is just missing some new stuff from the schema
    * which then gets added in .... good luck).
    * A side effect of this walking is also that the new tree nodes get created,
    * populated with local schema info as well as all the rest of the stuff seen
    * in buildTreeFromFrame, and, as before, the mapping table is build.
    */
    final private void buildTreeFromFormat(DefaultMutableTreeNode tn, Object obj, KnowledgeFrame format) 
    throws SchemaVerificationException, Exception {
        
        String slot_name, slot_type, schema_name;
        GekkoTreeNode gtn;
        DefaultMutableTreeNode dtn, listnode;
        KnowledgeFrame kf;
        KnowledgeList  kl;
        KnowledgeSlot newslot;
      
        slot_type = (String)format.get("type");
        slot_name = (String)format.get("slot");
        newslot = null; 
        if (slot_type.equals("local_frame") || slot_type.equals("global_frame")) {
            if (slot_type.equals("local_frame")) {
                kf = (KnowledgeFrame) format.get("schema");
                schema_name = (String) kf.get("group");                
            } else {
                schema_name = (String) format.get("schema");
            }
            ((GekkoTreeNode) tn.getUserObject()).setTreeNodeSchema(
                    new TreeNodeSchema(format, schema_name));  
            try {
                kf = (KnowledgeFrame)((KnowledgeSlot) obj).value();
                tn.add( dtn = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(slot_name))); 
                m_object_pairs.put(gtn, kf);
                gtn.setParent(dtn);
                gtn.setTreeNodeSchema(new TreeNodeSchema(format, schema_name));                                            
                buildTreeFromSchema(dtn, kf, m_schema_source.getSchema(schema_name));                                                                                        
            } catch (Exception e) {
                // throw new SchemaVerificationException("Expecting frame, didn't get it:" + slot_name);
                // for now just continue on
            }
         }
         else if (slot_type.equals("local_frame_list") || slot_type.equals("global_frame_list"))
         {
            if (slot_type.equals("local_frame_list")) {
                kf = (KnowledgeFrame) format.get("schema");
                schema_name = (String) kf.get("group");                
            } else {
                schema_name = (String) format.get("schema");
            }
            tn.add( listnode = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(slot_name))); 
            gtn.setParent(listnode);
            gtn.setTreeNodeSchema(new TreeNodeSchema(format, schema_name));                                            
            try {
                kl = (KnowledgeList)((KnowledgeSlot) obj).value();
            } catch (Exception e2) {
                throw new SchemaVerificationException("Expecting list, didn't get it:" + slot_name);
            }
            m_object_pairs.put(gtn, kl);            
            for (int i = 0; i < kl.length(); ++i) {
                newslot = (KnowledgeSlot) kl.slot_at(i);
                listnode.add( dtn = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(ITEM_PREFIX + i))); 
                if (newslot.is_frame() || newslot.is_list())
                    m_object_pairs.put(gtn, newslot.value());
                else
                    m_object_pairs.put(gtn, newslot);
                gtn.setParent(dtn);
                gtn.setTreeNodeSchema(new TreeNodeSchema(format, schema_name));                            
                buildTreeFromSchema(dtn, (KnowledgeFrame) newslot.value(), m_schema_source.getSchema(schema_name));
              
            }
         }
         else // Its a leaf - no schema
         {
            tn.add( dtn = new DefaultMutableTreeNode(gtn = new GekkoTreeNode(slot_name)));           
            gtn.setParent(dtn);
            gtn.setTreeNodeSchema(new TreeNodeSchema(format, null)); 
            m_object_pairs.put(gtn, obj);
         }
    }    

    
    /**
    * A subframe has changed (because of grafting) -- fix up
    * the hash table so we are consistent between tree and frame
    *
    * Currently do this the messy way of simply wiping the tree
    * below the current selection and rebuilding it. This doesn't clean out
    * the hash table so it can fill up -- but is highly unlikely to
    * during the editing of a single object .... (and since entries are keyed
    */
    public void resynch(Object oldvalue, Object newvalue) {
        GekkoTreeNode gtn;
        DefaultMutableTreeNode dtn;
        if (null == (gtn = getTreeNode(oldvalue))) {
            MainFrame.println("TreeFrameMapper:resynch():bad lookup:" + oldvalue);
        } else {
            dtn = (DefaultMutableTreeNode)gtn.getParent();
            m_object_pairs.put(gtn, newvalue);
            dtn.removeAllChildren();
            try {
                buildTree(dtn, (KnowledgeFrame)newvalue);
            } catch (Exception e) {
                MainFrame.println("TreeFrameMapper:resynch(): " + e);
            }
            ((DefaultTreeModel) m_tree.getModel()).nodeStructureChanged(dtn);
        }
    }
    
    /**
    * Associate the object with the GekkoTreeNode
    */
    public void map(GekkoTreeNode gtn, Object val) {
        m_object_pairs.put(gtn, val);
    }
    
    /** Return object in frame corresponding to current selection path
    */
    public Object getBrowsedObject() throws Exception {
        return getPathedObject(m_tree.getSelectionPath());
    }
    
    /** Given a tree path return the frame item associated with it
    */
    public Object getPathedObject(TreePath p) throws Exception {
        return m_object_pairs.get(((DefaultMutableTreeNode)p.getLastPathComponent()).getUserObject());
    }
    
    /** Returns GekkoTreeNode associated with obj (which hopefully is part)
    * of a frame)
    */
    public GekkoTreeNode getTreeNode(Object obj) {
        Enumeration keys = m_object_pairs.keys();
        Object key;
        
        while (keys.hasMoreElements()) {
            key = keys.nextElement();
            if (obj == m_object_pairs.get(key)) {
                return (GekkoTreeNode) key;
            }            
        }
        return null;
    }
    
    /** Returns the element associated with the tree node
    */
    public Object getMappedObject(GekkoTreeNode gkn) {
        return m_object_pairs.get(gkn);
    }
    
    
    /** Returns schema frame which describes Obj (which, hopefully,
    * is part of a frame)
    */
    public TreeNodeSchema getTreeNodeSchema(Object obj) {
        try {
            return getTreeNode(obj).getTreeNodeSchema();
        } catch (Exception e) {
            return null;
        }
    }
}