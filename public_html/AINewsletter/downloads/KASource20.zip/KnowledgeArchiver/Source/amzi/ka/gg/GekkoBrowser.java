package amzi.ka.gg;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;


import amzi.ka.*;
import amzi.frames.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;


public class GekkoBrowser extends KnowledgeFrameBrowser implements ActionListener {
    // A browser is a tree and a panel on which context sensitive
    // things happen. THis one knows about Gekkos

    
    JButton m_bUpload, m_bVerify, m_bNoVerify;
    boolean m_verifying;
    JPanel m_verify_panel;
    GekkoVerifier m_verifier;
    // --------------------------------------------------------------------------------------------

    /** 
    * Build the tree structure from the gekko
    */
    public void init(KnowledgeFrame g, String filename, BrowserContainer bc) {
        JPanel bpanel;

        super.init(g, filename, bc);
        m_verifying = false;
        m_verify_panel = null;
        try {
            String title;
            
            try {
                title = (String) ((KnowledgeFrame)g.get("Source Frame")).get("Title");
                title = title + " version: " + g.get_version();
                title = title + " date: " + g.get_update_date_string();
                if (null == g.get_key())
                    setTitle("Workspace GEKO: " + title);
                else
                    setTitle("Archived GEKO: " + title);
            } catch (Exception e0) {
                setTitle("Generic KnowledgeFrame");
            }        
        } catch (Exception e) {
            MainFrame.println("Exception GekkoBrowser:init():" + e.toString());
        }                    
        m_verifier = new GekkoVerifier(this, m_tfm);
        
        // Build buttons
        bpanel = new JPanel(new FlowLayout());
        m_bUpload = new JButton("Upload");
        m_bUpload.addActionListener(this);
        m_bUpload.setActionCommand("upload");
        m_bUpload.setToolTipText("Upload the Geko to the archive");
        m_bVerify = new JButton("Verify");
        m_bVerify.addActionListener(this);
        m_bVerify.setActionCommand("verify");
        m_bVerify.setToolTipText("Verify the Geko against the archive");
        m_bNoVerify = new JButton("NoVerify");
        m_bNoVerify.setToolTipText("Hide any verification error notices");
        m_bNoVerify.addActionListener(this);
        m_bNoVerify.setActionCommand("noverify");
        
        m_bUpload.setEnabled(true);
        m_bVerify.setEnabled(true);
        m_bNoVerify.setEnabled(false);
        
        bpanel.add(m_bUpload);
        bpanel.add(m_bVerify);
        bpanel.add(m_bNoVerify);
        
        m_left_panel.add("South", bpanel);
        if (m_left_panel.getMinimumSize().width > m_splitter.getDividerLocation())
            m_splitter.setDividerLocation(m_left_panel.getMinimumSize().width  + 10);
    } 
    
    /** Called when we are switching to edit in a browser -- obj is the
    * newly selected tree node
    */
    public void prepare(Object obj) {
        GekkoTreeNode selected;
        if (null == obj) {
            MainFrame.println("GekkoBrowser:prepare(): null focus object");
        } else if (obj instanceof GekkoTreeNode) {
            if (m_verifying) {
                selected = (GekkoTreeNode)obj;
                if (! selected.isAcknowledgedOrVerified()) {
                    m_verify_panel = m_verifier.getVerifyPanel(selected);
                    m_right_panel.add("South", m_verify_panel);                
                }
            }                        
        } else {
            MainFrame.println("GekkoBrowser:prepare(): not a GekkoTreeNode"); 
        }
    }

    /** Called when we are about to discard the editor -- gives us chance to clean
    * up any extant verification panel
    */
    public void prepare() {
        if (m_verify_panel != null) {
            m_right_panel.remove(m_verify_panel);
            m_verify_panel = null;
            setSize(getSize());        
        }                                                   
    }
    
    // Handle buttons and menus
    public void actionPerformed(ActionEvent e) {
        Cursor old_curse = m_browser_container.getCursor();
        m_browser_container.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        
        if (e.getActionCommand().equals("verify")) {
            if (! doVerify()) // if verify fails
                m_bUpload.setEnabled(false);
            else
                m_bUpload.setEnabled(true);
        } else if (e.getActionCommand().equals("upload")) {
            doUpload();            
        } else if (e.getActionCommand().equals("noverify")) {
            doNoVerify();
        } else
            super.actionPerformed(e); // Else give KnowledgeFrameBrowser a shot
        m_browser_container.setCursor(old_curse);
    }
    
    /**
    * Walk the sharable slots in the Gekko. 
    */
    public boolean doVerify() {
        boolean ok = false;

        // If we were editing make sure we are in synch
        // with the edit pane
        if (null != m_current_editor)
            m_current_editor.synchValue();
        
        m_verifying = true;
        m_cell_renderer.setVerifying(true);
        m_bVerify.setEnabled(false);
        m_bNoVerify.setEnabled(true); 
        ok = m_verifier.verifySlots(m_frame);
        try {  // Arghhh  the dreaded tree bug sometimes gives us NullPointer here
            prepare(getBrowsedTreeNode().getUserObject());
        } catch (Exception e) {
        }
        
        setSize(getSize()); // Kick it        
        return ok;
    }
    
    public void doUpload() {
        if (doVerify()) {
            try {
                GEKOClientI lib = m_browser_container.getSession().getLib();;
                UploadDialog.show(this, m_frame, lib.put_frame(m_frame));
            } catch (Exception e) {
                ErrorMessage.message(this, ErrorMessage.EM_UPLOAD_COMPILE_ERROR, e.getMessage());
            }
        } else {
            ErrorMessage.message(this, ErrorMessage.EM_VERIFY_ERROR);
        }
    }
    
    public void doNoVerify() {
        m_verifying = false;
        m_cell_renderer.setVerifying(false);
        m_bVerify.setEnabled(true);
        m_bNoVerify.setEnabled(false);
        m_bUpload.setEnabled(true);
        prepare();
    }
    
    public boolean getVerifying() {
        return m_verifying;
    }
}
