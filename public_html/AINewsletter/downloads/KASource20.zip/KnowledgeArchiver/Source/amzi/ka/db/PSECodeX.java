// PSECode.java

package amzi.ka.db;

import amzi.frames.*;
import amzi.kb.*;

import java.util.*;
import java.io.*;

import COM.odi.*;
import COM.odi.util.*;

public class PSECode
{
   public PSERule[] rules;

   public PSECode(Vector v, PSEVariable dv, PSETest ms, PSETest cv)
   {
      int i, size;
      
      size = v.size();
      rules = new PSERule[size];
      for (i=0; i<size; i++)
      {
         rules[i] = (PSERule)v.elementAt(i);
         rules[i].set_dependent_variable(dv);
         rules[i].set_model_system(ms);
         rules[i].set_controlled_variables(cv);
      }
   }

   public Code makeCode()
   {
      Code c = new Code(rules.length);
      for (int i=0; i<rules.length; i++)
         c.rules[i] = rules[i].makeRule();

      return c;
   }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();

      for (int i=0; i<rules.length; i++)
      {
         sb.append(rules[i].toString());
         sb.append("\n");
      }

      return sb.toString();
   }
}