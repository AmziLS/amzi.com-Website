// GEKOLogonRI.java

package amzi.ka.net.rmi;

import amzi.ka.net.*;
import java.rmi.*;
import amzi.frames.*;
import java.util.*;

/**
* Interface definition for the RMI logon server,
* that provides a connection to an RMI server.
*/
public interface GEKOLogonRI extends Remote
{
   public boolean logon(String user_id, String password) throws RemoteException, FrameException;
   //public GEKOLibraryRI logon(KnowledgeFrame person, String library) throws RemoteException, FrameException;
   /**
   * Get a vector of available archive names.
   */
   public Vector get_archives() throws RemoteException, FrameException;

   public GEKOLibraryRI open(String user_id, String library_name) throws RemoteException, FrameException;
   public GEKOLibraryRI create(
         String user_id, String library_name,
         String schema_file_name, KnowledgeFrame archivist)
         throws RemoteException, FrameException;
   //public void logoff(KnowledgeFrame person, String library) throws RemoteException, FrameException;
   public void close(String user_id, String library_name) throws RemoteException, FrameException;
   public void logoff(String user_id) throws RemoteException, FrameException;
}