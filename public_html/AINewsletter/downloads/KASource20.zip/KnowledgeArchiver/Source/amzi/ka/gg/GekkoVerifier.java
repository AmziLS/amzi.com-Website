package amzi.ka.gg;

import amzi.frames.*;
import amzi.ka.*;
import amzi.ka.net.*;
import amzi.ka.net.rmi.*;
import amzi.ka.net.rmi.client.*;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class GekkoVerifier {
    
    private Session m_session;
    private TreeFrameMapper m_tfm;
    private GekkoBrowser m_browser;
    private SchemaSource m_schema_source;
    
    public static final int V_GEKKO_NEW_DUP = 0;
    public static final int V_GEKKO_OLD_OK = 1;
    public static final int V_GEKKO_OLD_MOD = 2;
    public static final int V_AUTHOR_NEW_OK = 3;
    public static final int V_AUTHOR_NEW_DUP = 4;
    public static final int V_AUTHOR_OLD_MOD = 5;
    public static final int V_DV_NEW_OK = 6;
    public static final int V_DV_NEW_DUP = 7;
    public static final int V_DV_OLD_MOD = 8;
    public static final int V_IV_NEW_OK = 9;
    public static final int V_IV_NEW_DUP = 10;    
    public static final int V_IV_OLD_MOD = 11;
    public static final int V_SC_NEW_OK = 12;
    public static final int V_SC_NEW_DUP = 13;
    public static final int V_SC_OLD_MOD = 14;
    public static final int V_SUC_NEW_OK = 15;
    public static final int V_SUC_NEW_DUP = 16;
    public static final int V_SUC_OLD_MOD = 17;
    public static final int V_KW_NEW_OK = 18;
    public static final int V_KW_NEW_DUP = 19;
    public static final int V_KW_OLD_MOD = 20;
    public static final int V_MCV_NEW_OK = 21;
    public static final int V_MCV_NEW_DUP = 22;    
    public static final int V_MCV_OLD_MOD = 23;

    static final String V_MSGS[] = {
          "A GEKO with the same title already exists in the archive. Change your title.",
          "This GEKO has already been uploaded to the archive.",
          "Warning: This GEKO is different than the one in the archive. The archive version will be overwritten.",
          "Warning: The author is not already defined in the archive.",
          "An author with the same name already exists in the archive. Download the correct author frame.",
          "Warning: This author is different than the one in the archive. The archive version will be overwritten.",
          "Warning: The dependent variable is not already defined in the archive.",
          "The dependent variable already exists in the archive. Download it or change your variable name.",
          "The dependent variable is defined differently in the archive. Download it or change your variable name.",
          "Warning: The independent variable is not already defined in the archive.",
          "The independent variable already exists in the archive. Download it or change your variable name.",
          "The independent variable is defined differently in the archive. Download it or change your variable name.",
          "Warning: The source citation is not already defined in the archive.",
          "The source citation already exists in the archive. Download it or change your citation.",
          "Warning: The source citation is defined differently in the archive. The archive version will be overwritten.",
          "Warning: The support citation is not already defined in the archive.",
          "The support citation already exists in the archive. Download it or change your citation.",
          "Warning: The support citation is defined differently in the archive. The archive version will be overwritten.",
          "Warning: The keyword is not already defined in the archive.",
          "The keyword already exists in the archive. Download it or change your keyword.",
          "Warning: The keyword is defined differently in the archive. The archive version will be overwritten.",
          "Warning: The major controlled variable is not already defined in the archive.",
          "The major controlled variable already exists in the archive. Download it or change your variable name.",
          "The major controlled variable is defined differently in the archive. Download it or change your variable name."
    };
            
    static final String V_CLASS[] = {
           "amzi.ka.gg.OPanel",
           "amzi.ka.gg.NULLPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.APanel",
           "amzi.ka.gg.DOPanel",
           "amzi.ka.gg.DOPanel"           
           };
    
    public GekkoVerifier(GekkoBrowser browser, TreeFrameMapper tfm) {
        m_browser = browser;
        m_session = m_browser.getSession();
        m_tfm = tfm;
        m_schema_source = m_browser.getSchemaSource();
    }
    
    /**
    * get appropriate verify panel based on last error message
    * which called verification failure for given node
    */
    public JPanel getVerifyPanel(GekkoTreeNode node) {
        VPanel vp = null;
        int msg = node.getLastError();
        try {
            vp = (VPanel) Class.forName(V_CLASS[msg]).newInstance();
            vp.init(node, m_browser, msg, V_MSGS[msg]); 
        } catch (Exception e) {
        }
        return vp;      
    }    
    
    // Actually do the verification ..
    public boolean verifySlots(KnowledgeFrame frame) {
        KnowledgeFrame source, technical, knowledge, author, variable, citation, keyword;
        KnowledgeList ivars, cits, kwords, mcvars, dvars;
        int result, i;
        GEKOClientI lib;
        boolean ok = true;
        // Frame

        if (m_session == null) {
            ErrorMessage.message(null, ErrorMessage.EM_VERIFY_LOGIN);
        }
        lib = m_session.getLib();
        result = -1;
        try {
            KnowledgeSlot graft_point = null;
            Object graft = null;
            source = (KnowledgeFrame)frame.get("Source Frame");
            author = (KnowledgeFrame)source.get("Author");
            technical = (KnowledgeFrame)frame.get("Technical Frame");
            knowledge = (KnowledgeFrame)frame.get("Knowledge Frame");
            switch (lib.check_geko((String)source.get("Title"), frame))
            {
            case GEKOClientI.NEW_DUP: 
                result = V_GEKKO_NEW_DUP;
                break;
            case GEKOClientI.OLD_MOD: // Needs to be rethunk
                // result = V_GEKKO_OLD_MOD;
                result = -1;
                break;
            default:
                result = -1;
            }
            GekkoTreeNode gtn = m_tfm.getTreeNode(source);           
            if (-1 != result) {
                gtn.setVerified(false);
                gtn.setLastError(result);
                if (! gtn.isAcknowledged()) {
                    ok = false;
                    m_browser.expandTo(gtn);
                    gtn.setGraft(graft_point, graft);                    
                }
            } else {
                gtn.setVerified(true);
            }
 
            switch (lib.check_author((String)author.get("Name"), author))
            {
            case GEKOClientI.NEW_OK:
                result = V_AUTHOR_NEW_OK;            
                break;
            case GEKOClientI.NEW_DUP:
                result = V_AUTHOR_NEW_DUP;            
                graft = m_schema_source.simpleQuery("person", "Name", (String)author.get("Name"));
                graft_point = source.slot_at(source.slot_number("Author"));
                break;
            case GEKOClientI.OLD_MOD:
                result = V_AUTHOR_OLD_MOD;            
                break;
            default:
                result = -1;
            }
            gtn = m_tfm.getTreeNode(author);   
            if (-1 != result) {
                gtn.setVerified(false);
                gtn.setLastError(result);
                if (! gtn.isAcknowledged()) {
                    ok = false;                
                    m_browser.expandTo(gtn);
                    gtn.setGraft(graft_point, graft);
                }
            } else {
                gtn.setVerified(true);
            }
//dcm - these are not needed since we're generating the slots now,
// but leave in, commented out, as we might need them again sometime.
/*

            ivars = (KnowledgeList)knowledge.get("Independent Variables");
            for (i=0; i < ivars.length(); i++)
            {
                KnowledgeSlot s = ivars.slot_at(i);
                variable = (KnowledgeFrame)s.value();
                switch (lib.check_variable((String)variable.get("Name"), variable))
                {
                case GEKOClientI.NEW_OK:
                    result = V_IV_NEW_OK;
                    break;
                case GEKOClientI.NEW_DUP:
                    result = V_IV_NEW_DUP;
                    graft = m_schema_source.simpleQuery("variable", "Name", (String)variable.get("Name"));
                    graft_point = s;
                    break;
                case GEKOClientI.OLD_MOD:
                    result = V_IV_OLD_MOD;
                    break;
                default:
                    result = -1;
                }
                gtn = m_tfm.getTreeNode(variable);   
                if (-1 != result) {
                    gtn.setVerified(false);
                    gtn.setLastError(result);
                    if (! gtn.isAcknowledged()) {
                        ok = false;
                        m_browser.expandTo(gtn);
                        gtn.setGraft(graft_point, graft);                                        
                    }                                            
                } else {
                    gtn.setVerified(true);
                }                
            }

            dvars = (KnowledgeList)knowledge.get("Dependent Variables");
            for (i=0; i < dvars.length(); i++)
            {
                KnowledgeSlot s = dvars.slot_at(i);
                variable = (KnowledgeFrame)s.value();
                switch (lib.check_variable((String)variable.get("Name"), variable))
                {
                case GEKOClientI.NEW_OK:
                    result = V_IV_NEW_OK;
                    break;
                case GEKOClientI.NEW_DUP:
                    result = V_IV_NEW_DUP;
                    graft = m_schema_source.simpleQuery("variable", "Name", (String)variable.get("Name"));
                    graft_point = s;
                    break;
                case GEKOClientI.OLD_MOD:
                    result = V_IV_OLD_MOD;
                    break;
                default:
                    result = -1;
                }
                gtn = m_tfm.getTreeNode(variable);   
                if (-1 != result) {
                    gtn.setVerified(false);
                    gtn.setLastError(result);
                    if (! gtn.isAcknowledged()) {
                        ok = false;
                        m_browser.expandTo(gtn);
                        gtn.setGraft(graft_point, graft);                                        
                    }                                            
                } else {
                    gtn.setVerified(true);
                }                
            }
*/
            cits = (KnowledgeList)source.get("Source Citations");
            for (i=0; i < cits.length(); i++)
            {
                KnowledgeSlot s = cits.slot_at(i);
                citation = (KnowledgeFrame)s.value();
                switch (lib.check_citation((String)citation.get("Body"), citation))
                {
                case GEKOClientI.NEW_OK:
                    result = V_SC_NEW_OK;
                    break;
                case GEKOClientI.NEW_DUP:
                    result = V_SC_NEW_DUP;
                    graft = m_schema_source.simpleQuery("citation", "Body", (String)citation.get("Body"));
                    graft_point = s;
                    break;
                case GEKOClientI.OLD_MOD:
                    result = V_SC_OLD_MOD;
                    break;
                default:
                    result = -1;                    
                }
                gtn = m_tfm.getTreeNode(citation);  
                if (-1 != result) {
                    gtn.setVerified(false);
                    gtn.setLastError(result);
                    if (! gtn.isAcknowledged()) {
                        ok = false;                    
                        m_browser.expandTo(gtn);
                        gtn.setGraft(graft_point, graft);                                        
                    }                        
                } else {
                    gtn.setVerified(true);
                }                
            }

            if (source.slot_exists("Support Citations"))
            {
                cits = (KnowledgeList)source.get("Support Citations");
                for (i=0; i < cits.length(); i++)
                {
                    KnowledgeSlot s = cits.slot_at(i);
                    citation = (KnowledgeFrame)s.value();
                    switch (lib.check_citation((String)citation.get("Body"), citation))
                    {
                    case GEKOClientI.NEW_OK:
                        result = V_SUC_NEW_OK;
                        break;
                    case GEKOClientI.NEW_DUP:
                        result = V_SUC_NEW_DUP;
                        graft = m_schema_source.simpleQuery("citation", "Body", (String)citation.get("Body"));
                        graft_point = s;
                        break;
                    case GEKOClientI.OLD_MOD:
                        result = V_SUC_OLD_MOD;
                        break;
                    default:
                        result = -1;                    
                    }
                    gtn = m_tfm.getTreeNode(citation);            
                    if (-1 != result) {
                        gtn.setVerified(false);
                        gtn.setLastError(result);
                        if (! gtn.isAcknowledged()) {
                            ok = false;                      
                            m_browser.expandTo(gtn);
                            gtn.setGraft(graft_point, graft);                                        
                        }                            
                    } else {
                        gtn.setVerified(true);
                    }                                    
                }
            }

            kwords = (KnowledgeList)source.get("Keywords");
            for (i=0; i < kwords.length(); i++)
            {
                KnowledgeSlot s = kwords.slot_at(i);
                keyword = (KnowledgeFrame)s.value();
                switch (lib.check_keyword((String)keyword.get("word"), keyword))
                {
                    case GEKOClientI.NEW_OK:
                        result = V_KW_NEW_OK;
                        break;
                    case GEKOClientI.NEW_DUP:
                        result = V_KW_NEW_DUP;
                        graft = m_schema_source.simpleQuery("keyword", "word", (String)keyword.get("word"));
                        graft_point = s;
                        break;
                    case GEKOClientI.OLD_MOD:
                        result = V_KW_OLD_MOD;
                        break;
                    default:
                        result = -1;                    
                }
                gtn = m_tfm.getTreeNode(keyword);          
                if (-1 != result) {
                    gtn.setVerified(false);
                    gtn.setLastError(result);
                    if (! gtn.isAcknowledged()) {
                        ok = false;                    
                        m_browser.expandTo(gtn);
                        gtn.setGraft(graft_point, graft);                                                                
                    }                    
                } else {
                    gtn.setVerified(true);
                }                                                    
            }

//dcm - see comments above.
/*

            mcvars = (KnowledgeList)knowledge.get("Major Controlled Variables");
            for (i=0; i < mcvars.length(); i++)
            {
                KnowledgeSlot s = mcvars.slot_at(i);
                variable = (KnowledgeFrame)s.value();
                switch (lib.check_variable((String)variable.get("Name"), variable))
                {
                case GEKOClientI.NEW_OK:
                    result = V_MCV_NEW_OK;
                    break;
                case GEKOClientI.NEW_DUP:
                    result = V_MCV_NEW_DUP;
                    graft = m_schema_source.simpleQuery("variable", "Name", (String)variable.get("Name"));
                    graft_point = s;
                    break;
                case GEKOClientI.OLD_MOD:
                    result = V_MCV_OLD_MOD;
                    break;
                default:
                    result = -1;
                }
                gtn = m_tfm.getTreeNode(variable);   
                if (-1 != result) {
                    gtn.setVerified(false);
                    gtn.setLastError(result);
                    if (! gtn.isAcknowledged()) {
                        ok = false;
                        m_browser.expandTo(gtn);
                        gtn.setGraft(graft_point, graft);                                        
                    }                                            
                } else {
                    gtn.setVerified(true);
                }                
            }
*/            
        } catch (Exception e) {
            MainFrame.println("GekkoBrowser:verifySlots():" + e);
        }
        return ok;
   }
}

// -------- Verify interaction panels ---------

/** The generic Verify panel which appears at the
* bottom of the editor pane if verification fails
*/
class VPanel extends JPanel implements ActionListener {
    JPanel m_button_panel;
    GekkoTreeNode m_node;
    GekkoBrowser m_browser;
    int m_msg;
    
    public void init(GekkoTreeNode node, GekkoBrowser browser, int msg, String text) {
        m_msg = msg;
        m_node = node;
        m_browser = browser;
        JTextPane tp = new JTextPane();
        tp.setText(text);
        tp.setBackground(UIManager.getColor("OptionPane.background"));
        
        setLayout(new BorderLayout());
        add("Center", tp);
        m_button_panel = new JPanel(new FlowLayout());
        add("South", m_button_panel);
        add("West", new JLabel(UIManager.getIcon("OptionPane.warningIcon")));
    }
    
    public void actionPerformed(ActionEvent e) {
    }
    
}

/**
* No options
*/
class NULLPanel extends VPanel {    
    public void init(GekkoTreeNode node, GekkoBrowser browser, int msg, String text) {
        super.init(node, browser, msg, text);
    }
}

/**
* The warning panel -- once I acknowledge I will not get warned again
*/
class APanel extends VPanel {
    JButton bAck;
    public void init(GekkoTreeNode node, GekkoBrowser browser, int msg, String text) {
        super.init(node, browser, msg, text);
        m_button_panel.add(bAck = new JButton("Acknowledge"));
        bAck.addActionListener(this);
        bAck.setActionCommand("ack");
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("ack")) {
            m_node.setAcknowledged(true);
            m_browser.prepare();
            m_browser.setSize(m_browser.getSize());
        }
    }
    
}

/** 
* OK it -- which means
* I'll get warned again if I didn't do something else to 
* fix the problem (e.g. edit some field)
*/
class OPanel extends VPanel {
    JButton bOK;
    public void init(GekkoTreeNode node, GekkoBrowser browser, int msg, String text) {
        super.init(node, browser, msg, text);
        m_button_panel.add(bOK = new JButton("OK"));
        bOK.addActionListener(this);
        bOK.setActionCommand("ok");        
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("ok")) {
            m_browser.prepare();
            m_browser.setSize(m_browser.getSize());
        } 
    }    
}

/** 
* I can either download the fix now or OK it -- which means
* I'll get warned again if I didn't do something else to 
* fix the problem (e.g. edit some field)
*/
class DOPanel extends VPanel {
    JButton bDownload, bOK;
    public void init(GekkoTreeNode node, GekkoBrowser browser, int msg, String text) {
        super.init(node, browser, msg, text);
        m_button_panel.add(bDownload = new JButton("Download"));
        bDownload.addActionListener(this);
        bDownload.setActionCommand("download");
        m_button_panel.add(bOK = new JButton("OK"));
        bOK.addActionListener(this);
        bOK.setActionCommand("ok");
        
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("download")) {
            m_node.graft(m_browser);
            m_node.setVerified(true);
            m_browser.prepare();
            m_browser.setSize(m_browser.getSize());
        } else if (e.getActionCommand().equals("ok")) {
            m_browser.prepare();
            m_browser.setSize(m_browser.getSize());            
        }
    }    
}
