package amzi.ka.gg;

import com.sun.java.swing.plaf.windows.*;
import javax.swing.DefaultDesktopManager;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.beans.PropertyVetoException;
import java.util.Vector;

/**
 * Simple MDI activate and close --- sheesh .. alanl
 */
public class MDIDesktopManager extends DefaultDesktopManager 
        implements java.io.Serializable {

    /* The frame which is currently selected/activated.
     * We store this value to enforce MDI's single-selection model.
     */
    JInternalFrame currentFrame;
    JInternalFrame initialFrame;	  

    /* The list of frames, sorted by order of creation.
     * This list is necessary because by default the order of
     * child frames in the JDesktopPane changes during frame
     * activation (the activated frame is moved to index 0).
     * We preserve the creation order so that "next" and "previous"
     * frame actions make sense.
     */
    Vector childFrames = new Vector(1);

    public void closeFrame(JInternalFrame f) {
        childFrames.removeElement(f);
        activateFrame((JInternalFrame) childFrames.lastElement());
        super.closeFrame(f);
    }

    public void activateFrame(JInternalFrame f) {
        try {
            super.activateFrame(f);

            // Move to head of the list
            if (childFrames.indexOf(f) == -1) {
                childFrames.addElement(f);
            } else {
                childFrames.removeElement(f);
                childFrames.addElement(f);
            }

            if (currentFrame != null && f != currentFrame) {
                // If the current frame is maximized, transfer that 
                // attribute to the frame being activated.
                if (currentFrame.isMaximum()) {
                    currentFrame.setMaximum(false);
                    f.setMaximum(true);
                }
                if (currentFrame.isSelected()) {
                    currentFrame.setSelected(false);
                }
            }

            if (!f.isSelected()) {
                f.setSelected(true);
            }
            currentFrame = f;
        } catch (PropertyVetoException e) {}
    }

}
