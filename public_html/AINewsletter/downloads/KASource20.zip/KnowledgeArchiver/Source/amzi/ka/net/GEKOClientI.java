// GEKOClientI

package amzi.ka.net;

import amzi.ka.*;
import amzi.frames.*;
import amzi.kb.*;

import java.util.*;

/**
* An extension of the KnowledgeLibrary interface, but the full
* interface is repeated here, rather than use Java extensions
* to avoid the problems with different exception classes.
* @author Amzi! inc.
*/
public interface GEKOClientI
{
   public final static String RELEASE = "AMKES 2.0 beta";
   public final static int NEW_OK = 1;
   public final static int NEW_DUP = 2;
   public final static int OLD_OK = 3;
   public final static int OLD_MOD = 4;

   /**
   * Connect to a library server.
   */
   public void connect(String host) throws FrameException;

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port) throws FrameException;

   /**
   * Connect to a library server.
   */
   public void connect(String host, String port, String proxy_host, String proxy_port) throws FrameException;

   /**
   * Allow a user to log onto the server.
   */
   public boolean logon(String user_id, String password) throws FrameException;

   /**
   * Allow a user to log into the library.
   */
   public void logoff() throws FrameException;

   /**
   * Initialize a library server.
   */
   public void initialize() throws FrameException;

   /**
   * Initialize a library server.
   */
   public void initialize(Thread th) throws FrameException;

   /**
   * Creates a new open Knowledge Library.
   */
   public void create(String db_name) throws FrameException;

   /**
   * Create a new Knowledge Library from the named schema.
   */
   public void create(String db_name, String schema_file_name) throws FrameException;

   /**
   * Create a new closed Knowledge Library starting with the
   * person frame for the archivist.
   */
   public void create(String db_name, String schema_file_name, KnowledgeFrame archivist) throws FrameException;

   /**
   * Open an existing Knowledge Library.
   */
   public void open(String db_name) throws FrameException;

   /**
   * Close an open Knowledge Library.
   */
   //public void close() throws FrameException;

   public void close(String archive) throws FrameException;

   /**
   * Create a new group (empty) in a library.
   * @param group The name of the group to add.
   */
   public void add_group(String group) throws FrameException;

   /**
   * Get a vector of group names defined in the library.
   * @return The vector of groups.
   */
   public Vector get_groups() throws FrameException;

   /**
   * Puts a new frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public String put_frame(KnowledgeFrame f) throws FrameException;

   /**
   * Removess a frame in the library.  Throws an exception if
   * the frame group doesn't exist.
   * @param f  The frame to add.
   * @return The library key for the frame.
   */
   public void remove_frame(KnowledgeFrame f) throws FrameException;

   /**
   * Get a frame from the library based on its group name and
   * frame key and version.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @param version The version number
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key, int version) throws FrameException;

   /**
   * Get a frame from the library based on its group name and
   * frame key.
   * @param group The group the frame is in.
   * @param key The key for the individual frame.
   * @return The full frame or null if not found.
   */
   public KnowledgeFrame get_frame(String group, String key) throws FrameException;

   /**
   * Get key-note pairs using as a default the first slot of a frame
   * for the note field.
   * @param group The group name.
   * @return The vector of key-note pairs.
   */
   public Vector get_key_notes(String group) throws FrameException;

   /**
   * Get a vector of key-note pairs representing frames that
   * match the conditions specified in a QueryFrame.
   * @param qf The query frame.
   * @return a Vector of key-note pairs.
   */
   public Vector query(QueryFrame qf) throws FrameException;

   //----------------------------
   // KA-specific functions
   //

   /**
   * Get an array of available archive names.
   */
   public Vector get_archives() throws FrameException;

   /**
   * Check to see if a geko exists for the given title.
   * @param title The title string.
   * @param geko The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_geko(String title, KnowledgeFrame geko) throws FrameException;

   /**
   * Check to see if an author exists with the given name.
   * @param name The name string.
   * @param author The frame to compare against.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_author(String name, KnowledgeFrame author) throws FrameException;

   /**
   * Check to see if a variable exists with the given name.
   * @param name The name string.
   * @param variable The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_variable(String name, KnowledgeFrame variable) throws FrameException;

   /**
   * Check to see if a citation exists with the given body.
   * @param body The body string.
   * @param citation The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_citation(String body, KnowledgeFrame citation) throws FrameException;

   /**
   * Check to see if a keyword exists with the given body.
   * @param item The keyword string.
   * @param keyword The frame to compare.
   * @return new_OK, new_DUP, old_OK or old_MOD.
   */
   public int check_keyword(String item, KnowledgeFrame keyword) throws FrameException;

   /**
   * Get all the variables from the archive formatted
   * for inferencing.
   */
   public Variable[] get_variables() throws FrameException;

   /**
   * Get all the links from the archive formatted
   * for inferencing.
   */
   public Link[] get_links() throws FrameException;

   /**
   * Get all the rules from the gekos in the archive
   * formatted for inferencing.
   */
   public Rule[] get_rules() throws FrameException;
}
