package amzi.ka.gg;

import javax.swing.*;
import java.awt.*;
import amzi.frames.*;

public class UploadDialog {
    
    public static void show(KnowledgeFrameBrowser b, KnowledgeFrame f, String key) {
        JOptionPane option;
        JDialog d;
        Object obj[] = {"Update", "Keep", "Dispose"};
        JTextArea msg;
        
        msg = new JTextArea(
           "The knowledge frame uploaded succesfully.\n\n" +
           "Do you wish to: \n\n" +
           "  Update the browser with the archived copy, \n" +
           "  Keep the current copy in the browser or \n" +
           "  Dispose of the browser ?\n");
        msg.setEnabled(false);
        msg.setBackground(Color.lightGray);
        msg.setDisabledTextColor(Color.black);
        option = new JOptionPane(
           msg,
           JOptionPane.QUESTION_MESSAGE,
           JOptionPane.DEFAULT_OPTION,
           null,
           obj
           );
        
        d = option.createDialog(null, "Upload succeeded!");
        d.setVisible(true);
        
        String cmd = (String)option.getValue();

        if ("Dispose".equals(cmd)) {
            b.getBrowserContainer().deregister(b);
        } else if ("Keep".equals(cmd)) { // Do nothing
        } else if ("Update".equals(cmd)) { // Fake it -- get a new browser
            Rectangle pos = b.getBounds(); // and dispose of old
            KnowledgeFrame newf;
            try {
                newf = b.getBrowserContainer().getSession().getLib().get_frame(f.group_name(), key);
            } catch (Exception e) {
                newf = null;
            }
            b.getBrowserContainer().addNewBrowser( newf , f.group_name()).setBounds(pos);
        }
    }
}