// GEKOStreamView.java

package amzi.ka;

import amzi.frames.*;
import java.io.*;
import java.util.*;

/**
 * Read a GEKO in semicolon format from an input stream
 * and write a GEKO out in the same format.  This class
 * uses GEKOTokenizer to return GEKO interesting tokens
 * from the input stream.
 *
 * @author  Amzi! inc.
 */
public class GEKOStreamView
{
   public static final int IN  = 0;
   public static final int OUT = 1;

   private static String blanks = "            ";
   private static int indent = 2;

   GEKOTokenizer in;
   PrintWriter out;
   StringBuffer sb;
   String current_frame;
   File file_name;

   public GEKOStreamView(int io, File f) throws KAFrameException
   {
      initialize(io, f);
   }

   public GEKOStreamView(int io, String f) throws KAFrameException
   {
      initialize(io, new File(f));
   }

   private void initialize(int io, File f) throws KAFrameException
   {
      file_name = f;
      try
      {
         if (io == IN)
         {
            in = new GEKOTokenizer(file_name);
            out = null;
         }
         else
         {
            in = null;
            out = new PrintWriter(new FileOutputStream(file_name));
         }
      }
      catch (FileNotFoundException e)
      {
         throw new KAFrameException(this, KAFrameException.IO_ERROR, e.toString());
      }
      catch (IOException e)
      {
         throw new KAFrameException(this, KAFrameException.IO_ERROR, e.toString());
      }
   }

   public void close() throws KAFrameException
   {
      if (in != null)
         in.close();
      if (out != null)
         out.close();
   }

   /**
   * Walk through the input stream, picking up tokens.  Based on the
   * various slots encountered, create the appropriate frames in the
   * geko under construction and fill in their values.
   * @return A completed knowledge frame for a geko.
   */
   public KnowledgeFrame input() throws KAFrameException, FrameException
   {
      KnowledgeFrame g = new KnowledgeFrame("geko");

      int token_type;

      while (in.nextToken() != GEKOTokenizer.EOF)
      {
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.SOURCE_FRAME:
            g.set("Source Frame", read_source_frame());
            break;
         case GEKOTokenizer.TECHNICAL_FRAME:
            g.set("Technical Frame", read_technical_frame());
            break;
         case GEKOTokenizer.KNOWLEDGE_FRAME:
            g.set("Knowledge Frame", read_knowledge_frame());
            break;
         default:
            throw new KAFrameException(this,
               KAFrameException.TEXT_BAD_FIRST_LEVEL_SLOT,
               in.slot.name + in.get_file_info());
         }
      }
      return g;
   }

   /* Methods to support input */

   /**
   * The tokenizer is expecting a value at this point, so read
   * it.
   * @return The string value read.
   */
   private String read_value() throws KAFrameException, FrameException
   {
      // A slot was read, and it's asking for the value.

      if (in.nextToken() != GEKOTokenizer.VALUE)
         throw new KAFrameException(this,
            KAFrameException.TEXT_VALUE_EXPECTED,
            in.get_file_info());
      else
         return in.value.trim();
   }

   /* All the remaining functions know how to deal with the different
      types of frames and lists that are encountered in the input
      stream, and maps them to their appropriate frames. */

   private KnowledgeFrame read_source_frame() throws KAFrameException, FrameException
   {
      KnowledgeFrame f = new KnowledgeFrame("source frame");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.TITLE:
            f.set("Title", read_value());
            break;
         case GEKOTokenizer.AUTHOR:
            f.set("Author", read_person());
            break;
         case GEKOTokenizer.SOURCE_CITATIONS:
            do_source_citations(f);
            break;
         case GEKOTokenizer.SUPPORT_CITATIONS:
            do_support_citations(f);
            break;
         case GEKOTokenizer.KNOWLEDGE_NARRATIVE:
            f.set("Knowledge Narrative", read_value());
            break;
         case GEKOTokenizer.KEYWORDS:
            do_keywords(f);
            break;
         case GEKOTokenizer.SOURCE_FRAME_COMMENTS:
            f.set("Source Frame Comments", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return f;
   }

   private KnowledgeFrame read_technical_frame() throws KAFrameException, FrameException
   {
      KnowledgeFrame f = new KnowledgeFrame("technical frame");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.FILE_NAME:
            f.set("FileName", read_value());
            break;
         case GEKOTokenizer.SUBCLASS:
            f.set("SubClass", read_value());
            break;
         case GEKOTokenizer.STATUS:
            f.set("Status", read_value());
            break;
         case GEKOTokenizer.VERSION_NUMBER:
            f.set("Version Number", read_value());
            break;
         case GEKOTokenizer.VERSION_DATE:
            f.set("Version Date", read_value());
            break;
         case GEKOTokenizer.REVISION_DATE:
            f.set("Revision Date", read_value());
            break;
         case GEKOTokenizer.EXPIRATION_DATE:
            f.set("Expiration Date", read_value());
            break;
         case GEKOTokenizer.CONTRACT_ID_NUMBER:
            f.set("Contract/ID Number", read_value());
            break;
         case GEKOTokenizer.RESTRICTION:
            f.set("Restriction", read_value());
            break;
         case GEKOTokenizer.PEER_REVIEWS:
            do_peer_reviews(f);
            break;
         case GEKOTokenizer.USAGE_LOG:
            do_usage_log(f);
            break;
         case GEKOTokenizer.TECHNICAL_FRAME_COMMENTS:
            f.set("Technical Frame Comments", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return f;
   }

   private KnowledgeFrame read_knowledge_frame() throws KAFrameException, FrameException
   {
      KnowledgeFrame f = new KnowledgeFrame("knowledge frame");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.INDEPENDENT_VARIABLES:
            do_independent_variables(f);
            break;
         case GEKOTokenizer.DEPENDENT_VARIABLES:
            do_dependent_variables(f);
            break;
         case GEKOTokenizer.MODEL_SYSTEM:
            f.set("Model System", read_model_system());
            break;
         case GEKOTokenizer.MAJOR_CONTROLLED_VARIABLES:
            f.set("Controls", do_controlled_variables(f));
            break;
         case GEKOTokenizer.TABLE:
            f.set("Type", "table");
            f.set("Code", read_table());
            break;
         case GEKOTokenizer.RULE:
            f.set("Type", "rule");
            f.set("Code", "rule: " + read_value());
            break;
         case GEKOTokenizer.FUZZY_RULE:
            f.set("Type", "fuzzy rule");
            f.set("Code", read_value());
            break;
         case GEKOTokenizer.FORMULA:
            f.set("Type", "formula");
            f.set("Code", read_value());
            break;
         case GEKOTokenizer.DECLARATIVE_STATEMENTS:
            f.set("Declared Relations", "comment: " + read_value());
            break;
         case GEKOTokenizer.KNOWLEDGE_FRAME_COMMENTS:
            f.set("Knowledge Frame Comments", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return f;
   }


   private KnowledgeFrame read_person() throws KAFrameException, FrameException
   {
      KnowledgeFrame p = new KnowledgeFrame("person");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME:
            p.set("Name", read_value());
            break;
         case GEKOTokenizer.INSTITUTION:
            p.set("Institution", read_value());
            break;
         case GEKOTokenizer.EMAIL:
            p.set("Email", read_value());
            break;
         case GEKOTokenizer.BIOGRAPHY:
            p.set("Biography", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return p;
   }

   private void do_source_citations(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      KnowledgeFrame cit;
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.CITATION:
            f.add_list_item("Source Citations", read_citation());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private void do_support_citations(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      KnowledgeFrame cit;
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.CITATION:
            f.add_list_item("Support Citations", read_citation());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private KnowledgeFrame read_citation() throws KAFrameException, FrameException
   {
      KnowledgeFrame cit = new KnowledgeFrame("citation");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.BODY:
            cit.set("Body", read_value());
            break;
         case GEKOTokenizer.PEER_REVIEWED:
            cit.set("Peer Reviewed", read_value());
            break;
         case GEKOTokenizer.CITATION_CODE:
            cit.set("Citation Code", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return cit;
   }

   /**
   * Pick up the keyword list as a single string value, and then
   * use a new StreamTokenizer to break out the individual
   * keywords.
   */
   private void do_keywords(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      String keyword_list = read_value();
      StreamTokenizer tokens = new StreamTokenizer(
         new StringReader(keyword_list) );
      tokens.resetSyntax();
      tokens.wordChars(0, 255);
      tokens.ordinaryChar(';');

      KnowledgeFrame kw;

      try
      {
         while (tokens.nextToken() != StreamTokenizer.TT_EOF)
         {
            switch (tokens.ttype)
            {
            case StreamTokenizer.TT_WORD:
               kw = new KnowledgeFrame("keyword");
               kw.set("word", tokens.sval.trim());
               f.add_list_item("Keywords", kw);
               break;
            case ';':
               break;
            default:
               throw new KAFrameException(this,
                  KAFrameException.BAD_KEYWORD_LIST, keyword_list);
            }
         }
      }
      catch (IOException e)
      {
         throw new KAFrameException(this, KAFrameException.IO_ERROR, e.getMessage());
      }
   }

   private void do_peer_reviews(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.REVIEW:
            f.add_list_item("Peer Reviews", read_review());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private KnowledgeFrame read_review() throws KAFrameException, FrameException
   {
      KnowledgeFrame r = new KnowledgeFrame("review");
      r.set("Reviewer", read_person());

      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.COMMENTS:
            r.set("Comments", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return r;
   }

   private void do_usage_log(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.SESSION:
            f.add_list_item("Usage Log", read_session());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private KnowledgeFrame read_session() throws KAFrameException, FrameException
   {
      KnowledgeFrame s = new KnowledgeFrame("session");
      s.set("User", read_person());

      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME_OF_APPLICATION:
            s.set("Name of Application", read_value());
            break;
         case GEKOTokenizer.DEVELOPER_NAME:
            s.set("Developer Name", read_value());
            break;
         case GEKOTokenizer.DEVELOPER_EMAIL:
            s.set("Developer Email", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return s;
   }

   private void do_independent_variables(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.VARIABLE:
            f.add_list_item("Independent Variables", read_variable());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private void do_dependent_variables(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.VARIABLE:
            f.add_list_item("Dependent Variables", read_variable());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
   }

   private String do_controlled_variables(KnowledgeFrame f) throws KAFrameException, FrameException
   {
      boolean done = false;
      StringBuffer sb = new StringBuffer("comment: ");
      KnowledgeFrame v;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.VARIABLE:
            v = read_variable();
            f.add_list_item("Major Controlled Variables", v);
            sb.append(" " + (String)v.get("Name"));
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return sb.toString();
   }

   private KnowledgeFrame read_variable() throws KAFrameException, FrameException
   {
      KnowledgeFrame v = new KnowledgeFrame("variable");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME:
            v.set("Name", read_value());
            break;
         case GEKOTokenizer.TYPE:
            v.set("Type", read_value());
            break;
         case GEKOTokenizer.DESCRIPTION:
            v.set("Description", read_value());
            break;
         case GEKOTokenizer.LIMITS:
            v.set("Limits", read_value());
            break;
         case GEKOTokenizer.FUZZY_SETS:
            boolean fuzzy_done = false;
            while (! fuzzy_done)
            {
               in.nextToken();
               switch(in.slot.id)
               {
               case GEKOTokenizer.FUZZY_SET:
                  v.add_list_item("Fuzzy Sets", read_fuzzy_set());
                  break;
               default:
                  in.pushBack();
                  fuzzy_done = true;
               }
            }
            break;
         default:
            in.pushBack();
            done = true;
         }
      }

      if (! v.slot_exists("Name"))
         v.set("Name", "");
      if (! v.slot_exists("Description"))
         v.set("Description", "");
      return v;
   }

   private KnowledgeFrame read_fuzzy_set() throws KAFrameException, FrameException
   {
      KnowledgeFrame cit = new KnowledgeFrame("fuzzy set");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME:
            cit.set("Name", read_value());
            break;
         case GEKOTokenizer.TYPE:
            cit.set("Type", read_value());
            break;
         case GEKOTokenizer.SHAPE:
            cit.set("Shape", read_value());
            break;
         case GEKOTokenizer.FORMULA:
            cit.set("Formula", read_value());
            break;
         case GEKOTokenizer.HEDGES:
            boolean hedges_done = false;
            while (! hedges_done)
            {
               in.nextToken();
               switch(in.slot.id)
               {
               case GEKOTokenizer.HEDGE:
                  cit.add_list_item("Hedges", read_hedge());
                  break;
               default:
                  in.pushBack();
                  hedges_done = true;
               }
            }
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return cit;
   }

   private KnowledgeFrame read_hedge() throws KAFrameException, FrameException
   {
      KnowledgeFrame cit = new KnowledgeFrame("hedge");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME:
            cit.set("Name", read_value());
            break;
         case GEKOTokenizer.FORMULA:
            cit.set("Formula", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      return cit;
   }

   private String read_model_system() throws KAFrameException, FrameException
   {
      KnowledgeFrame m = new KnowledgeFrame("model_system");
      KnowledgeFrame v;

      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.NAME:
            m.set("Name", read_value());
            break;
         case GEKOTokenizer.DESCRIPTION:
            m.set("Description", read_value());
            break;
         case GEKOTokenizer.VARIABLE:
            v = read_variable();
            m.set("Name", v.get("Name"));
            m.set("Description", v.get("Description"));
            break;
         default:
            in.pushBack();
            done = true;
         }
      }
      // Note bug in KH-I, no ;; after Name slot value,
      // so description gets sucked up in Name.  OK for us.
System.out.println("Model System output:");
System.out.println("comment: " + (String)m.get("Name"));
      return "comment: " + (String)m.get("Name");
   }

   private String read_table() throws KAFrameException, FrameException
   {
      // The schema for KH gekos does not support different slots
      // for different occasions, so the structure in a table
      // must be formatted into a string whose value is then
      // put into the code slot.

      // Also note that ;; are often missing from AIBS
      // tables, so the special read_value routine.
      KnowledgeFrame tab = new KnowledgeFrame("table");
      boolean done = false;

      while (! done)
      {
         in.nextToken();
         switch(in.slot.id)
         {
         case GEKOTokenizer.FRAMEID:
         case GEKOTokenizer.TIMESTAMP:
            read_value();
            break;
         case GEKOTokenizer.DEFINITION:
            tab.set("Definition", read_value());
            break;
         case GEKOTokenizer.DATA:
            tab.set("Data", read_value());
            break;
         case GEKOTokenizer.INTERPOLATE:
            tab.set("Interpolate", read_value());
            break;
         default:
            in.pushBack();
            done = true;
         }
      }

      System.out.println("Definition: " + (String)tab.get("Definition"));
      System.out.println("Data: " + (String)tab.get("Data"));

      return "table: " + (String)tab.get("Definition") +
            "\n" +
            (String)tab.get("Data");
   }
}
