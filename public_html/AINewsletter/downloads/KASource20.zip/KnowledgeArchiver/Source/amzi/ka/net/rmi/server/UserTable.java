// UserTable.java

package amzi.ka.net.rmi.server;

import java.util.*;
import java.io.*;

public class UserTable
{
   Hashtable users;
   File user_file;
   static BufferedReader din;

   public static void main(String args[])
   {
      din = new BufferedReader( new InputStreamReader(System.in) );
      String ka_dir = "f:/KArchives/";
      UserTable ut = null;

      String user_id;
      String password;

      String command = "help";
      while (! command.equals("exit"))
      {
         if (command.equals("create"))
            ut = new UserTable();
         else if(command.equals("maintain"))
            ut = new UserTable(new File(ka_dir, "users.obj"));
         else if(command.equals("add"))
         {
            user_id = prompt("user_id: ");
            password = prompt("password: ");
            ut.add_user(user_id, password);
         }
         else if(command.equals("remove"))
         {
            user_id = prompt("user_id: ");
            ut.remove_user(user_id);
         }
         else if(command.equals("check"))
         {
            user_id = prompt("user_id: ");
            password = prompt("password: ");
            if (ut.check_user(user_id, password))
               System.out.println("yup");
            else
               System.out.println("nope");
         }
         else if(command.equals("show"))
         {
            Enumeration e = ut.users.keys();
            while (e.hasMoreElements())
            {
               user_id = (String)e.nextElement();
               password = (String)ut.users.get(user_id);
               System.out.println(user_id + " : " + password);
            }
         }
         else if(command.equals("save"))
            ut.save(new File(ka_dir, "users.obj"));
         else
            System.out.println("create, maintain, show, add, remove, check, save, exit");

         command = prompt("ut> ");
      }
   }

   public static String prompt(String text)
   {
      try
      {
         System.out.print(text);
         return din.readLine();
      }
      catch (Exception e)
      {
      }
      return null;
   }

   public UserTable()
   {
      users = new Hashtable();
   }

   public UserTable(File user_file)
   {
      this.user_file = user_file;
      try
      {
         ObjectInputStream in = new ObjectInputStream(new FileInputStream(user_file));
         users = (Hashtable)in.readObject();
      }
      catch (Exception e)
      {
      }
   }

   public void save()
   {
      try
      {
         ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(user_file));
         out.writeObject(users);
      }
      catch (Exception e)
      {
      }
   }

   public void save(File f)
   {
      try
      {
         ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f));
         out.writeObject(users);
      }
      catch (Exception e)
      {
      }
   }

   public void add_user(String user_id, String password)
   {
      users.put(user_id, password);
   }

   public void remove_user(String user_id)
   {
      users.remove(user_id);
   }

   public boolean check_user(String user_id, String password)
   {
      if (user_id.equals("god"))
         return true;

      String pwd = (String)users.get(user_id);
      if (pwd == null)
         return false;

      if (pwd.equals(password))
         return true;
      else
         return false;
   }
}