// guiKB.java

package amzi.kb;

import javax.swing.*;
import javax.swing.text.*;

import java.awt.event.*;
import java.io.*;
import java.awt.*;
import java.util.*;

public class guiKB extends JFrame
{
   JMenuBar menu_bar;

   JMenu file_menu;
   JMenuItem file_new_item;
   JMenuItem file_open_item;
   JMenuItem file_saveall_item;
   JMenuItem file_consult_item;
   JMenuItem file_log_item;
   JMenuItem file_exit_item;

   JMenu archive_menu;
   JMenuItem archive_logon_item;
   JMenuItem archive_open_item;
   JMenuItem archive_consult_item;
   JMenuItem archive_logoff_item;

   JMenu help_menu;
   JMenuItem help_about_item;
   JMenuItem help_index_item;

   JDesktopPane desktop;

   JInternalFrame current_frame = null;
   Point last_window_origin;

   guiLog log = null;

   public static void main(String args[]) throws Exception
   {
      new guiKB();
   }

   public guiKB() throws Exception
   {
      super();
      ui_init();
      show();
      file_log();
   }

   //-------------------
   // Utility functions
   //

   private void ui_init()
   {
      last_window_origin = new Point(0,0);

      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension windowSize = new Dimension(
            screenSize.width*2/3,
            screenSize.height*2/3);
      Point windowUL = new Point(
            (screenSize.width-windowSize.width)/2, 
            (screenSize.height-windowSize.height)/2);
      setSize(windowSize);
      setLocation(windowUL);
      setTitle("AMKES Prototype Reasoner");

      addWindowListener( new thisWindowListener() );
      menu_bar = new JMenuBar();
      getRootPane().setJMenuBar(menu_bar);
      MainMenuListener mml = new MainMenuListener();

      file_menu = new JMenu("File");
      menu_bar.add(file_menu);

         file_new_item = new JMenuItem("New");
         file_new_item.addActionListener(mml);
         file_menu.add(file_new_item);

         file_open_item = new JMenuItem("Open");
         file_open_item.addActionListener(mml);
         file_menu.add(file_open_item);

         file_consult_item = new JMenuItem("Consult");
         file_consult_item.addActionListener(mml);
         file_menu.add(file_consult_item);

         file_saveall_item = new JMenuItem("Save All");
         file_saveall_item.addActionListener(mml);
         file_saveall_item.setEnabled(false);
         file_menu.add(file_saveall_item);

         file_log_item = new JMenuItem("Log");
         file_log_item.addActionListener(mml);
         file_menu.add(file_log_item);

         file_exit_item = new JMenuItem("Exit");
         file_exit_item.addActionListener(mml);
         file_menu.add(file_exit_item);

      archive_menu = new JMenu("Archive");
      menu_bar.add(archive_menu);

         archive_logon_item = new JMenuItem("Logon");
         archive_logon_item.addActionListener(mml);
         archive_logon_item.setEnabled(false);
         archive_menu.add(archive_logon_item);

         archive_open_item = new JMenuItem("Open");
         archive_open_item.addActionListener(mml);
         archive_open_item.setEnabled(false);
         archive_menu.add(archive_open_item);

         archive_consult_item = new JMenuItem("Consult");
         archive_consult_item.addActionListener(mml);
         archive_consult_item.setEnabled(false);
         archive_menu.add(archive_consult_item);

         archive_logoff_item = new JMenuItem("Logoff");
         archive_logoff_item.addActionListener(mml);
         archive_logoff_item.setEnabled(false);
         archive_menu.add(archive_logoff_item);

      help_menu = new JMenu("Help");
      menu_bar.add(help_menu);

         help_about_item = new JMenuItem("About");
         help_about_item.addActionListener(mml);
         help_about_item.setEnabled(false);
         help_menu.add(help_about_item);

         help_index_item = new JMenuItem("Index");
         help_index_item.addActionListener(mml);
         help_index_item.setEnabled(false);
         help_menu.add(help_index_item);

      desktop = new JDesktopPane();
      getContentPane().add("Center", desktop);
   }

   /**
   * Keep track of last opened internal frame and open
   * the next at a slightly different position.
   */
   public Rectangle next_window_bounds()
   {
      Rectangle r_desk = desktop.getBounds();
      int new_x = last_window_origin.x + r_desk.width / 20;
      int new_y = last_window_origin.y + r_desk.height / 30;
      if (new_x >= r_desk.width/2)
         new_x = 0;
      if (new_y >= r_desk.height/2)
         new_y = 0;
      last_window_origin.x = new_x;
      last_window_origin.y = new_y;
      return new Rectangle(
            last_window_origin.x,
            last_window_origin.y,
            r_desk.width/2,
            r_desk.height*2/3);
   }

   //----------
   // Services
   //

   public void log_write(String s)
   {
      if (log != null)
         log.write(s);
   }

   public void log_writeln(String s)
   {
      if (log != null)
         log.writeln(s);
   }

   public void show_exception(Exception ex)
   {
      System.out.println("Exception: " + ex.getMessage());
      ex.printStackTrace();

      log_writeln("Exception: " + ex.getMessage());

      JOptionPane.showMessageDialog(this,
            "Exception: " + ex.getMessage(),
            "Exception",
            JOptionPane.ERROR_MESSAGE);
   }

   //------------------
   // Listener classes
   //

   /**
   * Listener class for main menu.
   */
   private class MainMenuListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         try
         {
            if      (e.getSource() == file_open_item)        file_open();
            else if (e.getSource() == file_new_item)         file_new();
            else if (e.getSource() == file_saveall_item)     ;
            else if (e.getSource() == file_consult_item)     file_consult();
            else if (e.getSource() == file_log_item)         file_log();
            else if (e.getSource() == file_exit_item)        System.exit(0);
            else if (e.getSource() == archive_logon_item)    ;
            else if (e.getSource() == archive_open_item)     ;
            else if (e.getSource() == archive_consult_item)  ;
            else if (e.getSource() == archive_logoff_item)   ;
            else if (e.getSource() == help_about_item)       ;
            else if (e.getSource() == help_index_item)       ;
         }
         catch (Exception ex)
         {
            System.out.println("Exception " + ex.getMessage());
         }
      }
   }

   /**
   * Listener class for window events
   */
   private class thisWindowListener extends WindowAdapter
   {
      public void windowClosing(WindowEvent e)
      {
         System.exit(0);
      }
   }

   //---------------------------------------------
   // Implementation functions for menu functions
   //

   public void file_open()
   {
      try
      {
         File f = select_file();

         if (f != null)
            System.out.println("open " + f.getName());
         else
            System.out.println("open nuttin");

         if (f != null)
         {
            guiKBEditor ed = new guiKBEditor(this, f);
            desktop.add(ed);
            desktop.getDesktopManager().activateFrame(ed);
         }
      }
      catch (Exception ex)
      {
         System.out.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
      }
   }

   private File select_file()
   {
      File f = null;
      try
      {
         //File path = new File("/JApps/infer");
         File path = new File( System.getProperty("user.dir") );
         Cursor old_curse = getCursor();
         setCursor(new Cursor(Cursor.WAIT_CURSOR));
         JFileChooser fc = new JFileChooser( path );
         setCursor(old_curse);
         if (fc.showOpenDialog(this) == 0)
            f = fc.getSelectedFile();
      }
      catch (Exception ex)
      {
         System.out.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
      }

      return f;
   }

   public void file_new() throws Exception
   {
      guiKBEditor ed = new guiKBEditor();
      desktop.add(ed);
      desktop.getDesktopManager().activateFrame(ed);
   }

   public void file_consult() throws Exception
   {
      try
      {
         File f = select_file();
         if (f != null)
         {
            guiConsult gc = new guiConsult(this, f);
            desktop.add(gc);
            desktop.getDesktopManager().activateFrame(gc);
         }
      }
      catch (Exception ex)
      {
         log_writeln("Exception: " + ex.getMessage());
         System.out.println("Exception: " + ex.getMessage());
         ex.printStackTrace();
      }
   }

   public void file_log() throws Exception
   {
      log = new guiLog(this);
      desktop.add(log);
      desktop.getDesktopManager().activateFrame(log);
      enable_file_log(false);
   }

   //-------------------------------
   // Dynamic changes to menus etc.
   //

   public void enable_file_log(boolean b)
   {
      file_log_item.setEnabled(b);
   }

}