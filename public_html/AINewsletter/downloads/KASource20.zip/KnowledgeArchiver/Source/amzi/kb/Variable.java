// Variable.java

package amzi.kb;

import java.util.*;
import java.io.*;

public class Variable implements Serializable
{
   public final static int V_STRING = 0;
   public final static int V_INT = 1;
   public final static int V_FLOAT = 2;
   public final static int V_BOOLEAN = 3;

   public final static int V_ALSO_SET = 100;
   public final static int V_ALT_GOAL = 101;

   VariableKey key;
   String name;
   int type;
   boolean multivalued;
   Vector menu;
   Vector equivalents = null;
   Vector subsets = null;
   Vector supersets = null;

   public Variable(VariableKey key, String name, int type, boolean multi)
   {
      init(key, name, type, multi);
   }

   public Variable(String name, int type, boolean multi)
   {
      init(new VariableKey(name), name, type, multi);
   }

   public Variable(String n)
   {
      init(new VariableKey(n), n, V_STRING, false);
   }

   public Variable(VariableKey k, String n)
   {
      init(k, n, V_STRING, false);
   }

   public Variable()
   {
      init(null, null, V_STRING, false);
   }

   private void init(VariableKey key, String name, int type, boolean multi)
   {
      this.key = key;
      this.name = name;
      this.type = type;
      this.multivalued = multi;
      if (type == V_STRING)
         menu = new Vector();
      else
         menu = null;
   }

   public void set_key(VariableKey k) { key = k; }
   public void set_name(String n) { name = n; }
   public void set_type(int t) { type = t; }
   public void set_multivalued(boolean b) { multivalued = b; }
   public void set_menu(Vector m) { menu = m; }


   public VariableKey get_key() { return key; }
   public String get_name() { return name; }
   public int get_type() { return type; }
   public Vector get_menu() { return menu; }

   public boolean is_multivalued() { return multivalued; }
   public boolean is_singlevalued() { return (! multivalued); }

   public void add_choice(Object c)
   {
      if (type != V_STRING)
         return;

      for (int i=0; i<menu.size(); i++)
      {
         if (menu.elementAt(i).equals(c))
            return;
      }
      menu.addElement(c);
   }


   public void set_equivalent(Variable v)
   {
      if (equivalents == null)
         equivalents = new Vector();
      equivalents.addElement(v);
   }

   public void set_subset(Variable v)
   {
      if (subsets == null)
         subsets = new Vector();
      subsets.addElement(v);
   }

   public void set_superset(Variable v)
   {
      if (supersets == null)
         supersets = new Vector();
      supersets.addElement(v);
   }

   public Enumeration get_equivalents() { return equivalents.elements(); }
   public Enumeration get_supersets() { return supersets.elements(); }
   public Enumeration get_subsets() { return subsets.elements(); }

   public boolean has_equivalents() { return (equivalents != null); }
   public boolean has_supersets() { return (supersets != null); }
   public boolean has_subsets() { return (subsets != null); }

   public Vector related_vars(int relation)
   {

      if (relation == V_ALSO_SET &&
            ! has_equivalents() &&
            ! has_supersets())
         return null;

      if (relation == V_ALT_GOAL &&
            ! has_equivalents() &&
            ! has_subsets())
         return null;

      Stack todo = new Stack();
      Vector done = new Vector();
      Variable v1, v2;
      Enumeration e;

      todo.push(this);
      while (! todo.empty())
      {
         v1 = (Variable)todo.pop();
         done.addElement(v1);

         if (v1.has_equivalents())
         {
            e = v1.get_equivalents();
            while (e.hasMoreElements())
            {
               v2 = (Variable)e.nextElement();
               if (todo.search(v2) < 0 && ! done.contains(v2))
                  todo.push(v2);
            }
         }

         e = null;
         switch (relation)
         {
         case V_ALSO_SET:
            if (v1.has_supersets())
               e = v1.get_supersets();
            break;
         case V_ALT_GOAL:
            if (v1.has_subsets())
               e = v1.get_subsets();
            break;
         default:
            break;
         }

         if (e != null)
         {
            while (e.hasMoreElements())
            {
               v2 = (Variable)e.nextElement();
               if (todo.search(v2) < 0 && ! done.contains(v2))
                  todo.push(v2);
            }
         }
      }

      // take out the first element, which is 'this'
      done.removeElementAt(0);
      if (done.isEmpty())
         return null;
      else
         return done;
   }

   public String prompt()
   {
      StringBuffer sb = new StringBuffer("What is the value of: ");
      sb.append(name);
      if (menu.size() > 0)
      {
         sb.append("[");
         for (int i=0; i<menu.size(); i++)
         {
            sb.append(menu.elementAt(i).toString());
            if (i<menu.size()-1)
               sb.append(",");
         }
         sb.append("]");
      }
      return sb.toString();
   }

   public void print(PrintStream o)
   {
      o.println(key.key);
      o.println(toString());
   }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();
      sb.append("VARIABLE " + name + " ");
      switch(type)
      {
      case V_STRING:
         sb.append("string");
         break;
      case V_INT:
         sb.append("int");
         break;
      case V_BOOLEAN:
         sb.append("boolean");
         break;
      case V_FLOAT:
         sb.append("float");
         break;
      }
      if (multivalued)
         sb.append(" multi");
      if (menu != null  && menu.size() > 0)
      {
         sb.append(" [");
         sb.append(menu.elementAt(0));
         for (int i=1; i<menu.size(); i++)
            sb.append(", " + menu.elementAt(i));
         sb.append("]");
      }
      sb.append(";");
      return sb.toString();
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}