// CodeBlock.java

public class CodeBlock
{
   Vector conditions;
   Vector actions;

   public CodeBlock()
   {
      conditions = new Vector();
      actions = new Vector();
   }
}