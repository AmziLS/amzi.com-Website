// Action.java

package amzi.kb;

import java.io.*;

public class Action implements Serializable
{
   private VariableKey v_key;
   private Object value;

   public Action(VariableKey k)
   {
      v_key = k;
      value = null;
   }

   public Action(VariableKey k, Object val)
   {
      v_key = k;
      value = val;
   }

   public Action(String k)
   {
      v_key = new VariableKey(k);
      value = null;
   }

   public Action(String k, Object val)
   {
      v_key = new VariableKey(k);
      value = val;
   }

   public void set_value(Object v) { value = v; }
   public VariableKey get_variable() { return v_key; }

   public String toString()
   {
      return v_key.get_name() + " = " + value.toString();
   }

   public void print(PrintStream o)
   {
      o.println(this.toString());
   }

   public KBMessage doit(Consultation c)
   {
      //c.log("ACTION: " + var_name + " = " + value.toString());
      KBMessage kmess;
      Object final_value;

      if (value.getClass() == KBClasses.cVariableKey)
      {
         final_value = c.known_value((VariableKey)value);
         if (final_value == null)
            return new KBMessage(KBMessage.NEED_VALUE, (VariableKey)value);
      }
      //else if (value.getClass() == KBClasses.cVariable)
      //{
      //   final_value = c.known_value(value.toString());
      //   if (final_value == null)
      //      return new KBMessage(KBMessage.NEED_VALUE, value.toString());
      //}
      else if (value.getClass() == KBClasses.cExpression)
      {
         kmess = ((Expression)value).evaluate(c);
         if (kmess.type == KBMessage.CALCULATED)
            final_value = kmess.value;
         else
            return kmess;
      }
      else
         final_value = value;

      c.set_value(v_key, final_value, true);

      return new KBMessage(KBMessage.SUCCESS, v_key, final_value);
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}