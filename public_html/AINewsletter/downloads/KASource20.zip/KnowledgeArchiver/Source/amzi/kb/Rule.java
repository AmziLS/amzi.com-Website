// Rule.java

package amzi.kb;

import java.io.*;
import java.util.*;

public class Rule implements Cloneable, Serializable
{
   private String name;
   private VariableKey dependent_variable;
   //private Vector independent_variables;
   private Vector preconditions;
   private Test conditions;
   private Action action;

   public Rule(String n)
   {
      name = n;
      //independent_variables = new Vector();
      conditions = null;
      preconditions = new Vector();
      dependent_variable = null;
      action = null;
   }

   public Rule()
   {
      name = "";
      //independent_variables = new Vector();
      conditions = null;
      preconditions = new Vector();
      dependent_variable = null;
      action = null;
   }

   public Object clone()
   {
      Rule r = new Rule(name);
      if (dependent_variable != null)
         r.set_dependent_variable(dependent_variable);
      //for (int i=0; i<independent_variables.size(); i++)
      //   r.add_independent_variable(
      //      (VariableKey)independent_variables.elementAt(i) );
      for (int i=0; i<preconditions.size(); i++)
         r.add_precondition( (Test)preconditions.elementAt(i) );
      if (conditions != null)
         r.set_conditions(conditions);
      if (action != null)
         r.set_action(action);

      return r;
   }

   public KBMessage get_value(Consultation c) throws KBException
   {
      KBMessage kmess;
      //c.log("Trying rule " + name);

      for (int i=0; i<preconditions.size(); i++)
      {
         kmess = ((Test)preconditions.elementAt(i)).check(c);
         switch (kmess.type)
         {
            case KBMessage.SUCCESS:
               break;
            case KBMessage.FAILURE:
            case KBMessage.NEED_VALUE:
               return kmess;
            default:
               throw new KBException(this, KBException.UNEXPECTED_RULE_RETURN);
         }
      }

      if (conditions != null)
      {
         kmess = conditions.check(c);
         switch (kmess.type)
         {
            case KBMessage.SUCCESS:
               break;
            case KBMessage.FAILURE:
            case KBMessage.NEED_VALUE:
               return kmess;
            default:
               throw new KBException(this, KBException.UNEXPECTED_RULE_RETURN);
         }
      }

      kmess = action.doit(c);
      return kmess;
   }

   public String get_name() { return name; }
   public void set_name(String n) { name = n; }
   public void set_conditions(Test t) { conditions = t; }
   public void add_precondition(Test t) { preconditions.addElement(t); }
   public void set_action(Action a)
   {
      this.action = a;
      dependent_variable = a.get_variable();
   }

   public VariableKey dependent_variable() { return dependent_variable; }
   //public Vector independent_variables() { return independent_variables; }

   public void set_dependent_variable(VariableKey v) { dependent_variable = v; }
   public void set_dependent_variable(String v) { dependent_variable = new VariableKey(v); }

   //public void add_independent_variable(String v)
   //{
   //   add_independent_variable(new VariableKey(v));
   //}

   //public void add_independent_variable(VariableKey v)
   //{
   //   for (int i=0; i<independent_variables.size(); i++)
   //   {
   //      if (independent_variables.elementAt(i).equals(v))
   //         return;
   //   }
   //   independent_variables.addElement(v);
   //}

   public String toString()
   {
      StringBuffer sb = new StringBuffer("RULE " + name + ":\n");
      for (int i=0; i<preconditions.size(); i++)
      {
         sb.append("Precondition\n");
         sb.append("  " + ((Test)preconditions.elementAt(i)).toString() + "\n");
      }
      if (conditions != null)
      {
         sb.append("IF\n");
         sb.append("  " + conditions.toString() + "\n");
      }
      else
         sb.append("IF true\n");
      sb.append("THEN\n");
      sb.append("  " + action.toString());
      sb.append(";");
      return sb.toString();
   }

   public void print(PrintStream o)
   {
      o.println("RULE " + name);
      o.println("dependent_variable = " + dependent_variable);
      //o.println("independent_variables = ");
      //for (int i=0; i<independent_variables.size(); i++)
      //   o.println("  " + independent_variables.elementAt(i));
      if (preconditions != null)
      {
         for (int i=0; i<preconditions.size(); i++)
         {
            o.println("PRECONDITION");
            ((Test)preconditions.elementAt(i)).print(o);
         }
      }
      if (conditions != null)
      {
         o.println("IF");
         conditions.print(o);
      }
      else
      {
         o.println("IF true");
      }

      o.println("THEN");
      action.print(o);
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}
