// PSECode.java

package amzi.kb;

import amzi.frames.*;

import java.util.*;
import java.io.*;

/**
* Code is just an array of rules which might
* have come from a single geko.
*/
public class Code implements Serializable
{
   public Rule[] rules;

   public Code(int size)
   {
      rules = new Rule[size];
   }

   public Code(Rule[] rs)
   {
      rules = new Rule[rs.length];
      for (int i=0; i<rs.length; i++)
      {
         rules[i] = rs[i];
      }
   }

   public Code(Vector v)
   {
      rules = new Rule[v.size()];
      for (int i=0; i<v.size(); i++)
      {
         rules[i] = (Rule)v.elementAt(i);
      }
   }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();

      for (int i=0; i<rules.length; i++)
      {
         sb.append(rules[i].toString());
         sb.append("\n");
      }

      return sb.toString();
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}