// guiActionEventDispatcher.java

package amzi.kb;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
* A dummy component used to dispatch events that enable
* components to talk to each other using events.
*/
public class guiActionEventDispatcher extends Component
{
   ActionListener actionListener = null;

   public void addActionListener(ActionListener l)
   {
      actionListener = AWTEventMulticaster.add(actionListener, l);
   }

   public void removeActionListener(ActionListener l)
   {
      actionListener = AWTEventMulticaster.remove(actionListener, l);
   }

   public void processEvent(String command)
   {
      // when event occurs which causes "action" semantic
      if (actionListener != null)
      {
         System.out.println("Doing the dispatch thing: " + command);
         actionListener.actionPerformed(new ActionEvent(this, AWTEvent.RESERVED_ID_MAX+2, command));
      }         
   }
}
 