// KBMessage.java

package amzi.kb;

import java.util.*;

public class KBMessage
{
   public static final int SUCCESS = 0;
   public static final int FAILURE = 1;
   public static final int NEED_VALUE = 2;
   public static final int ASK_USER = 3;
   public static final int GOAL = 4;
   public static final int EXCEPTION = 5;
   public static final int NO_GOAL = 6;
   public static final int MULTIVALUED_DONE = 7;
   public static final int CALCULATED = 8;

   public static String messes[] =
   {
      "SUCCESS",
      "FAILURE",
      "NEED_VALUE",
      "ASK_USER",
      "GOAL",
      "EXCEPTION",
      "NO_GOAL",
      "MULTIVALUED_DONE",
      "CALCULATED",
   };

   public int type;
   public VariableKey v_key = null;
   public Object value = null;

   public KBMessage(int t, VariableKey k, Object v)
   {
      type = t;
      v_key = k;
      value = v;
   }

   public KBMessage(int t, VariableKey k)
   {
      type = t;
      v_key = k;
   }

   public KBMessage(int t)
   {
      type = t;
   }

   public String toString()
   {
      StringBuffer s = new StringBuffer(messes[type]);
      if (v_key != null)
         s.append(" " + v_key.get_name());
      if (value != null)
      {
         if (type == GOAL)
            s.append(" (" + ((Vector)value).size() + " rules to try)");
         else
            s.append(" " + value.toString());
      }
      return s.toString();
   }
}