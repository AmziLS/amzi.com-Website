// Test.java

package amzi.kb;

import java.io.*;
import java.util.*;

public class Test implements Serializable
{
   public final static int OR  = 0;
   public final static int AND = 1;
   public final static int EQ  = 2;
   public final static int GT  = 3;
   public final static int LT  = 4;
   public final static int GTE = 5;
   public final static int LTE = 6;
   public final static int INCLUDES = 7;
   public final static int NEQ = 8;
   public final static int SUBSTRING = 9;

   public static String ops[] =
   {
      "OR",
      "AND",
      "EQ",
      "GT",
      "LT",
      "GTE",
      "LTE",
      "INCLUDES",
      "NEQ",
      "SUBSTRING",
   };

   int op;
   Object arg1;
   Object arg2;

   public Test(int op)
   {
      this.op = op;
      arg1 = null;
      arg2 = null;
   }

   public Test(int op, Object a1, Object a2)
   {
      this.op = op;
      arg1 = a1;
      arg2 = a2;
   }

   public KBMessage check(Consultation c) throws KBException
   {
      KBMessage m1;

      switch(op)
      {
      case OR:
         m1 = ((Test)arg1).check(c);
         if (m1.type == KBMessage.SUCCESS ||
             m1.type == KBMessage.NEED_VALUE)
             return m1;
         else
            return ((Test)arg2).check(c);
      case AND:
         m1 = ((Test)arg1).check(c);
         if (m1.type == KBMessage.NEED_VALUE ||
             m1.type == KBMessage.FAILURE)
            return m1;
         else
            return ((Test)arg2).check(c);
      default:
         return compare(c);
      }
   }

   private KBMessage compare(Consultation c) throws KBException
   {
      Object o1, o2;
      KBMessage kmess;

      if (arg1.getClass() == KBClasses.cVariableKey)
      {
         o1 = c.known_value((VariableKey)arg1);
         if (o1 == null)
            return new KBMessage(KBMessage.NEED_VALUE, (VariableKey)arg1);
      }
      else if (arg1.getClass() == KBClasses.cExpression)
      {
         kmess = ((Expression)arg1).evaluate(c);
         if (kmess.type == KBMessage.CALCULATED)
            o1 = kmess.value;
         else
            return kmess;
      }
      else
         o1 = arg1;

      if (arg2.getClass() == KBClasses.cVariableKey)
      {
         o2 = c.known_value((VariableKey)arg2);
         if (o2 == null)
            return new KBMessage(KBMessage.NEED_VALUE, (VariableKey)arg2);
      }
      else if (arg2.getClass() == KBClasses.cExpression)
      {
         kmess = ((Expression)arg2).evaluate(c);
         if (kmess.type == KBMessage.CALCULATED)
            o2 = kmess.value;
         else
            return kmess;
      }
      else
         o2 = arg2;

      boolean b;

      Class class_o1 = o1.getClass();

      if      (class_o1 == KBClasses.cInteger) b = compare((Integer)o1, o2);
      else if (class_o1 == KBClasses.cDouble)  b = compare((Double)o1, o2);
      else if (class_o1 == KBClasses.cString)  b = compare((String)o1, o2);
      else if (class_o1 == KBClasses.cBoolean) b = compare((Boolean)o1, o2);
      else if (class_o1 == KBClasses.cVector)  b = compare((Vector)o1, o2);
      else b = compare(o1, o2);


      if (b)
      {
         //c.log("TEST: matching");
         return new KBMessage(KBMessage.SUCCESS, (VariableKey)arg1, null);
      }
      else
      {
         //c.log("TEST: failing to match " + arg1.toString() + 
         //   ops[op] + arg2.toString());
         return new KBMessage(KBMessage.FAILURE);
      }
   }

   private boolean compare(Integer I1, Object o2) throws KBException
   {
      int i1 = I1.intValue();
      int i2 = ((Number)o2).intValue();
      boolean b = false;

      switch(op)
      {
      case EQ:
         if (i1 == i2)
            b = true;
         break;
      case GT:
         if (i1 > i2)
            b = true;
         break;
      case LT:
         if (i1 < i2)
            b = true;
         break;
      case GTE:
         if (i1 >= i2)
            b = true;
         break;
      case LTE:
         if (i1 <= i2)
            b = true;
         break;
      case NEQ:
         if (i1 != i2)
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   private boolean compare(Double D1, Object o2) throws KBException
   {
      double d1 = D1.doubleValue();
      double d2 = ((Number)o2).doubleValue();
      boolean b = false;

      switch(op)
      {
      case EQ:
         if (d1 == d2)
            b = true;
         break;
      case GT:
         if (d1 > d2)
            b = true;
         break;
      case LT:
         if (d1 < d2)
            b = true;
         break;
      case GTE:
         if (d1 >= d2)
            b = true;
         break;
      case LTE:
         if (d1 <= d2)
            b = true;
         break;
      case NEQ:
         if (d1 != d2)
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   private boolean compare(String s1, Object o2) throws KBException
   {
      String s2 = o2.toString();
      boolean b = false;

      switch(op)
      {
      case EQ:
         if (s1.equals(s2))
            b = true;
         break;
      case NEQ:
         if (! s1.equals(s2))
            b = true;
         break;
      case SUBSTRING:
         if (s2.indexOf(s1) >= 0)
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   private boolean compare(Vector v1, Object o2) throws KBException
   {
      boolean b = false;

      switch(op)
      {
      case INCLUDES:
         if (v1.contains(o2))
            b = true;
         break;
      case EQ:
         if (v1.contains(o2))
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   private boolean compare(Boolean B1, Object o2) throws KBException
   {
      boolean b1 = B1.booleanValue();
      boolean b2 = ((Boolean)o2).booleanValue();
      boolean b = false;

      switch(op)
      {
      case EQ:
         if (b1 == b2)
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   private boolean compare(Object o1, Object o2) throws KBException
   {
      boolean b = false;

      switch(op)
      {
      case EQ:
         if (o1.equals(o2))
            b = true;
         break;
      default:
         throw new KBException(this, KBException.UNEXPECTED_TEST_CONDITION);
      }
      return b;
   }

   public void set_arg1(Object a) { arg1 = a; }
   public void set_arg2(Object a) { arg2 = a; }

   public void print(PrintStream o)
   {
      print("", o);
   }

   public void print(String dent, PrintStream o)
   {
      o.println(dent + toString());
      /*
      switch (op)
      {
      case OR:
      case AND:
         ((Test)arg1).print(dent + "  ", o);
         ((Test)arg2).print(dent + "  ", o);
      default:
      }
      */
   }

   public String toString()
   {
      return arg1.toString() + " " +
           Test.ops[op] + " " + arg2.toString();
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}