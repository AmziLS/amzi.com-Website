// Link.java

package amzi.kb;

import java.io.*;
import java.util.*;

public class Link implements Serializable
{
   public static final int LK_NO_LINK = 0;
   public static final int LK_KIND_OF = 1;
   public static final int LK_EQUIVALENT_TO = 2;

   private int type;
   private VariableKey v_key1;
   private VariableKey v_key2;

   public static final String[] TYPE_NAMES =
   {
      "no_link",
      "ako",
      "==",
   };

   public Link(int t)
   {
      init(t, null, null);
   }

   public Link()
   {
      init(0, null, null);
   }

   public Link(int t, VariableKey vk1, VariableKey vk2)
   {
      init(t, vk1, vk2);
   }

   private void init(int t, VariableKey vk1, VariableKey vk2)
   {
      type = t;
      v_key1 = vk1;
      v_key2 = vk2;
   }

   public static String check_type(String t)
   {
      if      (t.equalsIgnoreCase("ako"))              return "ako";
      else if (t.equalsIgnoreCase("is_a_kind_of"))     return "ako";
      else if (t.equalsIgnoreCase("=="))               return "==";
      else if (t.equalsIgnoreCase("is_equivalent_to")) return "==";
      else
         return null;
   }

   public static int int_type(String ts)
   {
      if      (ts.equals("ako"))  return LK_KIND_OF;
      else if (ts.equals("=="))   return LK_EQUIVALENT_TO;
      else
         return LK_NO_LINK;
   }

   public int get_type() { return type; }
   public VariableKey get_var1() { return v_key1; }
   public VariableKey get_var2() { return v_key2; }

   public void set_type(int t) { type = t; }
   public void set_var1(VariableKey v) { v_key1 = v; }
   public void set_var2(VariableKey v) { v_key2 = v; }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}
