// guiConsult.java

package amzi.kb;

import amzi.util.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.event.*;

import java.awt.event.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

class guiConsult extends JInternalFrame
      implements ListSelectionListener, ActionListener, InferUI
{
   File file;
   guiKB mf;
   KnowledgeBase kb;
   Consultation consult;
   String goal = null;

   JList m_variables;
   SortedListModel m_vars;
   JList m_values;
   //SortedListModel m_vals;
   AttrValueListModel m_vals;
   JButton m_run;
   JButton m_clear;
   JRadioButton m_step_mode_on;
   JRadioButton m_step_mode_off;
   JTextField m_goal;
   guiActionEventDispatcher m_dispatch;

   String last_var = "";
   String last_val = "";

   guiConsult(guiKB mf, File f)
   {
      super(f.getName(), true, true, true, true);
      file = f;
      this.mf = mf;

      try
      {
         kb = new KnowledgeBase(file);
         ui_init();
         consult = new Consultation(kb, this);
         mf.log_writeln("Starting consultation with " + file.getName());
      }
      catch (Exception ex)
      {
         mf.log_writeln("guiConsult Exception: " + ex.getMessage());
         System.out.println("guiConsult Exception: " + ex.getMessage());
         ex.printStackTrace();

         JTextArea ta = new JTextArea(ex.getMessage());
         JOptionPane.showMessageDialog(mf,
               ta,
               "Exception",
               JOptionPane.ERROR_MESSAGE);
      }
   }


   //--------------------
   // Initialize the gui
   //

   private void ui_init()
   {
      setTitle("File: " + file.getName());
      getContentPane().add( split_pane() );
      setBounds(mf.next_window_bounds());
      setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
      m_dispatch = new guiActionEventDispatcher();
      m_dispatch.addActionListener(this);
      show();
   }

   private JSplitPane split_pane()
   {
      JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
      // This appears to be a meaningless statement
      sp.setDividerLocation( 0.5 );
      sp.setLeftComponent( left_pane() );
      sp.setRightComponent( right_pane() );
      return sp;
   }

   private JComponent left_pane()
   {
      JScrollPane js = new JScrollPane();
      js.setBorder(new TitledBorder("Variables"));

      m_vars = new SortedListModel(kb.get_variable_names());
      m_variables = new JList(m_vars);
      m_variables.addListSelectionListener(this);
      m_variables.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      js.setViewportView(m_variables);
      return js;
   }

   private JComponent right_pane()
   {
      JPanel p = new JPanel();

      p.setLayout( new BorderLayout() );
      p.add(right_north(), "North");
      p.add(right_center(), "Center");
      p.add(right_south(), "South");

      return p;
   }

   private JComponent right_north()
   {
      JPanel p = new JPanel();
      GridBagLayout gb = new GridBagLayout();
      p.setLayout(gb);

      GridBagConstraints gc = new GridBagConstraints();
      gc.fill = GridBagConstraints.HORIZONTAL;
      gc.gridy = 0;
      gc.gridx = GridBagConstraints.RELATIVE;
      gc.insets = new Insets( 5, 10, 5, 10 );

      JLabel l = new JLabel("Goal:");
      gc.anchor = GridBagConstraints.WEST;
      gb.setConstraints(l, gc);
      p.add(l);

      m_goal = new JTextField();
      gc.gridwidth = GridBagConstraints.REMAINDER;
      gc.anchor = GridBagConstraints.EAST;
      gc.weightx = 0.5;
      gb.setConstraints(m_goal, gc);
      p.add(m_goal);

      p.setBorder( new BevelBorder(BevelBorder.RAISED) );
      return p;
   }

   private JComponent right_center()
   {
      JScrollPane js = new JScrollPane();
      js.setBorder(new TitledBorder("Values"));

      //m_vals = new SortedListModel( new Vector() );
      m_vals = new AttrValueListModel( new Vector() );
      m_values = new JList(m_vals);
      m_values.addListSelectionListener(this);
      m_values.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

      js.setViewportView(m_values);
      return js;
   }

   private JComponent right_south()
   {
      JPanel p = new JPanel();
      p.setLayout( new FlowLayout() );

      m_run = new JButton("Run");
      m_run.addActionListener(this);
      p.add(m_run);

      m_clear = new JButton("Clear");
      m_clear.addActionListener(this);
      p.add(m_clear);

      /* How to add radio buttons */
      /*
      JPanel sp = new JPanel();
      sp.setLayout( new GridLayout(0,1) );
      ButtonGroup bg = new ButtonGroup();

      m_step_mode_on = new JRadioButton("On");
      m_step_mode_on.setSelected(true);
      m_step_mode_on.addActionListener(this);
      sp.add( m_step_mode_on );
      bg.add( m_step_mode_on );

      m_step_mode_off = new JRadioButton("Off");
      m_step_mode_off.addActionListener(this);
      sp.add( m_step_mode_off );
      bg.add( m_step_mode_off );

      sp.setBorder( new TitledBorder("Step") );
      p.add(sp);
      */

      p.setBorder( new BevelBorder(BevelBorder.RAISED) );
      return p;
   }

   //--------------------------------------
   // Listener classes and implementations
   //

   /**
   * Implementation of ListSelectionListener.
   */
   public void valueChanged(ListSelectionEvent e)
   {
      // This event happens not just when the selection changes,
      // but for both mouse pressed and mouse released on the
      // selection.  So we get duplicate firings.  Thus the
      // last_var kludge.

      if (e.getSource() == m_variables)
      {
         String var = (String)m_variables.getSelectedValue();
         if (var.equals(last_var))
            return;
         last_var = var;
         //System.out.println("variable " + var);
         Variable v = kb.get_variable(var);
         guiVariableView vv = new guiVariableView(mf, this, v);
      }
      if (e.getSource() == m_values)
      {
         String val = (String)m_values.getSelectedValue();
         if (val.equals(last_val))
            return;
         last_val = val;
         //System.out.println("value " + val);
      }
   }

   /**
   * Implementation of ActionListener.
   */
   public void actionPerformed( ActionEvent e )
   {
      if (e.getSource() == m_run)
      {
         //System.out.println("run");
         goal = m_goal.getText();
         consult.reset_stack();
         if (! goal.equals(""))
            consult.set_goal(goal);
         run(true);
      }
      else if (e.getSource() == m_clear)
      {
         //System.out.println("clear");
         clear();
      }
      else if (e.getSource() == m_dispatch)
      {
         //System.out.println("got a dispatch: " + e.getActionCommand());
         if (e.getActionCommand().equals("carry_on"))
         {
            //System.out.println("it was a carry_on");
            run(false);
         }
      }
   }

   public void set_goal(Variable v)
   {
      mf.log_writeln("Setting goal to " + v.get_name());
      m_goal.setText(v.get_name());
   }

   public void set_value(Variable v, Object o)
   {
      consult.set_value(v, o, true);
   }

   private void run(boolean first_time)
   {
      try
      {
         if (first_time)
            consult.forward_chain();
         KBMessage m = consult.backward_chain();
         //if (m == null)
         //   System.out.println("run loop got null message");
         //System.out.println("run loop got message: " + m.toString());
         process_message(m);
      }
      catch (KBException ex)
      {
         mf.show_exception(ex);
      }
   }

   private void clear()
   {
      //System.out.println("clear");
      m_goal.setText("");
      m_vals.removeAllElements();
      consult.clear_variables();
      consult.reset_stack();
   }

   /**
   * Continue the inference process.
   */
   public void carry_on()
   {
      //System.out.println("carry_on");
      m_dispatch.processEvent("carry_on");
   }

   void process_message(KBMessage m)
   {
      boolean done = false;

      switch (m.type)
      {
      case KBMessage.NO_GOAL:
         done = true;
         break;
      case KBMessage.MULTIVALUED_DONE:
         mf.log_writeln("The answer is: " + m.v_key.get_name() +
            " = " + m.value.toString());
         m_goal.setText(m.v_key.get_name() +
            " = " + m.value.toString());
         JOptionPane.showMessageDialog(mf,
               "The answer is: " + m.v_key.get_name() +
                  " = " + m.value.toString(),
               "Success",
               JOptionPane.INFORMATION_MESSAGE);
         carry_on();
         break;
      case KBMessage.SUCCESS:
         mf.log_writeln("The answer is: " + m.v_key.get_name() +
            " = " + m.value.toString());
         m_goal.setText(m.v_key.get_name() +
            " = " + m.value.toString());
         JOptionPane.showMessageDialog(mf,
               "The answer is: " + m.v_key.get_name() +
                  " = " + m.value.toString(),
               "Success",
               JOptionPane.INFORMATION_MESSAGE);
         carry_on();
         break;
      case KBMessage.FAILURE:
         mf.log_writeln("There is no answer.");
         JOptionPane.showMessageDialog(mf,
               "There is no answer.",
               "Failure",
               JOptionPane.INFORMATION_MESSAGE);
         done = true;
         break;
      case KBMessage.ASK_USER:
         guiAsk a = new guiAsk(mf, null, this, kb.get_variable(m.v_key));
         break;
      case KBMessage.EXCEPTION:
         mf.log_writeln("KB Exception: " + ((KBException)m.value).getMessage());
         mf.show_exception((KBException)m.value);
      }

      // Work forward one more time from derived data
      try
      {
         if (done)
            consult.forward_chain();
      }
      catch (KBException ex)
      {
         mf.show_exception(ex);
      }
   }


   //--------------------------------------------
   // Implementation of the InferUI interface
   //

   public void trace(String s)
   {
      mf.log_writeln(s);
   }

   public void value_remove(Variable v, Object val)
   {
      //m_vals.removeElement(v.get_name() + " = " + val.toString());
      m_vals.removeElement(v.get_name());
   }

   public void value_set(Variable v, Object val)
   {
      //mf.log_writeln("Setting value of " + v.get_name() +
      //   " to " + val.toString());
      //m_vals.addElement(v.get_name() + " = " + val.toString());
      m_vals.addElement(v.get_name(), val);
   }
}
