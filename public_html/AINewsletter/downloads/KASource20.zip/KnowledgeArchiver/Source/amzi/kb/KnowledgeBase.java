// KnowledgeBase.java

package amzi.kb;

import java.io.*;
import java.util.*;

public class KnowledgeBase implements Serializable
{
   public static final int KB_KIND_OF = 1;
   public static final int KB_EQUIVALENT_TO = 2;

   File kb_file;
   Hashtable variables;
   Vector rules;
   //Hashtable consultations;

   //static KBParser rp = null;
   
   public KnowledgeBase() throws KBException
   {
      kb_file = null;

      rules = new Vector();
      variables = new Hashtable();
   }

   public KnowledgeBase(File f) throws KBException
   {
      kb_file = f;

      rules = new Vector();
      variables = new Hashtable();

      parse_kb();

      //PrintWriter o = new PrintWriter(System.out);
      System.out.println("*** Knowledge Base "+ f.getName() + " ***");
      print(System.out);
      System.out.println("*** ***");
      //o.close();
   }


   public KnowledgeBase(Variable[] vs, Link[] ls, Rule[] rs)
   {
      VariableKey.set_kb(this);
      int i;

      variables = new Hashtable(vs.length);
      for (i=0; i<vs.length; i++)
         variables.put(vs[i].get_key().key, vs[i]);

      Variable v1, v2;
      for (i=0; i<ls.length; i++)
      {
         v1 = (Variable)variables.get(ls[i].get_var1().key);
         v2 = (Variable)variables.get(ls[i].get_var2().key);
         switch (ls[i].get_type())
         {
         case Link.LK_KIND_OF:
            v2.set_subset(v1);
            v1.set_superset(v2);
            break;
         case Link.LK_EQUIVALENT_TO:
            v1.set_equivalent(v2);
            v2.set_equivalent(v1);
            break;
         default:
            break;
         }
      }

      rules = new Vector(rs.length);
      for (i=0; i<rs.length; i++)
         rules.addElement(rs[i]);

      print(System.out);
   }


	public void parse_kb() throws KBException
	{
      /* commented out for now
      try
      {
         if (rp == null)
            rp = new KBParser(
               new FileReader(kb_file));
         else
            rp.ReInit(new FileReader(kb_file));

         KBParser.initialize(this);

         rp.knowledge_base();
      }
      catch (KBException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw ex;
      }
      catch (ParseException ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.PARSE_EXCEPTION, ex.getMessage());
      }
      catch (Exception ex)
      {
         System.out.println(ex.getMessage());
         ex.printStackTrace();
         throw new KBException(this, KBException.EXCEPTION, ex.getMessage());
      }
      */
	}


   public void add_rule(Rule r)
   {
      rules.addElement(r);
   }

   public void add_choice(String var_name, Object choice)
   {
      Variable v = (Variable)variables.get(var_name);
      v.add_choice(choice);
   }

   public Variable add_variable(String var_name)
   {
      if (variables.containsKey(var_name))
         return (Variable)variables.get(var_name);

      Variable v = new Variable(var_name);
      variables.put(var_name, v);
      return v;
   }

   public void add_variable(Variable v) throws KBException
   {
      if ( variables.containsKey(v.get_name()) )
         throw new KBException(this, KBException.DUPLICATE_VARIABLE, v.get_name());
      variables.put(v.get_name(), v);
   }

   public Variable get_variable(String var_name)
   {
      Enumeration e = variables.elements();
      Variable v;
      while (e.hasMoreElements())
      {
         v = (Variable)e.nextElement();
         if (v.get_name().equals(var_name))
            return v;
      }
      System.out.println("Failing to get_variable by name: " + var_name);
      return null;
   }

   public Variable get_variable(VariableKey vk)
   {
      Variable v = (Variable)variables.get(vk.key);
      if (v != null)
         return v;
      else
      {
         System.out.println("Failing to get_variable by key: " + vk.key);
/* Maddening problem - it prints out identical hashCode and equals but
      can't find from one key but can from the other... Switched back
      to just using the string of the key directly, rather than overriding
      hashCode and equals for VariableKeys. */
/*
         Enumeration e = variables.keys();
         System.out.println("the keys of 'variables' are: ");
         while (e.hasMoreElements())
         {
            VariableKey k = (VariableKey)e.nextElement();
            System.out.print(k.key + "." + k.hashCode());
            if (k.equals(vk))
            {
               System.out.println(" which equals " +
                     vk.key + "." + vk.hashCode());
               Variable v1 = (Variable)variables.get(k);
               Variable v2 = (Variable)variables.get(vk);
               if (v1 == null) System.out.println("v1 null");
               if (v2 == null) System.out.println("v2 null");
            }
            else
               System.out.println(" which doesn't equal " +
                     vk.key + "." + vk.hashCode());
         }
*/
         return null;
      }
   }

   public Variable check_variable(VariableKey vk) throws KBException
   {
      Variable v = (Variable)variables.get(vk.key);
      if (v == null)
         throw new KBException(this, KBException.NO_SUCH_VARIABLE, vk.get_name());

      return v;
   }

   public boolean variable_exists(VariableKey vk)
   {
      return variables.containsKey(vk.key);
   }

   public String[] get_variable_names()
   {
      String[] var_names = new String[variables.size()];

      Enumeration e = variables.elements();
      Variable v;
      int i = 0;
      while (e.hasMoreElements())
      {
         v = (Variable)e.nextElement();
         var_names[i] = v.get_name();
         i++;
      }
      return var_names;
   }

   public void declaration(int op, String vn1, String vn2) throws KBException
   {
      Variable var1 = get_variable(vn1);
      Variable var2 = get_variable(vn2);
      if (var1.is_multivalued() != var2.is_multivalued() ||
            var1.get_type() != var2.get_type())
         throw new KBException(this, KBException.INCOMPATIBLE_DECLARATION,
            vn1 + " & " + vn2);

      switch (op)
      {
      case KB_EQUIVALENT_TO:
         var1.set_equivalent(var2);
         var2.set_equivalent(var1);
         break;
      case KB_KIND_OF:
         var2.set_subset(var1);
         var1.set_superset(var2);
         break;
      default:
         break;
      }
   }

   /**
   * Return a vector of rules whose dependent variable
   * is the given variable.
   */
   public Vector get_rules(VariableKey vk)
   {
      Vector drules = new Vector();
      Rule r;
      Enumeration e = rules.elements();
      while (e.hasMoreElements())
      {
         r = (Rule)e.nextElement();
         if (r.dependent_variable().equals(vk))
            drules.addElement(r);
      }

      Variable var = get_variable(vk);
      Vector alt_vars = var.related_vars(Variable.V_ALT_GOAL);
      if (alt_vars == null)
         return drules;

      int i, j;
      Variable iv;

      for (i=0; i<alt_vars.size(); i++)
      {
         iv = (Variable)alt_vars.elementAt(i);
         for (j=0; j<rules.size(); j++)
         {
            r = (Rule)rules.elementAt(j);
            if (r.dependent_variable().equals(iv.get_key()))
               drules.addElement(r);
         }
      }

      return drules;
   }

   /**
   * Return a vector of all rules.
   */
   public Vector get_rules()
   {
      Vector rcopy = new Vector();
      for (int i=0; i<rules.size(); i++)
         rcopy.addElement(rules.elementAt(i));
      return rcopy;
   }

   public void print(PrintStream o)
   {
      Enumeration e;

      o.println("Printing variables for kb");
      Variable v;
      e = variables.elements();
      while (e.hasMoreElements())
      {
         v = (Variable)e.nextElement();
         v.print(o);
         o.println();
      }

      /*
      o.println("Printing variable keys for kb");
      VariableKey k;
      e = variables.keys();
      while (e.hasMoreElements())
      {
         k = (VariableKey)e.nextElement();
         o.println("HashKey = " + k.key + "." + k.hashCode());
         v = (Variable)variables.get(k);
         if (v != null)
         {
            v.print(o);
            o.println();
         }
         else
            o.println("Couldn't find the variable though.");
      }
      */

      o.println("Printing rules for kb");
      Rule r;
      e = rules.elements();
      while (e.hasMoreElements())
      {
         r = (Rule)e.nextElement();
         r.print(o);
         o.println();
      }
   }


   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
/*
   public void log(String s)
   {
      c.log(s);
   }
   */
}