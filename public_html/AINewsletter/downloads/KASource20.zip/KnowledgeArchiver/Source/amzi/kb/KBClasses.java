// KBClasses.java

package amzi.kb;

public class KBClasses
{
   static Class cVariableKey;
   static Class cVariable;
   static Class cExpression;
   static Class cString;
   static Class cInteger;
   static Class cDouble;
   static Class cBoolean;
   static Class cVector;

   static
   {
      try
      {
         cVariableKey = Class.forName("amzi.kb.VariableKey");
         cVariable = Class.forName("amzi.kb.Variable");
         cExpression = Class.forName("amzi.kb.Expression");
         cInteger = Class.forName("java.lang.Integer");
         cDouble = Class.forName("java.lang.Double");
         cString = Class.forName("java.lang.String");
         cBoolean = Class.forName("java.lang.Boolean");
         cVector = Class.forName("java.util.Vector");
      }
      catch (Exception ex)
      {
         System.out.println("*** Problem initializing classes ***");
      }
   }
}