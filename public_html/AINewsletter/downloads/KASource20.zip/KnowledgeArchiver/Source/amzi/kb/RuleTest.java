// RuleTest.java

package amzi.kb;

import java.io.*;

public class RuleTest implements KBClient_I
{
   KnowledgeBase kb;
   BufferedReader in;

   public static void main(String args[])
   {
      RuleTest prog = new RuleTest();
      prog.go();
   }

   public void go()
   {
      try
      {
         in = new BufferedReader(
            new InputStreamReader(System.in));
         System.out.print("Enter KB: ");
         String kb_name = in.readLine();
         kb = new KnowledgeBase(new File(kb_name + ".kb"));
         Consultation c = new Consultation(kb, this);
         String response;
         System.out.print("Enter goal: ");
         String goal = in.readLine();
         KBMessage kmess = c.go(goal);
         while (kmess.type == KBMessage.ASK_USER)
         {
            System.out.print(kb.get_variable(kmess.var_name).prompt());
            response = in.readLine();
            c.set_value(kmess.var_name, response, true);
            kmess = c.go(goal);
         }
         switch (kmess.type)
         {
         case KBMessage.NO_ANSWER:
            System.out.println("*** No Answer ***");
            break;
         case KBMessage.ANSWER:
            System.out.println("*** The answer is: " + kmess.value.toString());
            break;
         default:
            System.out.println("rt oops");
         }
      }
      catch (Exception e)
      {
         System.out.println("Oops: " + e.getMessage());
         e.printStackTrace();
      }
   }

   public void log(String s)
   {
      System.out.print("LOG: ");
      System.out.println(s);
   }
}


