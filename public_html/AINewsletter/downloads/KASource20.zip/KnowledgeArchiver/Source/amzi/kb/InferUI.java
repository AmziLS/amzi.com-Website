// InferUI.java

package amzi.kb;

public interface InferUI
{
   public void trace(String s);
   public void value_set(Variable v, Object val);
   public void value_remove(Variable v, Object val);
   //public void value_set(String vname, Object val);
}