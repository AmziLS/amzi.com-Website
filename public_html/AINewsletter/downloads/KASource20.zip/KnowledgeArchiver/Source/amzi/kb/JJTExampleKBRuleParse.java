// KnowledgeBase.java

package amzi.kb;

import java.io.*;
import java.util.*;

public class KnowledgeBase implements RuleParserTreeConstants
{
   File kb_file;
   Hashtable variables;
   Vector rules;
   Hashtable consultations;
   static KBParser rp = null;
   
   public KnowledgeBase(File f)
   {
      kb_file = f;

      rules = new Vector();
      variables = new Hashtable();

      parse_kb();

      //PrintWriter o = new PrintWriter(System.out);
      System.out.println("*** Knowledge Base "+ f.getName() + " ***");
      print(System.out);
      System.out.println("*** ***");
      //o.close();
   }

	public void parse_kb()
	{
      try
      {
         if (rp == null)
            rp = new KBParser(
               new FileReader(kb_file));
         else
            rp.ReInit(new FileReader(kb_file));

         rp.Initialize(this);

         rp.knowledge_base();
      }
      catch (Exception e)
      {
         System.out.println("Oops: " + e.getMessage());
         e.printStackTrace();
      }
	}

   private void load_kb(SimpleNode kb_node)
   {
      //SimpleNode kb_node = (SimpleNode)nod;
      if (kb_node.getID() != JJTKNOWLEDGEBASE)
         System.out.println("problem");
      int kb_size = kb_node.jjtGetNumChildren();
      int i;
      SimpleNode n;
      for (i=0; i<kb_size; i++)
      {
         n = (SimpleNode)kb_node.jjtGetChild(i);
         switch (n.getID())
         {
         case JJTRULE:
            make_rule(n);
            break;
         case JJTTABLE:
            make_table_rules(n);
            break;
         default:
            System.out.println("blarney");
         }
      }
   }

   private void make_table_rules(SimpleNode table_node)
   {
      Node heading = table_node.jjtGetChild(0);
      // get the table headings
      int n_independent_vars = heading.jjtGetNumChildren() - 1;
      // get all the independent vars
      SimpleNode nhead;
      Variable[] i_vars = new Variable[n_independent_vars];
      for (int i=0; i<n_independent_vars; i++)
      {
         nhead = (SimpleNode)heading.jjtGetChild(i);
         i_vars[i] = this.add_variable((String)nhead.getImage());
      }
      // and the dependent one
      nhead = (SimpleNode)heading.jjtGetChild(n_independent_vars);
      Variable d_var = this.add_variable((String)nhead.getImage());

      // make all the rules from the table
      for (int i=1; i<table_node.jjtGetNumChildren(); i++)
      {
         Rule r = new Rule();

         String var_name;
         SimpleNode row = (SimpleNode)table_node.jjtGetChild(i);
         SimpleNode n;
         Test t;
         Stack test_stack = new Stack();
         // build the test from the columns of the row, first
         // pushing all the individual tests onto a stack.
         for (int j=0; j<row.jjtGetNumChildren()-1; j++)
         {
            t = new Test(Test.EQ);
            t.set_arg1(i_vars[j]);
            r.add_independent_variable(i_vars[j].get_name());

            n = (SimpleNode)row.jjtGetChild(j);
            switch(n.getID())
            {
            case JJTVARIABLE:
               var_name = (String)n.getImage();
               this.add_variable(var_name);
               r.add_independent_variable(var_name);
               t.set_arg2(this.get_variable(var_name));
               break;
            case JJTVALUE:
               t.set_arg2(n.getImage());
               add_choice(i_vars[j].get_name(), n.getImage());
               break;
            default:
               System.out.println("arghh ina row");
            }
            test_stack.push(t);
         }
         // then popping them off 'anding' as we go
         Test lhs = null;
         Test t1, t2;
         while (! test_stack.empty())
         {
            t1 = (Test)test_stack.pop();
            if (lhs != null)
            {
               t2 = lhs;
               lhs = new Test(Test.AND);
               lhs.set_arg1(t1);
               lhs.set_arg2(t2);
            }
            else
               lhs = t1;
         }
         r.set_test(lhs);

         var_name = d_var.get_name();
         r.set_dependent_variable(var_name);
         Action a = new Action(var_name);
         Object value = ((SimpleNode)row.jjtGetChild(n_independent_vars)).getImage();
         add_choice(var_name, value);
         a.set_value(value);
         r.set_action(a);

         add_rule(r);
      }
   }

   private void make_rule(SimpleNode rule_node)
   {
      Rule r = new Rule();
      Node lhs_node = rule_node.jjtGetChild(0);
      Node rhs_node = rule_node.jjtGetChild(1);

      Node first_node = lhs_node.jjtGetChild(0);
      Test t = make_test((SimpleNode)first_node, r);
      r.set_test(t);

      Action a = make_action(rhs_node, r);
      r.set_action(a);

      //System.out.println("rule test: ");
      //System.out.println(r.toString());
      add_rule(r);

      return;
   }

   private Action make_action(Node node, Rule r)
   {
      String var_name = (String)((SimpleNode)node.jjtGetChild(0)).getImage();
      add_variable(var_name);
      Action a = new Action(var_name);
      r.set_dependent_variable(var_name);

      Object value = ((SimpleNode)node.jjtGetChild(1)).getImage();
      add_choice(var_name, value);
      a.set_value(value);

      return a;
   }

   private Test make_test(SimpleNode node, Rule r)
   {
      Test t=null;
      switch(node.getID())
      {
      case JJTOREXPRESSION:
         if (node.jjtGetNumChildren() == 1)
         {
            t = make_test((SimpleNode)node.jjtGetChild(0), r);
         }
         else
         {
            t = new Test(Test.OR);
            t.set_arg1( make_test((SimpleNode)node.jjtGetChild(0), r) );
            t.set_arg2( make_test((SimpleNode)node.jjtGetChild(1), r) );
         }
         break;
      case JJTANDEXPRESSION:
         if (node.jjtGetNumChildren() == 1)
         {
            t = make_test((SimpleNode)node.jjtGetChild(0), r);
         }
         else
         {
            t = new Test(Test.AND);
            t.set_arg1( make_test((SimpleNode)node.jjtGetChild(0), r) );
            t.set_arg2( make_test((SimpleNode)node.jjtGetChild(1), r) );
         }
         break;
      case JJTTEST:
         SimpleNode op_node = (SimpleNode)node.jjtGetChild(1);
         int op = ((Integer)(op_node.getImage())).intValue();
         t = new Test(op);
         SimpleNode n;
         String var_name = null;

         n = (SimpleNode)node.jjtGetChild(0);
         switch(n.getID())
         {
         case JJTVARIABLE:
            var_name = (String)n.getImage();
            this.add_variable(var_name);
            r.add_independent_variable(var_name);
            t.set_arg1(this.get_variable(var_name));
            break;
         case JJTVALUE:
            t.set_arg1(node.getImage());
            break;
         default:
            System.out.println("arghh");
         }

         n = (SimpleNode)node.jjtGetChild(2);
         switch(n.getID())
         {
         case JJTVARIABLE:
            var_name = (String)n.getImage();
            this.add_variable(var_name);
            r.add_independent_variable(var_name);
            t.set_arg2(this.get_variable(var_name));
            break;
         case JJTVALUE:
            t.set_arg2(n.getImage());
            if (var_name != null)
               this.add_choice(var_name, n.getImage());
            break;
         default:
            System.out.println("arghh");
         }
         break;
      default:
         System.out.println("uck");
      }
      return t;
   }

   public void add_rule(Rule r)
   {
      rules.addElement(r);
   }

   public void add_choice(String var_name, Object choice)
   {
      Variable v = (Variable)variables.get(var_name);
      v.add_choice(choice);
   }

   public Variable add_variable(String var_name)
   {
      if (variables.containsKey(var_name))
         return (Variable)variables.get(var_name);

      Variable v = new Variable(var_name);
      variables.put(var_name, v);
      return v;
   }

   public void add_variable(Variable v) throws KBException
   {
      if ( variables.containsKey(v.get_name()) )
         throw new KBException(this, DUPLICATE_VARIABLE, v.get_name());
      variables.put(v.get_name(), v);
   }

   public Variable get_variable(String var_name) throws KBException
   {
      Variable v = (Variable)variables.get(var_name);
      if (v == null)
         throw new KBException(this, NO_SUCH_VARIABLE, var_name);

      return v;
   }

   public String[] get_variables()
   {
      String[] var_names = new String[variables.size()];

      Enumeration evn = variables.keys();
      int i = 0;
      while (evn.hasMoreElements())
      {
         var_names[i] = (String)evn.nextElement();
         i++;
      }
      return var_names;
   }

   /**
   * Return a vector of rules whose dependent variable
   * is the given variable.
   */
   public Vector get_rules(String var_name)
   {
      Vector drules = new Vector();
      Rule r;
      Enumeration e = rules.elements();
      while (e.hasMoreElements())
      {
         r = (Rule)e.nextElement();
         if (r.dependent_variable().equals(var_name))
            drules.addElement(r);
      }
      return drules;
   }

   public void print(PrintStream o)
   {
      o.println("Printing rules for kb");
      Rule r;
      Enumeration e = rules.elements();
      while (e.hasMoreElements())
      {
         r = (Rule)e.nextElement();
         r.print(o);
         o.println();
      }
   }


/*
   public void log(String s)
   {
      c.log(s);
   }
   */
}