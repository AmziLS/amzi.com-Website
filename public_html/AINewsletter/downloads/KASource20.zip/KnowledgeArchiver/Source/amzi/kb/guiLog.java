// guiLog.java

// guiKBEditor.java

package amzi.kb;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

import java.awt.event.*;
import java.io.*;
import java.awt.*;
import java.util.*;

class guiLog extends JInternalFrame
{
   guiKB mf;
   JTextArea text;

   guiLog(guiKB mf) throws Exception
   {
      super("Log", true, true, true, true);
      this.mf = mf;
      ui_init();
   }

   void ui_init() throws Exception
   {
      addInternalFrameListener(new logFrameListener());
      text = new JTextArea();
      JScrollPane s = new JScrollPane(text);
      getContentPane().add("Center", s);
      setBounds(mf.next_window_bounds());
      System.out.println("showing new LOG");
      show();
   }

   public void write(String s)
   {
      text.append(s);
   }

   public void writeln(String s)
   {
      text.append(s + "\n");
   }

   //----------------------------------
   // inner classes for listeners etc.
   //

   private class logFrameListener extends InternalFrameAdapter
   {
      public void internalFrameClosed(InternalFrameEvent e)
      {
         //System.out.println("Frame closed: log");
         mf.enable_file_log(true);
      }
   }
}
