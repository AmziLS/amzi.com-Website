// guiKBEditor.java

package amzi.kb;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

import java.awt.event.*;
import java.io.*;
import java.awt.*;
import java.util.*;

class guiKBEditor extends JInternalFrame
{
   File file;
   guiKB mf;

   JEditorPane edit_pane;
   JScrollPane scroll_pane;
   JMenuBar menu_bar;
   JMenu file_menu;
   JMenuItem save_item;
   JMenuItem save_as_item;

   guiKBEditor(guiKB mf, File f) throws Exception
   {
      super(f.getName(), true, true, true, true);
      file = f;
      this.mf = mf;
      ui_init();
   }

   guiKBEditor() throws Exception
   {
      super("New KB", true, true, true, true);
      file = null;
      ui_init();
   }

   void ui_init() throws Exception
   {
      addInternalFrameListener(new editorFrameListener());
      menu_bar = new JMenuBar();
      file_menu = new JMenu("File");
      menu_bar.add(file_menu);
      fileMenuListener fml = new fileMenuListener();

         save_item = new JMenuItem("Save");
         save_item.addActionListener(fml);
         file_menu.add(save_item);

         save_as_item = new JMenuItem("Save As");
         save_as_item.addActionListener(fml);
         file_menu.add(save_as_item);

      setJMenuBar(menu_bar);

      edit_pane = new JEditorPane();
      scroll_pane = new JScrollPane(edit_pane);
      getContentPane().add("Center", scroll_pane);

      if (file != null)
         edit_pane.read(new FileReader(file), null);
      /* how to hand-read a document into an editor
      Document d = ed.getDocument();
      BufferedReader br = new BufferedReader( new FileReader(f) );
      String line;
      Position p;
      d.insertString(0, br.readLine(), null);
      while (null != (line = br.readLine()))
      {
         //System.out.println(line);
         p = d.getEndPosition();
         //System.out.println("position = " + p.getOffset());
         d.insertString(p.getOffset()-1, line+"\n", null);
      }
      */
      setBounds(mf.next_window_bounds());
      setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
      show();
   }

   private class fileMenuListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         try
         {
            if (e.getSource() == save_item)
               save_file();
            else if (e.getSource() == save_as_item)
               save_as_file();
            else
               System.out.println("hmmmm");
         }
         catch (Exception ex)
         {
            System.out.println("Exception " + ex.getMessage());
         }
      }
   }

   private class editorFrameListener extends InternalFrameAdapter
   {
      public void internalFrameClosed(InternalFrameEvent e)
      {
         System.out.println("Closed: " + file.getName());
         /*
         int choice = JOptionPane.showConfirmDialog(null, "save before closing?",
            "save dialog", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
         if (choice == JOptionPane.CANCEL_OPTION)
         {
            System.out.println("option: cancel");
            try {
               setClosed(false);
            } catch(Exception ex) {}
         }
         */
      }
   }

   void save_file() throws Exception
   {
      System.out.println("saving");
      FileWriter fw = new FileWriter(file);
      edit_pane.write(fw);
      fw.close();
   }

   void save_as_file() throws Exception
   {
      File f = null;
      File path = new File("f:\\japps\\infer");
      JFileChooser fc = new JFileChooser( path );
      if (fc.showOpenDialog(this) == 0)
         f = fc.getSelectedFile();

      if (f != null)
      {
         System.out.println("save as " + f.getName());
         file = f;
         setTitle(file.getName());
         save_file();
      }
      else
         System.out.println("save as nuttin");
   }
}