// Expression.java

package amzi.kb;

import java.util.*;
import java.io.*;

public class Expression implements Serializable
{
   public final static int PLUS = 0;
   public final static int MINUS = 1;
   public final static int MULT = 2;
   public final static int DIV = 3;
   public final static int UNARY_MINUS = 4;

   public final static int INT = 20;
   public final static int DOUBLE = 21;
   public final static int VARIABLE = 22;

   public static String ops[] =
   {
      "+",
      "-",
      "*",
      "/",
      "-",
   };

   private Stack expression;

   public Expression()
   {
      expression = new Stack();
   }

   public Expression(Stack e)
   {
      expression = e;
   }

   public Expression(Object[] oa)
   {
      expression = new Stack();
      for (int i=0; i<oa.length; i++)
         push(oa[i]);
   }

   public void push(Object o)
   {
      expression.push(o);
   }

   /**
   * Evaluate the expression, returning either an
   * Integer or a Double.  The expression is stored
   * on a stack with operators and type op preceding
   * various number types.
   * Example 3/2+4/5 is stored as
   * int 3 int 2 / int 4 int 5 / +
   */
   public KBMessage evaluate(Consultation c)
   {
      Stack eval = new Stack();
      Stack args = new Stack();
      Integer Iop;
      double darg1, darg2;
      int ians;
      double dans = 0.0;
      Integer Idouble = new Integer(DOUBLE);
      Number N;

      eval = (Stack)expression.clone();
      
      while (! eval.empty())
      {
         Iop = (Integer)eval.pop();
         switch (Iop.intValue())
         {
         case INT:
         case DOUBLE:
            N = (Number)eval.pop();
            args.push(N);
            break;
         case UNARY_MINUS:
            darg1 = ((Number)args.pop()).doubleValue();
            dans = - darg1;
            eval.push(new Double(dans));
            eval.push(Idouble);
            while (! args.empty())
            {
               eval.push(args.pop());
               eval.push(Idouble);
            }
            break;
         case VARIABLE:
            VariableKey v = (VariableKey)eval.pop();
            Object o = c.known_value(v);
            if (o == null)
               return new KBMessage(KBMessage.NEED_VALUE, v);
            else
               args.push(o);
            break;
         default:
            darg2 = ((Number)args.pop()).doubleValue();
            darg1 = ((Number)args.pop()).doubleValue();
            switch (Iop.intValue())
            {
            case PLUS:
               dans = darg1 + darg2;
               break;
            case MINUS:
               dans = darg1 - darg2;
               break;
            case MULT:
               dans = darg1 * darg2;
               break;
            case DIV:
               dans = darg1 / darg2;
               break;
            default:
               break;
            }
            eval.push(new Double(dans));
            eval.push(Idouble);
            while (! args.empty())
            {
               eval.push(args.pop());
               eval.push(Idouble);
            }
            break;
         }
      }

      dans = ((Number)args.pop()).doubleValue();
      double d2;
      ians = (int)dans;
      d2 = ians;

      KBMessage kmess = new KBMessage(KBMessage.CALCULATED);
      if (d2 == dans)
         kmess.value = new Integer(ians);
      else
         kmess.value = new Double(dans);
      return kmess;
   }

   public void print(PrintStream o)
   {
      print("", o);
   }

   public void print(String dent, PrintStream o)
   {
      o.println(dent + toString());
   }

   public String toString()
   {
      StringBuffer sb = new StringBuffer();

      Stack eval = new Stack();
      Integer Iop;
      Number arg1, arg2;

      eval = (Stack)expression.clone();
      
      while (! eval.empty())
      {
         Iop = (Integer)eval.pop();
         switch (Iop.intValue())
         {
         case INT:
         case DOUBLE:
         case VARIABLE:
            sb.append(eval.pop().toString() + " ");
            break;
         default:
            sb.append(ops[Iop.intValue()] + " ");
            break;
         }
      }
      
      return sb.toString();
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}
