// Consultation.java

package amzi.kb;

import java.util.*;

public class Consultation
{
   public static final String MORE = "...";
   public static final String NO_VALUE = "no_answer";

   InferUI ui;
   KnowledgeBase kb;
   Hashtable values;
   Stack goal_stack;
   String blanks = "                                          ";               

   public Consultation(KnowledgeBase kb, InferUI ui)
   {
      //VariableKey.set_kb(kb);
      this.kb = kb;
      this.ui = ui;
      init();
   }

   public Consultation(KnowledgeBase kb)
   {
      //VariableKey.set_kb(kb);
      this.kb = kb;
      this.ui = null;
      init();
   }

   private void init()
   {
      values = new Hashtable();
      goal_stack = new Stack();
   }

   public void set_goal(VariableKey vk)
   {
      push(new KBMessage(KBMessage.GOAL, vk));
   }

   public void set_goal(String var_name)
   {
      push(new KBMessage(KBMessage.GOAL, kb.get_variable(var_name).get_key()));
   }

   public void clear_variables()
   {
      values.clear();
   }

   public void reset_stack()
   {
      goal_stack.removeAllElements();
   }

   private void push(KBMessage m)
   {
      //log("PUSH " + m.toString());
      goal_stack.push(m);
   }

   private KBMessage pop()
   {
      KBMessage m = (KBMessage)goal_stack.pop();
      //log("POP " + m.toString());
      return m;
   }

   private KBMessage peek()
   { 
      KBMessage m = (KBMessage)goal_stack.peek();
      //log("PEEK " + m.toString());
      return m;
   }

   private boolean stack_empty()
   { 
      return goal_stack.isEmpty();
   }

   public void set_value(VariableKey vk, Object value, boolean chain)
   {
      Variable var = kb.get_variable(vk);
      set_value(var, value, chain);
   }

   public void set_value(Variable var, Object value, boolean chain)
   {
      log("Setting value: " + var.get_name() + " = " + value.toString());
      VariableKey vk = var.get_key();
      Object old_value = values.get(vk.key);

      if (var.is_multivalued())
      {
         Vector v;
         if (old_value != null)
         {
            v = (Vector)old_value;
            if (! v.contains(value))
               v.insertElementAt(value, 0);
         }
         else
         {
            v = new Vector();
            v.addElement(MORE);
            v.insertElementAt(value, 0);
            values.put(vk.key, v);
         }
         if (ui != null)
            ui.value_set(var, v);
      }
      else
      {
         values.put(vk.key, value);
         if (ui != null)
            ui.value_set(var, value);
      }

      if (chain)
         set_related_vars(var, value);
   }

   private void set_related_vars(Variable var, Object val)
   {
      Vector other_vars = var.related_vars(Variable.V_ALSO_SET);
      if (other_vars == null)
         return;

      for (int i=0; i < other_vars.size(); i++)
      {
         Variable v2 = (Variable)other_vars.elementAt(i);
         set_value(v2, val, false);
      }
   }

   public void remove_more_value(Variable var)
   {
      Vector vals = (Vector)values.get(var.get_key().key);

      if ( ((String)vals.lastElement()).equals(MORE) )
      {
         vals.removeElementAt(vals.size()-1);
         if (ui != null)
            ui.value_set(var, vals);
      }

      // We're cleaning up a multivalued variable after a
      // deduce_value(), so we can clean up all the other
      // variables that were considered as goals as well.
      Vector other_vars = var.related_vars(Variable.V_ALT_GOAL);
      if (other_vars == null)
         return;

      for (int i=0; i < other_vars.size(); i++)
      {
         Variable v2 = (Variable)other_vars.elementAt(i);
         vals = (Vector)values.get(v2.get_key().key);
         if ( vals != null && ((String)vals.lastElement()).equals(MORE) )
         {
            vals.removeElementAt(vals.size()-1);
            if (ui != null)
               ui.value_set(v2, vals);
         }
      }
   }

   public boolean multivar_has_more(Variable var)
   {
      if (var.is_singlevalued())
         return false;

      Vector vals = (Vector)values.get(var.get_key().key);

      if ( vals == null ||
           ((String)vals.lastElement()).equals(MORE) )
           return true;
      else
         return false;
   }

   public void remove_value(Variable var, Object value)
   {
      Object vals = values.get(var.get_key().key);
      if (vals != null && vals.getClass() == KBClasses.cVector)
      {
         //if (ui != null)
         //   ui.value_remove(var, vals);
         ((Vector)vals).removeElement(value);
         if (ui != null)
            ui.value_set(var, vals);
      }
   }

   public Object known_value(Variable var)
   {
      return values.get(var.get_key().key);
   }

   public Object known_value(VariableKey vk)
   {
      return values.get(vk.key);
   }

   public KBMessage backward_chain()
   {
      //System.out.println("In backward_chain()");

      if (stack_empty())
      {
         //System.out.println("empty stack");
         return new KBMessage(KBMessage.NO_GOAL);
      }

      KBMessage kmess = null;
      KBMessage gmess = null;
      Variable var;

      try
      {
         deduce_value();

go_loop:
         while(true)
         {
            kmess = pop();
            var = kb.get_variable(kmess.v_key);

            switch (kmess.type)
            {
            case KBMessage.MULTIVALUED_DONE:
            case KBMessage.FAILURE:
            case KBMessage.SUCCESS:
               pop();  // pop the goal
               if (stack_empty())
                  break go_loop;
               else
                  deduce_value();
               break;
            case KBMessage.NEED_VALUE:
               push(new KBMessage(KBMessage.GOAL, kmess.v_key));
               deduce_value();
               break;
            case KBMessage.ASK_USER:
               break go_loop;
            default:
               //System.out.println("unexpected kmess");
               break go_loop;
            }
         }
      }
      catch (KBException ex)
      {
         System.out.println("ooo, a backward_chain KBException: " + ex.getMessage());
         ex.printStackTrace();
         kmess = new KBMessage(KBMessage.EXCEPTION, null, ex);
      }
      catch (Exception ex)
      {
         System.out.println("oooo General Exception: " + ex.getMessage());
         ex.printStackTrace();
         kmess = new KBMessage(KBMessage.EXCEPTION, null, ex);
      }
      finally
      {
         //if (kmess == null)
         //   System.out.println("about to return a null kmess");
         return kmess;
      }
   }

   public void deduce_value() throws KBException
   {
      KBMessage gmess = pop();

      //if (gmess == null)
      //   System.out.println("null gmess in deduce_value");

      if (gmess.type != KBMessage.GOAL)
         throw new KBException(this, KBException.EXPECTED_GOAL);

      VariableKey v_key = gmess.v_key;
      log("Looking for value of: " + v_key.get_name());
      //System.out.println("deduce_value of " + var_name);

      // first see if we've got a value already

      //System.out.println("looking for a val");
      Variable var = kb.get_variable(v_key);
      if (var.is_singlevalued())
      {
         Object val = values.get(v_key.key);
         if (val != null)
         {
            log("Variable already has value: " + v_key.get_name() + " = " + val.toString());
            // put it back, go() will pop it after learning of the success.
            push(gmess);
            push(new KBMessage(KBMessage.SUCCESS, v_key, val));
            return;
         }
      }
      else
      {
         if (! multivar_has_more(var))
         {
            Vector vals = (Vector)values.get(v_key.key);
            log("Variable already has all values: " + v_key.get_name() + " = " + vals.toString());
            // put it back, go() will pop it after learning of the success.
            push(gmess);
            push(new KBMessage(KBMessage.SUCCESS, v_key, vals));
            return;
         }
      }

      // Next walk through the rules that can conclude a
      // value for this variable, seeing if we find one
      // that works.

      // We keep the vector of rules on the stack with
      // the goal in the value field of message.  If
      // its null, get a fresh one.

      Vector rules = null;
      if (gmess.value == null)
      {
         rules = kb.get_rules(v_key);
         if (rules.isEmpty())
         {
            gmess.value = rules;
            push(gmess);
            push(new KBMessage(KBMessage.ASK_USER, v_key));
            return;
         }
      }
      else
         rules = (Vector)gmess.value;

      Rule r;
      Object answer;
      KBMessage kmess = null;
      int i;

rule_loop:
      for (i=0; i<rules.size(); i++)
      {
         r = (Rule)rules.elementAt(i);

         log("Trying rule: " + r.get_name());
         kmess = r.get_value(this);

         switch (kmess.type)
         {
         case KBMessage.FAILURE:
            kmess.v_key = v_key;
            break;
         case KBMessage.SUCCESS:
            log("Rule " + r.get_name() + " succeeds");
            // If its a multivalued variable, get all the
            // answers we can.
            if (var.is_singlevalued())
               break rule_loop;
            else
               break;
         case KBMessage.NEED_VALUE:
            log("Rule " + r.get_name() + " needs value of: " + kmess.v_key.get_name());
            break rule_loop;
         default:
            throw new KBException(this, KBException.UNEXPECTED_RULE_RETURN);
         }
      }

      // for multivalued, we're looking for all solutions, so we
      // need to know when we've looked at all rules.
      if (var.is_multivalued() && i==rules.size())
      {
         kmess = new KBMessage(KBMessage.MULTIVALUED_DONE, v_key);
      }

      // eliminate the rules we've tried already
      // so next time back we start where we left
      // off.

      //System.out.println("rule_loop done with: " + kmess.toString());

      switch (kmess.type)
      {
         case KBMessage.FAILURE:
            // This will be a singlevalued failure, because
            // multivalued will not end in either success or
            // failure.
            rules.removeAllElements();
            set_value(v_key, NO_VALUE, true);
            break;
         case KBMessage.SUCCESS:
            // we might end on success for a search for multi-valued
            // variables, which means we need to clean up
            if (i == rules.size())
               rules.removeAllElements();
            else
            {
               for (int j=0; j<i+1; j++)
                  rules.removeElementAt(0);
            }
            break;
         case KBMessage.NEED_VALUE:
            for (int j=0; j<i; j++)
               rules.removeElementAt(0);
            break;
         case KBMessage.MULTIVALUED_DONE:
            rules.removeAllElements();
            Vector vals = (Vector)values.get(v_key.key);
            if (vals == null)
            {
               set_value(v_key, NO_VALUE, true);
               kmess = new KBMessage(KBMessage.FAILURE, v_key);
            }
            else
               // for multivalued, take out MORE
               // so we know this is complete.
               remove_more_value(var);
            kmess.value = values.get(v_key.key);
            break;
         default:
            throw new KBException(this, KBException.UNEXPECTED_RULE_RETURN);
      }

      //System.out.println("rule_loop done with: " + kmess.toString());
      //System.out.println("current value of "+ var_name + " = " +
      //   known_value(var_name));

      gmess.value = rules;
      push(gmess);
      push(kmess);
      return;
   }

   public void forward_chain() throws KBException
   {
      int hits = 1;
      Vector rules = kb.get_rules();

      while (hits > 0)
      {
         hits = forward_pass(rules);
      }
   }

   private int forward_pass(Vector rules) throws KBException
   {
      Rule r;
      KBMessage kmess;
      int hits = 0;
      int i;

      log("");
      log("--- Start Forward Pass ---");

      int last_rule = rules.size();
      for (i=0; i<last_rule; i++)
      {
         r = (Rule)rules.elementAt(i);
         //log("Next rule = " + r.get_name());
         if ( known_value(r.dependent_variable()) == null ||
            multivar_has_more(kb.get_variable(r.dependent_variable())) )
         {
            kmess = r.get_value(this);
            switch (kmess.type)
            {
            case KBMessage.SUCCESS:
               log("forward fire: " + r.get_name());
               rules.removeElementAt(i);
               i--; last_rule--;
               hits++;
               break;
            case KBMessage.FAILURE:
               //log("forward fire failure");
               rules.removeElementAt(i);
               i--; last_rule--;
               break;
            default:
               //log("forward fire insufficient data");
               break;
            }
         }
      }

      log("Number of rules firing = " + hits);
      log("--- End of Forward Pass ---");
      log("");
      return hits;
   }

   public void log(Object o)
   {
      int indent = 2 * goal_stack.size();
      if (indent > 10)
         indent = 10;
      String tab = blanks.substring(0, 2*indent);

      if (ui != null)
      {
         ui.trace(tab + o.toString());
         System.out.println("LOG: " + tab + o.toString());
      }
      else
         System.out.println("LOG: " + tab + o.toString());
   }

   public void debug(Object o)
   {
      System.out.println("DEBUG: " + o.toString());
   }
}
