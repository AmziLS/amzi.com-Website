// KBException.java

package amzi.kb;

import amzi.util.*;

/**
 * Exception class for Knowledge Archive exceptions.
 *
 * @author  Amzi! inc.
 */

public class KBException extends AmziException
{
   static class ErrorMsg
   {
      public int number;
      public int type;
      public String msg;

      public ErrorMsg(int n, int t, String m)
      {
         number = n;
         type = t;
         msg = m;
      }
   }

   // Types of errors
   public final static int UNKNOWN  = 0;
   public final static int ABORT    = 1;
   public final static int FATAL    = 2;
   public final static int INTERNAL = 3;
   public final static int ERROR    = 4;

   // Execution Errors 101 -
   public final static int EXPECTED_GOAL   =  101;
   public final static int UNEXPECTED_RULE_RETURN  = 102;
   public final static int UNEXPECTED_TEST_CONDITION = 103;
   public final static int EXCEPTION = 104;

   // Compilation/Build Errors 201 -

   public final static int PARSE_EXCEPTION  = 201;
   public final static int DUPLICATE_VARIABLE  = 202;
   public final static int NO_SUCH_VARIABLE  = 203;
   public final static int INCOMPATIBLE_DECLARATION  = 204;

   private static ErrorMsg[] msgs =
   {
      /*101*/ new ErrorMsg(EXPECTED_GOAL, INTERNAL,
         "Unexpected inference stack element, wanted a GOAL."),
      /*102*/ new ErrorMsg(UNEXPECTED_RULE_RETURN, INTERNAL,
         "Unexpected inference stack element returned from rule."),
      /*103*/ new ErrorMsg(UNEXPECTED_TEST_CONDITION, INTERNAL,
         "Unexpected test condition on IF side of rule."),
      /*104*/ new ErrorMsg(EXCEPTION, ERROR,
         "Error compiling slot "),

      /*201*/ new ErrorMsg(PARSE_EXCEPTION, ERROR,
         "Syntax error compiling slot "),
      /*202*/ new ErrorMsg(DUPLICATE_VARIABLE, ERROR,
         "Duplicate variable definition: "),
      /*203*/ new ErrorMsg(NO_SUCH_VARIABLE, ERROR,
         "Unknown variable: "),
      /*204*/ new ErrorMsg(INCOMPATIBLE_DECLARATION, ERROR,
         "Incompatible variables for a declared relationship: "),

      new ErrorMsg(UNKNOWN, UNKNOWN,
         "Unknown KB Error")
   };

   protected int type;
   protected String prefix = null;
   protected String msg = "";
   protected int error_number = 0;

   public KBException()
   {
      msg = "";
      prefix = "";
      //Thread.currentThread().dumpStack();
   }
   
   /**
    * Constructor for exception with just a preformatted message.
    *
    * @param   i  the identifier of the message
    */
   public KBException(int i)
   {
      msg = findMsg(i);
      prefix = "";
      error_number = i;
      //Thread.currentThread().dumpStack();
   }

   /**
    * Constructor for exception with a custom message.
    *
    * @param   m  the message to be used
    */
   public KBException(String m)
   {
      msg = msg;
      prefix = "";
      error_number = 0;
      //Thread.currentThread().dumpStack();
   }

   public KBException(int i, String a)
   {
      msg = findMsg(i) + a;
      prefix = "";
      error_number = i;
      //Thread.currentThread().dumpStack();
   }

   /**
    * Constructor for exception with a preformatted message
    * and a customized message prefix.
    *
    * @param   c  the message prefix
    * @param   i  the message identifier
    */
   public KBException(String c, int i)
   {
      msg = findMsg(i);
      prefix = c;
      error_number = i;
      //Thread.currentThread().dumpStack();
   }

   /**
    * Constructor for exception with a preformatted
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    */
   public KBException(Object o, int i)
   {
      msg = findMsg(i);
      prefix = o.getClass().getName();
      error_number = i;
      //Thread.currentThread().dumpStack();
   }

   /**
    * Constructor for exception with a custom
    * message and a prefix generated from the class
    * name of the thrower.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   m  the custom message
    */
   public KBException(Object o, String m)
   {
      msg = m;
      prefix = o.getClass().getName();
      error_number = 0;
      //Thread.currentThread().dumpStack();
   }

   /**
    * Constructor for exception with a preformatted
    * message, a prefix generated from the class
    * name of the thrower, and additional information.
    *
    * @param   o  an object, usually the one that threw
    *             the message
    * @param   i  the message identifier
    * @param   a  additional information
    */
   public KBException(Object o, int i, String a)
   {
      msg = findMsg(i) + a;
      prefix = o.getClass().getName();
      error_number = i;
      //Thread.currentThread().dumpStack();
   }

   protected String findMsg(int error_number)
   {
      // Just walk down the array looking, as this only
      // happens occasionally, its not such a
      // big deal.
      int i;
      for (i=0; i<msgs.length-1; i++)  // last message is default
      {
         if (msgs[i].number == error_number)
            break;
      }
      // set the type, a little ugly but ok for now
      this.type = msgs[i].type;
      return msgs[i].msg;
   }

   // deprecated
   public String getMsg()
   {
      return getMessage();
   }

   public String getMessage()
   {
      switch (error_number)
      {
      case EXCEPTION:
      case PARSE_EXCEPTION:
      default:
         return "Error #KB" +  error_number + ": " + msg;
      }
   }

   public int getType()
   {
      return type;
   }
}
