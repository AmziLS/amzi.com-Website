// VariableKey.java

package amzi.kb;

import java.io.*;

public class VariableKey implements Serializable
{
   static KnowledgeBase KB = null;

   public String key;

   public static void set_kb(KnowledgeBase kb)
   {
      KB = kb;
   }

   public VariableKey(String k)
   {
      key = k;
   }

   public String get_key() { return key; }
   public String toString() { return get_name(); }
   public int hashCode() { return key.hashCode(); }
   public boolean equals(VariableKey k) { return key.equals(k.key); }

   public String get_name()
   {
      if (KB == null)
         return key;
      else
      {
         Variable v = KB.get_variable(this);
         if (v == null)
         {
            System.out.println("No variable in KB for: " + key);
            Thread.currentThread().dumpStack();
         }
         return KB.get_variable(this).get_name();
      }
   }

   // Implementation of the Serializable interface

   private void writeObject(java.io.ObjectOutputStream out)
      throws IOException
   {
      out.defaultWriteObject();
   }

   private void readObject(java.io.ObjectInputStream in)
      throws IOException, ClassNotFoundException
   {
      in.defaultReadObject();
   }
}