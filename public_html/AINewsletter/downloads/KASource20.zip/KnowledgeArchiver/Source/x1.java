import java.io.*;
import java.util.*;

public class x1
{
   public static void main(String[] args)
   {
      Stack s = new Stack();
      s.push("a");
      s.push("b");
      s.push("c");
      for (int i=0; i<s.size(); i++)
         System.out.println((String)s.elementAt(i));
   }
}